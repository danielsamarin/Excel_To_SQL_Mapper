"""Base classes and utilities for tool implementations."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Generic, TypeVar
from pydantic import BaseModel

from ..core.confirmation import ConfirmationHandler


T = TypeVar("T", bound=BaseModel)


@dataclass
class ToolResult:
    """Result of a tool execution."""

    success: bool
    data: Any = None
    error: str | None = None
    message: str | None = None

    def to_string(self) -> str:
        """Convert result to human-readable string."""
        if self.error:
            return f"Error: {self.error}"
        if self.message:
            return self.message
        if self.data is not None:
            if isinstance(self.data, (list, dict)):
                import json
                return json.dumps(self.data, indent=2, default=str)
            return str(self.data)
        return "Operation completed successfully."


class BaseTool(ABC, Generic[T]):
    """Base class for all tools."""

    name: str
    description: str
    param_model: type[T]

    def __init__(self, confirmation_handler: ConfirmationHandler | None = None):
        self._confirmation_handler = confirmation_handler

    @abstractmethod
    async def execute(self, params: T) -> ToolResult:
        """Execute the tool with the given parameters."""
        pass

    def get_parameters_schema(self) -> dict:
        """Get the JSON schema for the tool parameters."""
        return self.param_model.model_json_schema()

    async def __call__(self, params: dict) -> str:
        """Call the tool with a params dict, returning a string result."""
        try:
            validated_params = self.param_model.model_validate(params)
            result = await self.execute(validated_params)
            return result.to_string()
        except Exception as e:
            return f"Error executing {self.name}: {str(e)}"


class EmptyParams(BaseModel):
    """Empty parameters model for tools that don't require parameters."""

    pass
