"""Tests for Copilot Windows Manager."""
