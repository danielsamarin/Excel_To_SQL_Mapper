"""Chat interface component."""

from dataclasses import dataclass, field
from typing import Callable, Awaitable
import asyncio

from nicegui import ui

from ..core.confirmation import ConfirmationRequest, ActionSeverity


@dataclass
class ChatMessage:
    """A message in the chat history."""

    role: str  # "user", "assistant", "system"
    content: str
    confirmation_request: ConfirmationRequest | None = None


class ChatInterface:
    """Chat interface for interacting with Copilot."""

    def __init__(self):
        self._messages: list[ChatMessage] = []
        self._on_send: Callable[[str], Awaitable[None]] | None = None
        self._message_container: ui.column | None = None
        self._input_field: ui.input | None = None
        self._is_processing = False

    def set_on_send(self, callback: Callable[[str], Awaitable[None]]):
        """Set the callback for when user sends a message."""
        self._on_send = callback

    def add_message(self, role: str, content: str):
        """Add a message to the chat history."""
        self._messages.append(ChatMessage(role=role, content=content))
        self._refresh_messages()

    def add_confirmation_request(self, request: ConfirmationRequest):
        """Add a confirmation request to the chat."""
        msg = ChatMessage(
            role="system",
            content="",
            confirmation_request=request,
        )
        self._messages.append(msg)
        self._refresh_messages()

    def remove_confirmation_request(self, request_id: str):
        """Remove a confirmation request from the chat."""
        self._messages = [
            m for m in self._messages
            if not (m.confirmation_request and m.confirmation_request.id == request_id)
        ]
        self._refresh_messages()

    def set_processing(self, is_processing: bool):
        """Set the processing state."""
        self._is_processing = is_processing
        if self._input_field:
            self._input_field.props(f"{'disabled' if is_processing else ''}")

    def clear(self):
        """Clear the chat history."""
        self._messages.clear()
        self._refresh_messages()

    def render(self) -> ui.column:
        """Render the chat interface."""
        with ui.column().classes("w-full h-full") as container:
            with ui.scroll_area().classes("flex-grow w-full"):
                self._message_container = ui.column().classes("w-full p-4 gap-2")
                self._render_messages()

            with ui.row().classes("w-full p-4 gap-2 items-center border-t"):
                self._input_field = ui.input(
                    placeholder="Type your message..."
                ).classes("flex-grow").props("outlined dense")

                self._input_field.on("keydown.enter", self._handle_send)

                ui.button(
                    icon="send",
                    on_click=self._handle_send,
                ).props("flat round color=primary")

        return container

    def _render_messages(self):
        """Render all messages in the container."""
        if not self._message_container:
            return

        self._message_container.clear()

        with self._message_container:
            if not self._messages:
                ui.label("How can I help you manage your Windows system today?").classes(
                    "text-gray-500 text-center w-full py-8"
                )
                return

            for msg in self._messages:
                self._render_message(msg)

            if self._is_processing:
                with ui.row().classes("items-center gap-2"):
                    ui.spinner(size="sm")
                    ui.label("Processing...").classes("text-gray-500")

    def _render_message(self, msg: ChatMessage):
        """Render a single message."""
        if msg.confirmation_request:
            self._render_confirmation(msg.confirmation_request)
            return

        if msg.role == "user":
            with ui.row().classes("w-full justify-end"):
                with ui.card().classes("bg-primary text-white max-w-[80%]"):
                    ui.markdown(msg.content)
        elif msg.role == "assistant":
            with ui.row().classes("w-full justify-start"):
                with ui.card().classes("bg-gray-100 max-w-[80%]"):
                    with ui.row().classes("items-center gap-2 mb-2"):
                        ui.icon("smart_toy", size="sm").classes("text-primary")
                        ui.label("Copilot").classes("font-bold text-primary")
                    ui.markdown(msg.content)
        else:
            with ui.row().classes("w-full justify-center"):
                ui.label(msg.content).classes("text-gray-500 text-sm italic")

    def _render_confirmation(self, request: ConfirmationRequest):
        """Render a confirmation request."""
        severity_colors = {
            ActionSeverity.LOW: "bg-blue-50 border-blue-200",
            ActionSeverity.MEDIUM: "bg-yellow-50 border-yellow-200",
            ActionSeverity.HIGH: "bg-red-50 border-red-200",
        }
        severity_icons = {
            ActionSeverity.LOW: "info",
            ActionSeverity.MEDIUM: "warning",
            ActionSeverity.HIGH: "error",
        }
        severity_icon_colors = {
            ActionSeverity.LOW: "text-blue-500",
            ActionSeverity.MEDIUM: "text-yellow-600",
            ActionSeverity.HIGH: "text-red-500",
        }

        color_class = severity_colors.get(request.severity, "bg-gray-50")
        icon = severity_icons.get(request.severity, "help")
        icon_color = severity_icon_colors.get(request.severity, "text-gray-500")

        with ui.card().classes(f"w-full {color_class} border-2"):
            with ui.row().classes("items-center gap-2 mb-2"):
                ui.icon(icon).classes(icon_color)
                ui.label("Confirmation Required").classes("font-bold")
                ui.badge(request.severity.value.upper()).props(
                    f"color={'negative' if request.severity == ActionSeverity.HIGH else 'warning' if request.severity == ActionSeverity.MEDIUM else 'primary'}"
                )

            ui.label(f"Action: {request.action_name}").classes("font-medium")
            ui.label(request.description).classes("text-gray-700")

            if request.details:
                with ui.expansion("Details", icon="info").classes("w-full"):
                    for key, value in request.details.items():
                        ui.label(f"{key}: {value}").classes("text-sm text-gray-600")

            with ui.row().classes("gap-2 mt-4"):
                ui.button(
                    "Confirm",
                    on_click=lambda r=request: self._handle_confirm(r),
                    color="primary",
                ).props("unelevated")
                ui.button(
                    "Cancel",
                    on_click=lambda r=request: self._handle_deny(r),
                    color="negative",
                ).props("outline")

    def _refresh_messages(self):
        """Refresh the message display."""
        if self._message_container:
            self._message_container.clear()
            with self._message_container:
                if not self._messages:
                    ui.label("How can I help you manage your Windows system today?").classes(
                        "text-gray-500 text-center w-full py-8"
                    )
                else:
                    for msg in self._messages:
                        self._render_message(msg)

                    if self._is_processing:
                        with ui.row().classes("items-center gap-2"):
                            ui.spinner(size="sm")
                            ui.label("Processing...").classes("text-gray-500")

    async def _handle_send(self):
        """Handle sending a message."""
        if not self._input_field or not self._on_send:
            return

        content = self._input_field.value
        if not content or not content.strip():
            return

        self._input_field.value = ""
        await self._on_send(content.strip())

    def _handle_confirm(self, request: ConfirmationRequest):
        """Handle confirmation."""
        from ..app import get_app_instance
        app = get_app_instance()
        if app and app.confirmation_handler:
            app.confirmation_handler.confirm(request.id)
        self.remove_confirmation_request(request.id)
        self.add_message("system", f"Confirmed: {request.action_name}")

    def _handle_deny(self, request: ConfirmationRequest):
        """Handle denial."""
        from ..app import get_app_instance
        app = get_app_instance()
        if app and app.confirmation_handler:
            app.confirmation_handler.deny(request.id)
        self.remove_confirmation_request(request.id)
        self.add_message("system", f"Cancelled: {request.action_name}")
