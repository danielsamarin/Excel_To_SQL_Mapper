"""Application management tools."""

import subprocess
import os
from pathlib import Path
from pydantic import BaseModel, Field
import winreg

from ..base import BaseTool, ToolResult, EmptyParams
from ...core.confirmation import ConfirmationHandler


class LaunchAppParams(BaseModel):
    """Parameters for launch_app tool."""
    path: str = Field(description="Application path or name")
    args: list[str] = Field(default_factory=list, description="Command line arguments")


class ListInstalledAppsParams(EmptyParams):
    """Parameters for list_installed_apps tool."""
    pass


class GetRunningAppsParams(EmptyParams):
    """Parameters for get_running_apps tool."""
    pass


def _get_installed_apps_from_registry() -> list[dict]:
    """Get installed applications from Windows registry."""
    apps = []
    registry_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]

    for hkey, path in registry_paths:
        try:
            with winreg.OpenKey(hkey, path) as key:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        subkey_name = winreg.EnumKey(key, i)
                        with winreg.OpenKey(key, subkey_name) as subkey:
                            try:
                                name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                                app_info = {"name": name}
                                try:
                                    app_info["version"] = winreg.QueryValueEx(subkey, "DisplayVersion")[0]
                                except FileNotFoundError:
                                    pass
                                try:
                                    app_info["publisher"] = winreg.QueryValueEx(subkey, "Publisher")[0]
                                except FileNotFoundError:
                                    pass
                                try:
                                    app_info["install_location"] = winreg.QueryValueEx(subkey, "InstallLocation")[0]
                                except FileNotFoundError:
                                    pass
                                apps.append(app_info)
                            except FileNotFoundError:
                                continue
                    except Exception:
                        continue
        except Exception:
            continue

    seen = set()
    unique_apps = []
    for app in apps:
        if app["name"] not in seen:
            seen.add(app["name"])
            unique_apps.append(app)

    return sorted(unique_apps, key=lambda x: x["name"].lower())


class ListInstalledAppsTool(BaseTool[ListInstalledAppsParams]):
    name = "list_installed_apps"
    description = "List all installed applications on the system"
    param_model = ListInstalledAppsParams

    async def execute(self, params: ListInstalledAppsParams) -> ToolResult:
        try:
            apps = _get_installed_apps_from_registry()
            return ToolResult(
                success=True,
                data=apps[:100],
                message=f"Found {len(apps)} installed applications (showing max 100)",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class LaunchAppTool(BaseTool[LaunchAppParams]):
    name = "launch_app"
    description = "Launch an application by path or name"
    param_model = LaunchAppParams

    async def execute(self, params: LaunchAppParams) -> ToolResult:
        try:
            path = params.path

            well_known_apps = {
                "notepad": "notepad.exe",
                "calculator": "calc.exe",
                "calc": "calc.exe",
                "paint": "mspaint.exe",
                "explorer": "explorer.exe",
                "cmd": "cmd.exe",
                "powershell": "powershell.exe",
                "chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                "firefox": r"C:\Program Files\Mozilla Firefox\firefox.exe",
                "code": "code",
                "vscode": "code",
            }

            if path.lower() in well_known_apps:
                path = well_known_apps[path.lower()]

            cmd = [path] + params.args
            subprocess.Popen(cmd, shell=True)

            return ToolResult(success=True, message=f"Launched: {path}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class GetRunningAppsTool(BaseTool[GetRunningAppsParams]):
    name = "get_running_apps"
    description = "Get a list of currently running applications"
    param_model = GetRunningAppsParams

    async def execute(self, params: GetRunningAppsParams) -> ToolResult:
        try:
            import psutil

            running_apps = []
            seen_names = set()

            for proc in psutil.process_iter(["pid", "name", "exe"]):
                try:
                    info = proc.info
                    name = info["name"]

                    if name and name not in seen_names:
                        if not name.lower().startswith(("system", "registry", "csrss", "smss", "wininit", "services")):
                            seen_names.add(name)
                            running_apps.append({
                                "name": name,
                                "pid": info["pid"],
                                "exe": info.get("exe"),
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            running_apps.sort(key=lambda x: x["name"].lower())

            return ToolResult(
                success=True,
                data=running_apps[:50],
                message=f"Found {len(running_apps)} running applications (showing max 50)",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_application_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all application management tools."""
    return [
        ListInstalledAppsTool(confirmation_handler),
        LaunchAppTool(confirmation_handler),
        GetRunningAppsTool(confirmation_handler),
    ]
