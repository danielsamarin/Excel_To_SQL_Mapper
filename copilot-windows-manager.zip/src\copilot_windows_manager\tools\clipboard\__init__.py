"""Clipboard management tools."""

import pyperclip
from pydantic import BaseModel, Field

from ..base import BaseTool, ToolResult, EmptyParams
from ...core.confirmation import ConfirmationHandler


class GetClipboardParams(EmptyParams):
    """Parameters for get_clipboard tool."""
    pass


class SetClipboardParams(BaseModel):
    """Parameters for set_clipboard tool."""
    content: str = Field(description="Content to copy to clipboard")


class ClearClipboardParams(EmptyParams):
    """Parameters for clear_clipboard tool."""
    pass


class GetClipboardTool(BaseTool[GetClipboardParams]):
    name = "get_clipboard"
    description = "Get the current contents of the clipboard"
    param_model = GetClipboardParams

    async def execute(self, params: GetClipboardParams) -> ToolResult:
        try:
            content = pyperclip.paste()
            if not content:
                return ToolResult(success=True, data="", message="Clipboard is empty")

            if len(content) > 10000:
                content = content[:10000] + "\n... (truncated)"

            return ToolResult(success=True, data=content, message=f"Clipboard contains {len(content)} characters")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class SetClipboardTool(BaseTool[SetClipboardParams]):
    name = "set_clipboard"
    description = "Copy content to the clipboard"
    param_model = SetClipboardParams

    async def execute(self, params: SetClipboardParams) -> ToolResult:
        try:
            pyperclip.copy(params.content)
            return ToolResult(success=True, message=f"Copied {len(params.content)} characters to clipboard")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ClearClipboardTool(BaseTool[ClearClipboardParams]):
    name = "clear_clipboard"
    description = "Clear the clipboard contents"
    param_model = ClearClipboardParams

    async def execute(self, params: ClearClipboardParams) -> ToolResult:
        try:
            pyperclip.copy("")
            return ToolResult(success=True, message="Clipboard cleared")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_clipboard_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all clipboard management tools."""
    return [
        GetClipboardTool(confirmation_handler),
        SetClipboardTool(confirmation_handler),
        ClearClipboardTool(confirmation_handler),
    ]
