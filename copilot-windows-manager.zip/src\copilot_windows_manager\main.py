"""Entry point for Copilot Windows Manager."""

import sys


def main():
    """Main entry point."""
    from .utils.logging import setup_logging

    debug = "--debug" in sys.argv
    setup_logging(debug=debug)

    from .app import create_app
    from nicegui import ui, app

    copilot_app = create_app()

    native = "--no-native" not in sys.argv

    if native:
        ui.run(
            title="Copilot Windows Manager",
            native=True,
            window_size=(1200, 800),
            reload=False,
        )
    else:
        ui.run(
            title="Copilot Windows Manager",
            host="127.0.0.1",
            port=8080,
            reload=debug,
        )


if __name__ == "__main__":
    main()
