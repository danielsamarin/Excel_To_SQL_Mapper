"""Excel automation tools using win32com."""

from pathlib import Path
from pydantic import BaseModel, Field
from typing import Optional, Any

from ..base import BaseTool, ToolResult
from ...core.confirmation import ConfirmationHandler, ActionSeverity

try:
    import win32com.client
    HAS_WIN32COM = True
except ImportError:
    HAS_WIN32COM = False


class CreateWorkbookParams(BaseModel):
    """Parameters for create_workbook tool."""
    path: str = Field(description="Path for the new Excel file")
    sheet_name: str = Field(default="Sheet1", description="Name for the first sheet")


class OpenWorkbookParams(BaseModel):
    """Parameters for open_workbook tool."""
    path: str = Field(description="Path to the Excel file")


class ReadCellsParams(BaseModel):
    """Parameters for read_cells tool."""
    path: str = Field(description="Path to the Excel file")
    sheet: str = Field(default="Sheet1", description="Sheet name")
    range: str = Field(description="Cell range (e.g., 'A1:C10' or 'A1')")


class WriteCellsParams(BaseModel):
    """Parameters for write_cells tool."""
    path: str = Field(description="Path to the Excel file")
    sheet: str = Field(default="Sheet1", description="Sheet name")
    range: str = Field(description="Starting cell (e.g., 'A1')")
    values: list[list[Any]] = Field(description="2D array of values to write")


class RunFormulaParams(BaseModel):
    """Parameters for run_formula tool."""
    path: str = Field(description="Path to the Excel file")
    sheet: str = Field(default="Sheet1", description="Sheet name")
    cell: str = Field(description="Cell to put the formula (e.g., 'A1')")
    formula: str = Field(description="Excel formula (e.g., '=SUM(A1:A10)')")


def _get_excel_app():
    """Get or create Excel application instance."""
    if not HAS_WIN32COM:
        raise RuntimeError("win32com not available. Install pywin32.")
    try:
        excel = win32com.client.GetActiveObject("Excel.Application")
    except Exception:
        excel = win32com.client.Dispatch("Excel.Application")
    excel.Visible = True
    return excel


class CreateWorkbookTool(BaseTool[CreateWorkbookParams]):
    name = "create_workbook"
    description = "Create a new Excel workbook"
    param_model = CreateWorkbookParams
    _requires_confirmation = True

    async def execute(self, params: CreateWorkbookParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="create_workbook",
                description=f"Create new Excel workbook: {params.path}",
                severity=ActionSeverity.MEDIUM,
                details={"path": params.path, "sheet_name": params.sheet_name},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            excel = _get_excel_app()
            workbook = excel.Workbooks.Add()

            sheet = workbook.Sheets(1)
            sheet.Name = params.sheet_name

            path = Path(params.path).expanduser().resolve()
            path.parent.mkdir(parents=True, exist_ok=True)

            workbook.SaveAs(str(path))

            return ToolResult(success=True, message=f"Created workbook: {path}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class OpenWorkbookTool(BaseTool[OpenWorkbookParams]):
    name = "open_workbook"
    description = "Open an existing Excel workbook"
    param_model = OpenWorkbookParams

    async def execute(self, params: OpenWorkbookParams) -> ToolResult:
        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"File not found: {path}")

            excel = _get_excel_app()
            workbook = excel.Workbooks.Open(str(path))

            sheets = [workbook.Sheets(i + 1).Name for i in range(workbook.Sheets.Count)]

            return ToolResult(
                success=True,
                data={"path": str(path), "sheets": sheets},
                message=f"Opened workbook with {len(sheets)} sheets: {', '.join(sheets)}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ReadCellsTool(BaseTool[ReadCellsParams]):
    name = "read_cells"
    description = "Read values from a cell range in an Excel workbook"
    param_model = ReadCellsParams

    async def execute(self, params: ReadCellsParams) -> ToolResult:
        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"File not found: {path}")

            excel = _get_excel_app()

            workbook = None
            for wb in excel.Workbooks:
                if Path(wb.FullName).resolve() == path:
                    workbook = wb
                    break

            if not workbook:
                workbook = excel.Workbooks.Open(str(path))

            sheet = workbook.Sheets(params.sheet)
            range_obj = sheet.Range(params.range)
            values = range_obj.Value

            if values is None:
                values = [[None]]
            elif not isinstance(values, tuple):
                values = [[values]]
            else:
                values = [list(row) if isinstance(row, tuple) else [row] for row in values]

            return ToolResult(
                success=True,
                data=values,
                message=f"Read {len(values)} rows from {params.range}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class WriteCellsTool(BaseTool[WriteCellsParams]):
    name = "write_cells"
    description = "Write values to cells in an Excel workbook"
    param_model = WriteCellsParams
    _requires_confirmation = True

    async def execute(self, params: WriteCellsParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="write_cells",
                description=f"Write {len(params.values)} rows to {params.path}",
                severity=ActionSeverity.MEDIUM,
                details={"path": params.path, "sheet": params.sheet, "range": params.range},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"File not found: {path}")

            excel = _get_excel_app()

            workbook = None
            for wb in excel.Workbooks:
                if Path(wb.FullName).resolve() == path:
                    workbook = wb
                    break

            if not workbook:
                workbook = excel.Workbooks.Open(str(path))

            sheet = workbook.Sheets(params.sheet)

            rows = len(params.values)
            cols = max(len(row) for row in params.values) if params.values else 0

            start_cell = sheet.Range(params.range)
            end_cell = sheet.Cells(start_cell.Row + rows - 1, start_cell.Column + cols - 1)
            target_range = sheet.Range(start_cell, end_cell)

            target_range.Value = params.values
            workbook.Save()

            return ToolResult(success=True, message=f"Wrote {rows}x{cols} values starting at {params.range}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class RunFormulaTool(BaseTool[RunFormulaParams]):
    name = "run_formula"
    description = "Insert an Excel formula into a cell"
    param_model = RunFormulaParams
    _requires_confirmation = True

    async def execute(self, params: RunFormulaParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="run_formula",
                description=f"Insert formula '{params.formula}' at {params.cell}",
                severity=ActionSeverity.MEDIUM,
                details={"path": params.path, "cell": params.cell, "formula": params.formula},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"File not found: {path}")

            excel = _get_excel_app()

            workbook = None
            for wb in excel.Workbooks:
                if Path(wb.FullName).resolve() == path:
                    workbook = wb
                    break

            if not workbook:
                workbook = excel.Workbooks.Open(str(path))

            sheet = workbook.Sheets(params.sheet)
            cell = sheet.Range(params.cell)
            cell.Formula = params.formula

            result = cell.Value
            workbook.Save()

            return ToolResult(
                success=True,
                data={"formula": params.formula, "result": result},
                message=f"Formula inserted at {params.cell}, result: {result}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_excel_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all Excel automation tools."""
    return [
        CreateWorkbookTool(confirmation_handler),
        OpenWorkbookTool(confirmation_handler),
        ReadCellsTool(confirmation_handler),
        WriteCellsTool(confirmation_handler),
        RunFormulaTool(confirmation_handler),
    ]
