"""Main layout for the application."""

from nicegui import ui

from ..tools import ToolRegistry


def create_layout(
    chat_interface,
    tool_registry: ToolRegistry,
    connection_status: str = "Connecting...",
):
    """Create the main application layout.

    Args:
        chat_interface: The chat interface component
        tool_registry: Registry of available tools
        connection_status: Current connection status string
    """
    ui.colors(primary="#0066cc", secondary="#6c757d", accent="#28a745")

    with ui.header().classes("bg-primary text-white items-center justify-between px-4"):
        with ui.row().classes("items-center gap-2"):
            ui.icon("computer", size="md")
            ui.label("Copilot Windows Manager").classes("text-xl font-bold")

        with ui.row().classes("items-center gap-2"):
            status_icon = ui.icon("circle", size="xs")
            status_label = ui.label(connection_status)

            def update_status(status: str, connected: bool):
                status_label.text = status
                if connected:
                    status_icon.classes("text-green-400", remove="text-yellow-400 text-red-400")
                else:
                    status_icon.classes("text-yellow-400", remove="text-green-400 text-red-400")

            status_label._update_status = update_status

    with ui.row().classes("w-full h-[calc(100vh-64px)]"):
        with ui.column().classes("w-64 h-full bg-gray-50 border-r p-4 overflow-y-auto"):
            ui.label("Tool Categories").classes("text-lg font-bold mb-4")

            categories = tool_registry.get_by_category()

            category_icons = {
                "list": "list",
                "focus": "center_focus_strong",
                "move": "open_with",
                "resize": "aspect_ratio",
                "change": "swap_horiz",
                "close": "close",
                "read": "description",
                "write": "edit",
                "copy": "content_copy",
                "delete": "delete",
                "launch": "launch",
                "get": "info",
                "kill": "dangerous",
                "set": "edit",
                "clear": "clear",
                "create": "add",
                "open": "folder_open",
                "run": "play_arrow",
                "send": "send",
                "search": "search",
            }

            category_display = {
                "list": "Windows",
                "focus": "Windows",
                "move": "Windows",
                "resize": "Windows",
                "change": "Windows",
                "close": "Windows",
                "read": "Files",
                "write": "Files",
                "copy": "Files",
                "delete": "Files",
                "launch": "Applications",
                "get": "System",
                "kill": "Processes",
                "set": "Clipboard",
                "clear": "Clipboard",
                "create": "Office",
                "open": "Office",
                "run": "Office",
                "send": "Email",
                "search": "Search",
            }

            grouped: dict[str, list] = {}
            for tool in tool_registry.all():
                prefix = tool.name.split("_")[0]
                display_cat = category_display.get(prefix, "Other")
                if display_cat not in grouped:
                    grouped[display_cat] = []
                grouped[display_cat].append(tool)

            category_order = ["Windows", "Files", "Applications", "Processes", "System", "Clipboard", "Office", "Email", "Search", "Other"]

            for cat in category_order:
                if cat not in grouped:
                    continue
                tools = grouped[cat]

                with ui.expansion(cat, icon=_get_category_icon(cat)).classes("w-full"):
                    for tool in tools:
                        with ui.row().classes("items-center gap-1 py-1 px-2 hover:bg-gray-100 rounded cursor-pointer w-full"):
                            ui.icon(_get_tool_icon(tool.name), size="xs").classes("text-gray-500")
                            ui.label(tool.name.replace("_", " ").title()).classes("text-sm")
                            if getattr(tool, "_requires_confirmation", False):
                                ui.badge("!").props("color=warning dense").classes("ml-auto")

        with ui.column().classes("flex-grow h-full"):
            chat_interface.render()

    with ui.footer().classes("bg-gray-100 text-gray-600 text-sm py-2 px-4"):
        ui.label("GitHub Copilot SDK | NiceGUI Native Mode")


def _get_category_icon(category: str) -> str:
    """Get icon for a tool category."""
    icons = {
        "Windows": "desktop_windows",
        "Files": "folder",
        "Applications": "apps",
        "Processes": "memory",
        "System": "computer",
        "Clipboard": "content_paste",
        "Office": "description",
        "Email": "email",
        "Search": "search",
        "Other": "extension",
    }
    return icons.get(category, "extension")


def _get_tool_icon(tool_name: str) -> str:
    """Get icon for a specific tool."""
    icons = {
        "list_windows": "list",
        "focus_window": "center_focus_strong",
        "move_window": "open_with",
        "resize_window": "aspect_ratio",
        "change_window_state": "swap_horiz",
        "close_window": "close",
        "list_files": "folder",
        "read_file": "description",
        "write_file": "edit",
        "copy_file": "content_copy",
        "move_file": "drive_file_move",
        "delete_file": "delete",
        "list_installed_apps": "apps",
        "launch_app": "launch",
        "get_running_apps": "play_circle",
        "list_processes": "list",
        "get_process_info": "info",
        "kill_process": "dangerous",
        "get_system_stats": "analytics",
        "get_clipboard": "content_paste",
        "set_clipboard": "content_copy",
        "clear_clipboard": "clear",
        "create_workbook": "add",
        "open_workbook": "folder_open",
        "read_cells": "grid_on",
        "write_cells": "edit",
        "run_formula": "functions",
        "send_email": "send",
        "read_inbox": "inbox",
        "create_calendar_event": "event",
        "search_emails": "search",
    }
    return icons.get(tool_name, "build")
