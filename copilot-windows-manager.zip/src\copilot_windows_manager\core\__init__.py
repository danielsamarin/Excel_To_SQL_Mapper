"""Core module for Copilot Windows Manager."""

from .client import CopilotClient
from .confirmation import ConfirmationHandler, ActionSeverity
from .exceptions import (
    CopilotError,
    ToolExecutionError,
    ConfirmationDeniedError,
    ConnectionError,
)

__all__ = [
    "CopilotClient",
    "ConfirmationHandler",
    "ActionSeverity",
    "CopilotError",
    "ToolExecutionError",
    "ConfirmationDeniedError",
    "ConnectionError",
]
