"""File management tools using pathlib and shutil."""

from pathlib import Path
import shutil
from pydantic import BaseModel, Field
from typing import Optional

from ..base import BaseTool, ToolResult
from ...core.confirmation import ConfirmationHandler, ActionSeverity


class ListFilesParams(BaseModel):
    """Parameters for list_files tool."""
    path: str = Field(default=".", description="Directory path to list")
    pattern: str = Field(default="*", description="Glob pattern to match")
    recursive: bool = Field(default=False, description="Search recursively")


class ReadFileParams(BaseModel):
    """Parameters for read_file tool."""
    path: str = Field(description="File path to read")
    encoding: str = Field(default="utf-8", description="File encoding")


class WriteFileParams(BaseModel):
    """Parameters for write_file tool."""
    path: str = Field(description="File path to write")
    content: str = Field(description="Content to write")
    append: bool = Field(default=False, description="Append instead of overwrite")


class CopyFileParams(BaseModel):
    """Parameters for copy_file tool."""
    source: str = Field(description="Source file path")
    destination: str = Field(description="Destination file path")


class MoveFileParams(BaseModel):
    """Parameters for move_file tool."""
    source: str = Field(description="Source file path")
    destination: str = Field(description="Destination file path")


class DeleteFileParams(BaseModel):
    """Parameters for delete_file tool."""
    path: str = Field(description="File path to delete")


class ListFilesTool(BaseTool[ListFilesParams]):
    name = "list_files"
    description = "List files in a directory with optional glob pattern matching"
    param_model = ListFilesParams

    async def execute(self, params: ListFilesParams) -> ToolResult:
        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"Path does not exist: {path}")

            if params.recursive:
                files = list(path.rglob(params.pattern))
            else:
                files = list(path.glob(params.pattern))

            file_list = []
            for f in files[:100]:
                try:
                    stat = f.stat()
                    file_list.append({
                        "name": f.name,
                        "path": str(f),
                        "is_dir": f.is_dir(),
                        "size": stat.st_size if f.is_file() else None,
                    })
                except Exception:
                    continue

            return ToolResult(
                success=True,
                data=file_list,
                message=f"Found {len(file_list)} items (showing max 100)",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ReadFileTool(BaseTool[ReadFileParams]):
    name = "read_file"
    description = "Read the contents of a file"
    param_model = ReadFileParams

    async def execute(self, params: ReadFileParams) -> ToolResult:
        try:
            path = Path(params.path).expanduser().resolve()
            if not path.exists():
                return ToolResult(success=False, error=f"File does not exist: {path}")
            if not path.is_file():
                return ToolResult(success=False, error=f"Path is not a file: {path}")

            content = path.read_text(encoding=params.encoding)

            if len(content) > 50000:
                content = content[:50000] + "\n... (truncated)"

            return ToolResult(success=True, data=content, message=f"Read {len(content)} characters from {path.name}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class WriteFileTool(BaseTool[WriteFileParams]):
    name = "write_file"
    description = "Write content to a file (create or overwrite)"
    param_model = WriteFileParams
    _requires_confirmation = True

    async def execute(self, params: WriteFileParams) -> ToolResult:
        if self._confirmation_handler:
            action = "Append to" if params.append else "Write to"
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="write_file",
                description=f"{action} file: {params.path}",
                severity=ActionSeverity.MEDIUM,
                details={"path": params.path, "content_length": len(params.content), "append": params.append},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            path = Path(params.path).expanduser().resolve()
            path.parent.mkdir(parents=True, exist_ok=True)

            mode = "a" if params.append else "w"
            with open(path, mode, encoding="utf-8") as f:
                f.write(params.content)

            action = "Appended to" if params.append else "Wrote to"
            return ToolResult(success=True, message=f"{action} {path}: {len(params.content)} characters")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class CopyFileTool(BaseTool[CopyFileParams]):
    name = "copy_file"
    description = "Copy a file to a new location"
    param_model = CopyFileParams

    async def execute(self, params: CopyFileParams) -> ToolResult:
        try:
            source = Path(params.source).expanduser().resolve()
            destination = Path(params.destination).expanduser().resolve()

            if not source.exists():
                return ToolResult(success=False, error=f"Source does not exist: {source}")

            destination.parent.mkdir(parents=True, exist_ok=True)

            if source.is_dir():
                shutil.copytree(source, destination)
            else:
                shutil.copy2(source, destination)

            return ToolResult(success=True, message=f"Copied {source} to {destination}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class MoveFileTool(BaseTool[MoveFileParams]):
    name = "move_file"
    description = "Move a file to a new location"
    param_model = MoveFileParams
    _requires_confirmation = True

    async def execute(self, params: MoveFileParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="move_file",
                description=f"Move {params.source} to {params.destination}",
                severity=ActionSeverity.MEDIUM,
                details={"source": params.source, "destination": params.destination},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            source = Path(params.source).expanduser().resolve()
            destination = Path(params.destination).expanduser().resolve()

            if not source.exists():
                return ToolResult(success=False, error=f"Source does not exist: {source}")

            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(destination))

            return ToolResult(success=True, message=f"Moved {source} to {destination}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class DeleteFileTool(BaseTool[DeleteFileParams]):
    name = "delete_file"
    description = "Delete a file or directory"
    param_model = DeleteFileParams
    _requires_confirmation = True

    async def execute(self, params: DeleteFileParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="delete_file",
                description=f"Delete: {params.path}",
                severity=ActionSeverity.HIGH,
                details={"path": params.path},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            path = Path(params.path).expanduser().resolve()

            if not path.exists():
                return ToolResult(success=False, error=f"Path does not exist: {path}")

            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()

            return ToolResult(success=True, message=f"Deleted: {path}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_file_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all file management tools."""
    return [
        ListFilesTool(confirmation_handler),
        ReadFileTool(confirmation_handler),
        WriteFileTool(confirmation_handler),
        CopyFileTool(confirmation_handler),
        MoveFileTool(confirmation_handler),
        DeleteFileTool(confirmation_handler),
    ]
