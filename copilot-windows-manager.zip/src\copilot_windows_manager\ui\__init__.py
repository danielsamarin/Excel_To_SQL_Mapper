"""UI module for Copilot Windows Manager."""

from .layout import create_layout
from .chat import ChatInterface

__all__ = ["create_layout", "ChatInterface"]
