"""Outlook automation tools using win32com."""

from datetime import datetime
from pydantic import BaseModel, Field
from typing import Optional

from ..base import BaseTool, ToolResult
from ...core.confirmation import ConfirmationHandler, ActionSeverity

try:
    import win32com.client
    HAS_WIN32COM = True
except ImportError:
    HAS_WIN32COM = False


class SendEmailParams(BaseModel):
    """Parameters for send_email tool."""
    to: list[str] = Field(description="List of recipient email addresses")
    subject: str = Field(description="Email subject")
    body: str = Field(description="Email body (plain text or HTML)")
    cc: list[str] = Field(default_factory=list, description="CC recipients")
    bcc: list[str] = Field(default_factory=list, description="BCC recipients")
    html: bool = Field(default=False, description="Whether body is HTML")


class ReadInboxParams(BaseModel):
    """Parameters for read_inbox tool."""
    count: int = Field(default=10, description="Number of messages to retrieve")
    unread_only: bool = Field(default=False, description="Only return unread messages")


class CreateCalendarEventParams(BaseModel):
    """Parameters for create_calendar_event tool."""
    subject: str = Field(description="Event subject/title")
    start: str = Field(description="Start time (ISO format: 2024-01-15T09:00:00)")
    end: str = Field(description="End time (ISO format: 2024-01-15T10:00:00)")
    location: str = Field(default="", description="Event location")
    body: str = Field(default="", description="Event description")
    attendees: list[str] = Field(default_factory=list, description="List of attendee emails")


class SearchEmailsParams(BaseModel):
    """Parameters for search_emails tool."""
    query: str = Field(description="Search query")
    folder: str = Field(default="Inbox", description="Folder to search in")
    count: int = Field(default=20, description="Maximum results to return")


def _get_outlook_app():
    """Get or create Outlook application instance."""
    if not HAS_WIN32COM:
        raise RuntimeError("win32com not available. Install pywin32.")
    return win32com.client.Dispatch("Outlook.Application")


class SendEmailTool(BaseTool[SendEmailParams]):
    name = "send_email"
    description = "Send an email via Outlook"
    param_model = SendEmailParams
    _requires_confirmation = True

    async def execute(self, params: SendEmailParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="send_email",
                description=f"Send email to {', '.join(params.to)}",
                severity=ActionSeverity.HIGH,
                details={
                    "to": params.to,
                    "subject": params.subject,
                    "cc": params.cc,
                    "bcc": params.bcc,
                },
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            outlook = _get_outlook_app()
            mail = outlook.CreateItem(0)

            mail.To = "; ".join(params.to)
            mail.Subject = params.subject

            if params.cc:
                mail.CC = "; ".join(params.cc)
            if params.bcc:
                mail.BCC = "; ".join(params.bcc)

            if params.html:
                mail.HTMLBody = params.body
            else:
                mail.Body = params.body

            mail.Send()

            return ToolResult(
                success=True,
                message=f"Email sent to {', '.join(params.to)} with subject: {params.subject}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ReadInboxTool(BaseTool[ReadInboxParams]):
    name = "read_inbox"
    description = "Read messages from Outlook inbox"
    param_model = ReadInboxParams

    async def execute(self, params: ReadInboxParams) -> ToolResult:
        try:
            outlook = _get_outlook_app()
            namespace = outlook.GetNamespace("MAPI")
            inbox = namespace.GetDefaultFolder(6)

            messages = inbox.Items
            messages.Sort("[ReceivedTime]", True)

            email_list = []
            count = 0

            for msg in messages:
                if count >= params.count:
                    break

                try:
                    if params.unread_only and msg.UnRead is False:
                        continue

                    email_list.append({
                        "subject": msg.Subject,
                        "sender": str(msg.SenderEmailAddress),
                        "sender_name": str(msg.SenderName),
                        "received": str(msg.ReceivedTime),
                        "unread": msg.UnRead,
                        "preview": msg.Body[:200] if msg.Body else "",
                    })
                    count += 1
                except Exception:
                    continue

            return ToolResult(
                success=True,
                data=email_list,
                message=f"Retrieved {len(email_list)} emails from inbox",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class CreateCalendarEventTool(BaseTool[CreateCalendarEventParams]):
    name = "create_calendar_event"
    description = "Create a calendar event in Outlook"
    param_model = CreateCalendarEventParams
    _requires_confirmation = True

    async def execute(self, params: CreateCalendarEventParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="create_calendar_event",
                description=f"Create calendar event: {params.subject}",
                severity=ActionSeverity.MEDIUM,
                details={
                    "subject": params.subject,
                    "start": params.start,
                    "end": params.end,
                    "attendees": params.attendees,
                },
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            outlook = _get_outlook_app()
            appointment = outlook.CreateItem(1)

            appointment.Subject = params.subject
            appointment.Start = params.start
            appointment.End = params.end

            if params.location:
                appointment.Location = params.location
            if params.body:
                appointment.Body = params.body

            if params.attendees:
                for email in params.attendees:
                    appointment.Recipients.Add(email)
                appointment.MeetingStatus = 1

            appointment.Save()

            if params.attendees:
                appointment.Send()

            return ToolResult(
                success=True,
                message=f"Created calendar event: {params.subject} from {params.start} to {params.end}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class SearchEmailsTool(BaseTool[SearchEmailsParams]):
    name = "search_emails"
    description = "Search emails in Outlook by query"
    param_model = SearchEmailsParams

    async def execute(self, params: SearchEmailsParams) -> ToolResult:
        try:
            outlook = _get_outlook_app()
            namespace = outlook.GetNamespace("MAPI")

            folder_map = {
                "Inbox": 6,
                "Outbox": 4,
                "Sent": 5,
                "Drafts": 16,
                "Deleted": 3,
            }

            folder_id = folder_map.get(params.folder, 6)
            folder = namespace.GetDefaultFolder(folder_id)

            filter_str = f"@SQL=\"urn:schemas:httpmail:subject\" LIKE '%{params.query}%' OR \"urn:schemas:httpmail:textdescription\" LIKE '%{params.query}%'"

            try:
                messages = folder.Items.Restrict(filter_str)
            except Exception:
                messages = folder.Items

            messages.Sort("[ReceivedTime]", True)

            results = []
            count = 0

            for msg in messages:
                if count >= params.count:
                    break

                try:
                    subject = str(msg.Subject).lower()
                    body = str(msg.Body).lower() if msg.Body else ""
                    query_lower = params.query.lower()

                    if query_lower in subject or query_lower in body:
                        results.append({
                            "subject": msg.Subject,
                            "sender": str(msg.SenderEmailAddress),
                            "sender_name": str(msg.SenderName),
                            "received": str(msg.ReceivedTime),
                            "preview": msg.Body[:200] if msg.Body else "",
                        })
                        count += 1
                except Exception:
                    continue

            return ToolResult(
                success=True,
                data=results,
                message=f"Found {len(results)} emails matching '{params.query}'",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_outlook_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all Outlook automation tools."""
    return [
        SendEmailTool(confirmation_handler),
        ReadInboxTool(confirmation_handler),
        CreateCalendarEventTool(confirmation_handler),
        SearchEmailsTool(confirmation_handler),
    ]
