"""Copilot SDK client wrapper using the official GitHub Copilot SDK."""

import asyncio
from dataclasses import dataclass
from typing import Callable, Any, Optional

import structlog

from copilot import (
    CopilotClient as SDKClient,
    CopilotSession,
    Tool,
    define_tool,
    SessionEvent,
    PermissionRequest,
    PermissionRequestResult,
)
from copilot.generated.session_events import SessionEventType

from .exceptions import ConnectionError, ToolExecutionError
from .confirmation import ConfirmationHandler

logger = structlog.get_logger()


@dataclass
class Message:
    """A chat message."""

    role: str  # "user", "assistant", "system", "tool"
    content: str
    tool_calls: list[dict] | None = None
    tool_call_id: str | None = None
    name: str | None = None


@dataclass
class ToolDefinition:
    """Definition of an available tool for internal tracking."""

    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable
    requires_confirmation: bool = False


# Available models from the Copilot SDK
AVAILABLE_MODELS = [
    ("gpt-5", "GPT-5"),
    ("claude-sonnet-4", "Claude Sonnet 4"),
    ("claude-sonnet-4.5", "Claude Sonnet 4.5"),
    ("claude-haiku-4.5", "Claude Haiku 4.5"),
]

DEFAULT_MODEL = "gpt-5"


class CopilotClientWrapper:
    """Wrapper for GitHub Copilot SDK interactions."""

    def __init__(self, confirmation_handler: ConfirmationHandler | None = None):
        self._tool_definitions: dict[str, ToolDefinition] = {}
        self._sdk_tools: list[Tool] = []
        self._confirmation_handler = confirmation_handler
        self._connected = False
        self._messages: list[Message] = []
        self._on_message_callback: Callable[[Message], None] | None = None
        self._on_stream_callback: Callable[[str], None] | None = None
        self._on_model_change_callback: Callable[[str], None] | None = None

        # Current model selection
        self._selected_model: str = DEFAULT_MODEL

        # SDK client and session
        self._client: SDKClient | None = None
        self._session: CopilotSession | None = None

    @property
    def selected_model(self) -> str:
        """Get the currently selected model."""
        return self._selected_model

    @selected_model.setter
    def selected_model(self, model: str):
        """Set the selected model."""
        valid_models = [m[0] for m in AVAILABLE_MODELS]
        if model in valid_models:
            self._selected_model = model
            logger.info("Model changed", model=model)
            if self._on_model_change_callback:
                self._on_model_change_callback(model)
        else:
            logger.warning("Invalid model selected", model=model, valid=valid_models)

    def set_model_change_callback(self, callback: Callable[[str], None]):
        """Set callback for when model changes."""
        self._on_model_change_callback = callback

    @staticmethod
    def get_available_models() -> list[tuple[str, str]]:
        """Get list of available models as (id, display_name) tuples."""
        return AVAILABLE_MODELS.copy()

    def set_message_callback(self, callback: Callable[[Message], None]):
        """Set callback for new messages."""
        self._on_message_callback = callback

    def set_stream_callback(self, callback: Callable[[str], None]):
        """Set callback for streaming tokens."""
        self._on_stream_callback = callback

    def register_tool(self, tool_def: ToolDefinition):
        """Register a tool with the client."""
        self._tool_definitions[tool_def.name] = tool_def

        # Create SDK Tool from our ToolDefinition
        async def make_handler(definition: ToolDefinition):
            async def handler(invocation):
                params = invocation.get("arguments", {})
                try:
                    if asyncio.iscoroutinefunction(definition.handler):
                        result = await definition.handler(params)
                    else:
                        result = definition.handler(params)
                    return result
                except Exception as e:
                    logger.error("Tool execution failed", tool=definition.name, error=str(e))
                    return f"Error: {str(e)}"

            return handler

        # Create the SDK Tool
        sdk_tool = Tool(
            name=tool_def.name,
            description=tool_def.description,
            parameters=tool_def.parameters,
            handler=asyncio.get_event_loop().run_until_complete(make_handler(tool_def)),
        )
        self._sdk_tools.append(sdk_tool)
        logger.info("Registered tool", tool_name=tool_def.name)

    def get_tools(self) -> list[ToolDefinition]:
        """Get all registered tools."""
        return list(self._tool_definitions.values())

    def get_tools_schema(self) -> list[dict]:
        """Get tools in OpenAI function calling schema format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for tool in self._tool_definitions.values()
        ]

    async def connect(self) -> bool:
        """Initialize Copilot SDK client and verify connection."""
        try:
            # Create SDK client with default options (spawns CLI server)
            self._client = SDKClient({
                "log_level": "info",
                "auto_start": True,
                "auto_restart": True,
            })

            # Start the client
            await self._client.start()

            # Verify connection with a ping
            ping_response = await self._client.ping("health-check")
            logger.info(
                "Copilot SDK connected",
                protocol_version=ping_response.get("protocolVersion"),
            )

            # Get status
            status = await self._client.get_status()
            logger.info("Copilot CLI status", version=status.get("version"))

            self._connected = True
            return True

        except FileNotFoundError:
            logger.error("GitHub Copilot CLI not found. Please install copilot CLI.")
            return False
        except Exception as e:
            logger.error("Failed to connect to Copilot SDK", error=str(e))
            return False

    @property
    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self._connected

    async def _handle_permission_request(
        self, request: PermissionRequest, context: dict
    ) -> PermissionRequestResult:
        """Handle permission requests from Copilot."""
        if self._confirmation_handler:
            # Map SDK permission request to our confirmation handler
            from .confirmation import ActionSeverity

            severity = ActionSeverity.MEDIUM
            if request.get("kind") in ["write", "shell"]:
                severity = ActionSeverity.HIGH

            confirmed = await self._confirmation_handler.request_confirmation(
                action_name=f"permission_{request.get('kind', 'unknown')}",
                description=f"Copilot requests permission: {request.get('kind')}",
                severity=severity,
                details=request,
            )

            if confirmed:
                return {"kind": "approved"}
            else:
                return {"kind": "denied-interactively-by-user"}

        # Default: deny if no handler
        return {"kind": "denied-no-approval-rule-and-could-not-request-from-user"}

    async def _create_session(self) -> CopilotSession:
        """Create a new Copilot session with tools."""
        if not self._client:
            raise ConnectionError("Client not connected")

        # Rebuild SDK tools list from current tool definitions
        sdk_tools = []
        for tool_def in self._tool_definitions.values():
            # Create async handler wrapper
            async def make_handler(definition: ToolDefinition):
                async def handler(invocation):
                    params = invocation.get("arguments", {})
                    try:
                        if asyncio.iscoroutinefunction(definition.handler):
                            result = await definition.handler(params)
                        else:
                            result = definition.handler(params)
                        return str(result) if result is not None else "Success"
                    except Exception as e:
                        logger.error("Tool execution failed", tool=definition.name, error=str(e))
                        return f"Error: {str(e)}"

                return handler

            handler = await make_handler(tool_def)
            sdk_tool = Tool(
                name=tool_def.name,
                description=tool_def.description,
                parameters=tool_def.parameters,
                handler=handler,
            )
            sdk_tools.append(sdk_tool)

        session = await self._client.create_session({
            "model": self._selected_model,
            "tools": sdk_tools,
            "streaming": True,
            "on_permission_request": self._handle_permission_request,
            "system_message": {
                "mode": "append",
                "content": """You are a Windows system management assistant. You help users manage their Windows system including windows, files, applications, processes, clipboard, Excel, and Outlook.

When you need to perform system operations, use the available tools. Always explain what you're doing and provide clear results.

Be helpful, concise, and proactive in suggesting relevant actions.""",
            },
        })
        logger.debug("Created session with model", model=self._selected_model)

        return session

    async def send_message(self, content: str):
        """Send a message and stream the response.

        This method processes the user message, creates a session if needed,
        sends to Copilot, and yields response tokens via callbacks.
        """
        user_message = Message(role="user", content=content)
        self._messages.append(user_message)

        if self._on_message_callback:
            self._on_message_callback(user_message)

        if not self._connected:
            # Fallback mode
            response_text = self._fallback_response(content)
            assistant_message = Message(role="assistant", content=response_text)
            self._messages.append(assistant_message)

            if self._on_message_callback:
                self._on_message_callback(assistant_message)

            if self._on_stream_callback:
                self._on_stream_callback(response_text)

            yield response_text
            return

        try:
            # Create a fresh session for each conversation turn
            session = await self._create_session()

            # Collect response
            response_parts = []
            done = asyncio.Event()

            def on_event(event: SessionEvent):
                nonlocal response_parts

                if event.type == SessionEventType.ASSISTANT_MESSAGE_DELTA:
                    # Streaming chunk
                    delta = getattr(event.data, "delta_content", "") or ""
                    if delta:
                        response_parts.append(delta)
                        if self._on_stream_callback:
                            self._on_stream_callback(delta)

                elif event.type == SessionEventType.ASSISTANT_MESSAGE:
                    # Final message
                    final_content = getattr(event.data, "content", "")
                    if final_content and not response_parts:
                        # No streaming, use final content
                        response_parts.append(final_content)
                        if self._on_stream_callback:
                            self._on_stream_callback(final_content)

                elif event.type == SessionEventType.SESSION_IDLE:
                    done.set()

                elif event.type == SessionEventType.SESSION_ERROR:
                    error_msg = getattr(event.data, "message", str(event.data))
                    logger.error("Session error", error=error_msg)
                    response_parts.append(f"Error: {error_msg}")
                    done.set()

            # Subscribe to events
            unsubscribe = session.on(on_event)

            try:
                # Send message
                await session.send({"prompt": content})

                # Wait for completion with timeout
                await asyncio.wait_for(done.wait(), timeout=120.0)

            except asyncio.TimeoutError:
                logger.warning("Session timeout waiting for response")
                if not response_parts:
                    response_parts.append("Request timed out. Please try again.")
            finally:
                unsubscribe()
                await session.destroy()

            # Build final response
            response_text = "".join(response_parts)

            if not response_text:
                response_text = "I received your message but couldn't generate a response. Please try again."

            assistant_message = Message(role="assistant", content=response_text)
            self._messages.append(assistant_message)

            if self._on_message_callback:
                self._on_message_callback(assistant_message)

            yield response_text

        except Exception as e:
            logger.error("Error in send_message", error=str(e))
            error_response = f"An error occurred: {str(e)}"

            assistant_message = Message(role="assistant", content=error_response)
            self._messages.append(assistant_message)

            if self._on_message_callback:
                self._on_message_callback(assistant_message)

            if self._on_stream_callback:
                self._on_stream_callback(error_response)

            yield error_response

    def _fallback_response(self, user_message: str) -> str:
        """Generate a response using local tool execution when Copilot is unavailable."""
        message_lower = user_message.lower()

        if "list" in message_lower and "window" in message_lower:
            return "I'll list the open windows for you. [Tool: list_windows]"
        elif "list" in message_lower and "process" in message_lower:
            return "I'll list the running processes. [Tool: list_processes]"
        elif "list" in message_lower and "file" in message_lower:
            return "I'll list the files in the current directory. [Tool: list_files]"
        elif "system" in message_lower and "stat" in message_lower:
            return "I'll get the system statistics. [Tool: get_system_stats]"
        elif "clipboard" in message_lower:
            if "set" in message_lower or "copy" in message_lower:
                return "I can copy content to the clipboard. [Tool: set_clipboard]"
            return "I'll check the clipboard contents. [Tool: get_clipboard]"
        elif "inbox" in message_lower or "email" in message_lower:
            return "I'll check your inbox. [Tool: read_inbox]"

        return f"I understand you want help with: {user_message}. I have tools available for window management, file operations, process control, clipboard, Excel, and Outlook. However, the Copilot service is currently unavailable. Please check your connection and try again."

    def get_history(self) -> list[Message]:
        """Get conversation history."""
        return self._messages.copy()

    def clear_history(self):
        """Clear conversation history."""
        self._messages.clear()

    async def disconnect(self):
        """Disconnect from the Copilot SDK."""
        if self._session:
            try:
                await self._session.destroy()
            except Exception:
                pass
            self._session = None

        if self._client:
            try:
                await self._client.stop()
            except Exception:
                pass
            self._client = None

        self._connected = False
        logger.info("Disconnected from Copilot SDK")


# Backwards compatibility alias
CopilotClient = CopilotClientWrapper
