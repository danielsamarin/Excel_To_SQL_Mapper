"""Core module for Copilot Windows Manager."""

from .client import (
    CopilotClient,
    CopilotClientWrapper,
    Message,
    ToolDefinition,
    AVAILABLE_MODELS,
    DEFAULT_MODEL,
)
from .confirmation import ConfirmationHandler, ActionSeverity
from .exceptions import (
    CopilotError,
    ToolExecutionError,
    ConfirmationDeniedError,
    ConnectionError,
)

__all__ = [
    "CopilotClient",
    "CopilotClientWrapper",
    "Message",
    "ToolDefinition",
    "AVAILABLE_MODELS",
    "DEFAULT_MODEL",
    "ConfirmationHandler",
    "ActionSeverity",
    "CopilotError",
    "ToolExecutionError",
    "ConfirmationDeniedError",
    "ConnectionError",
]
