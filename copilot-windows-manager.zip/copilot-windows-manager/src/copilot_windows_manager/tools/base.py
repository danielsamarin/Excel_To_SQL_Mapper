"""Base classes and utilities for tool implementations."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Generic, TypeVar
from pydantic import BaseModel

from ..core.confirmation import ConfirmationHandler

# Import SDK types for interoperability
from copilot import Tool as SDKTool, define_tool as sdk_define_tool, ToolResult as SDKToolResult


T = TypeVar("T", bound=BaseModel)


@dataclass
class ToolResult:
    """Result of a tool execution."""

    success: bool
    data: Any = None
    error: str | None = None
    message: str | None = None

    def to_string(self) -> str:
        """Convert result to human-readable string."""
        if self.error:
            return f"Error: {self.error}"
        if self.message:
            return self.message
        if self.data is not None:
            if isinstance(self.data, (list, dict)):
                import json
                return json.dumps(self.data, indent=2, default=str)
            return str(self.data)
        return "Operation completed successfully."

    def to_sdk_result(self) -> SDKToolResult:
        """Convert to SDK ToolResult format."""
        return SDKToolResult(
            textResultForLlm=self.to_string(),
            resultType="success" if self.success else "failure",
            error=self.error,
        )


class BaseTool(ABC, Generic[T]):
    """Base class for all tools."""

    name: str
    description: str
    param_model: type[T]

    def __init__(self, confirmation_handler: ConfirmationHandler | None = None):
        self._confirmation_handler = confirmation_handler

    @abstractmethod
    async def execute(self, params: T) -> ToolResult:
        """Execute the tool with the given parameters."""
        pass

    def get_parameters_schema(self) -> dict:
        """Get the JSON schema for the tool parameters."""
        return self.param_model.model_json_schema()

    async def __call__(self, params: dict) -> str:
        """Call the tool with a params dict, returning a string result."""
        try:
            validated_params = self.param_model.model_validate(params)
            result = await self.execute(validated_params)
            return result.to_string()
        except Exception as e:
            return f"Error executing {self.name}: {str(e)}"

    def to_sdk_tool(self) -> SDKTool:
        """Convert this tool to an SDK Tool instance."""
        async def handler(invocation):
            params = invocation.get("arguments", {})
            result_str = await self(params)
            return result_str

        return SDKTool(
            name=self.name,
            description=self.description,
            parameters=self.get_parameters_schema(),
            handler=handler,
        )


class EmptyParams(BaseModel):
    """Empty parameters model for tools that don't require parameters."""

    pass


def create_sdk_tool(
    name: str,
    description: str,
    param_model: type[BaseModel],
    handler,
    confirmation_handler: ConfirmationHandler | None = None,
) -> SDKTool:
    """Create an SDK Tool from a handler function.

    This is a convenience function for creating SDK tools without subclassing BaseTool.

    Args:
        name: Tool name
        description: Tool description
        param_model: Pydantic model for parameters
        handler: Async or sync function that takes validated params
        confirmation_handler: Optional confirmation handler

    Returns:
        SDK Tool instance
    """
    import asyncio

    async def wrapped_handler(invocation):
        params = invocation.get("arguments", {})
        try:
            validated = param_model.model_validate(params)
            if asyncio.iscoroutinefunction(handler):
                result = await handler(validated)
            else:
                result = handler(validated)

            if isinstance(result, ToolResult):
                return result.to_string()
            return str(result) if result is not None else "Success"
        except Exception as e:
            return f"Error: {str(e)}"

    return SDKTool(
        name=name,
        description=description,
        parameters=param_model.model_json_schema(),
        handler=wrapped_handler,
    )
