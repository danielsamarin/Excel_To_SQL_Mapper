"""Tools module for Copilot Windows Manager."""

from .base import ToolResult, BaseTool, EmptyParams, create_sdk_tool
from .registry import ToolRegistry, register_all_tools

# Re-export SDK types for convenience
from copilot import Tool as SDKTool, define_tool

__all__ = [
    "ToolResult",
    "BaseTool",
    "EmptyParams",
    "create_sdk_tool",
    "ToolRegistry",
    "register_all_tools",
    "SDKTool",
    "define_tool",
]
