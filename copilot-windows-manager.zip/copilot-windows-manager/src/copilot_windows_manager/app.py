"""Main NiceGUI application using GitHub Copilot SDK."""

import asyncio
from typing import Optional

from nicegui import ui, app

import structlog

from .core.client import CopilotClient
from .core.confirmation import ConfirmationHandler
from .tools import register_all_tools, ToolRegistry
from .ui.chat import ChatInterface
from .ui.layout import create_layout

logger = structlog.get_logger()

_app_instance: Optional["CopilotApp"] = None


def get_app_instance() -> Optional["CopilotApp"]:
    """Get the current app instance."""
    return _app_instance


class CopilotApp:
    """Main application class using GitHub Copilot SDK."""

    def __init__(self):
        global _app_instance
        _app_instance = self

        self.confirmation_handler = ConfirmationHandler()
        self.client = CopilotClient(self.confirmation_handler)
        self.tool_registry: ToolRegistry | None = None
        self.chat_interface = ChatInterface()
        self._status_label = None
        self._shutdown_event = asyncio.Event()

        self.confirmation_handler.set_request_callback(self._on_confirmation_request)
        self.chat_interface.set_on_send(self._on_user_message)

    def _on_confirmation_request(self, request):
        """Handle new confirmation requests."""
        self.chat_interface.add_confirmation_request(request)

    async def _on_user_message(self, content: str):
        """Handle user messages."""
        self.chat_interface.add_message("user", content)
        self.chat_interface.set_processing(True)

        try:
            response_parts = []
            async for chunk in self.client.send_message(content):
                response_parts.append(chunk)

            full_response = "".join(response_parts)

            # Remove duplicate assistant messages
            self.chat_interface._messages = [
                m for m in self.chat_interface._messages
                if m.role != "assistant" or m.content != full_response
            ]
            self.chat_interface.add_message("assistant", full_response)

        except Exception as e:
            logger.error("Error processing message", error=str(e))
            self.chat_interface.add_message("system", f"Error: {str(e)}")
        finally:
            self.chat_interface.set_processing(False)

    async def initialize(self):
        """Initialize the application and connect to Copilot SDK."""
        logger.info("Initializing Copilot Windows Manager with SDK")

        # Register all tools
        self.tool_registry = register_all_tools(self.confirmation_handler)
        logger.info("Registered tools", count=len(self.tool_registry.all()))

        # Register tools with the client
        self.tool_registry.register_with_client(self.client)

        # Connect to Copilot SDK
        connected = await self.client.connect()

        if self._status_label:
            if connected:
                self._status_label._update_status("Connected to Copilot", True)
            else:
                self._status_label._update_status("Offline (Local Mode)", False)

        if connected:
            logger.info("Successfully connected to GitHub Copilot SDK")
        else:
            logger.warning("Running in offline mode - Copilot SDK unavailable")

        logger.info("Initialization complete", connected=connected)

    async def shutdown(self):
        """Gracefully shutdown the application."""
        logger.info("Shutting down Copilot Windows Manager")

        # Disconnect from SDK
        await self.client.disconnect()

        self._shutdown_event.set()
        logger.info("Shutdown complete")

    def _on_model_change(self, model: str):
        """Handle model selection change."""
        from .core import AVAILABLE_MODELS
        self.client.selected_model = model
        model_display = {m[0]: m[1] for m in AVAILABLE_MODELS}
        display_name = model_display.get(model, model)
        self.chat_interface.add_message("system", f"Switched to {display_name}")

    def create_ui(self):
        """Create the application UI."""
        create_layout(
            chat_interface=self.chat_interface,
            tool_registry=self.tool_registry or ToolRegistry(),
            connection_status="Connecting to Copilot...",
            on_model_change=self._on_model_change,
            initial_model=self.client.selected_model,
        )

        async def init():
            await self.initialize()

        ui.timer(0.1, init, once=True)


def create_app() -> CopilotApp:
    """Create and configure the application."""
    copilot_app = CopilotApp()

    # Pre-register tools before UI is created
    copilot_app.tool_registry = register_all_tools(copilot_app.confirmation_handler)
    copilot_app.tool_registry.register_with_client(copilot_app.client)

    @ui.page("/")
    def main_page():
        copilot_app.create_ui()

    # Register shutdown handler
    @app.on_shutdown
    async def on_shutdown():
        await copilot_app.shutdown()

    return copilot_app
