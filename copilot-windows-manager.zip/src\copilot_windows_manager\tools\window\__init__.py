"""Window management tools using pywinctl."""

from pydantic import BaseModel, Field
from typing import Optional
import pywinctl as pwc

from ..base import BaseTool, ToolResult, EmptyParams
from ...core.confirmation import ConfirmationHandler, ActionSeverity, requires_confirmation


class ListWindowsParams(EmptyParams):
    """Parameters for list_windows tool."""
    pass


class FocusWindowParams(BaseModel):
    """Parameters for focus_window tool."""
    title: str = Field(description="Window title or partial match")


class MoveWindowParams(BaseModel):
    """Parameters for move_window tool."""
    title: str = Field(description="Window title or partial match")
    x: int = Field(description="New X position")
    y: int = Field(description="New Y position")


class ResizeWindowParams(BaseModel):
    """Parameters for resize_window tool."""
    title: str = Field(description="Window title or partial match")
    width: int = Field(description="New width")
    height: int = Field(description="New height")


class ChangeWindowStateParams(BaseModel):
    """Parameters for change_window_state tool."""
    title: str = Field(description="Window title or partial match")
    state: str = Field(description="Target state: minimize, maximize, or restore")


class CloseWindowParams(BaseModel):
    """Parameters for close_window tool."""
    title: str = Field(description="Window title or partial match")


def _find_window(title: str):
    """Find a window by title (partial match)."""
    windows = pwc.getWindowsWithTitle(title)
    return windows[0] if windows else None


class ListWindowsTool(BaseTool[ListWindowsParams]):
    name = "list_windows"
    description = "List all open windows with their titles, positions, and sizes"
    param_model = ListWindowsParams

    async def execute(self, params: ListWindowsParams) -> ToolResult:
        try:
            windows = pwc.getAllWindows()
            window_list = []
            for win in windows:
                try:
                    if win.title:
                        window_list.append({
                            "title": win.title,
                            "position": {"x": win.left, "y": win.top},
                            "size": {"width": win.width, "height": win.height},
                            "is_minimized": win.isMinimized,
                            "is_maximized": win.isMaximized,
                        })
                except Exception:
                    continue
            return ToolResult(success=True, data=window_list, message=f"Found {len(window_list)} windows")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class FocusWindowTool(BaseTool[FocusWindowParams]):
    name = "focus_window"
    description = "Bring a window to the foreground by its title"
    param_model = FocusWindowParams

    async def execute(self, params: FocusWindowParams) -> ToolResult:
        try:
            window = _find_window(params.title)
            if not window:
                return ToolResult(success=False, error=f"Window '{params.title}' not found")
            window.activate()
            return ToolResult(success=True, message=f"Focused window: {window.title}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class MoveWindowTool(BaseTool[MoveWindowParams]):
    name = "move_window"
    description = "Move a window to a specific position"
    param_model = MoveWindowParams

    async def execute(self, params: MoveWindowParams) -> ToolResult:
        try:
            window = _find_window(params.title)
            if not window:
                return ToolResult(success=False, error=f"Window '{params.title}' not found")
            window.moveTo(params.x, params.y)
            return ToolResult(success=True, message=f"Moved '{window.title}' to ({params.x}, {params.y})")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ResizeWindowTool(BaseTool[ResizeWindowParams]):
    name = "resize_window"
    description = "Resize a window to specific dimensions"
    param_model = ResizeWindowParams

    async def execute(self, params: ResizeWindowParams) -> ToolResult:
        try:
            window = _find_window(params.title)
            if not window:
                return ToolResult(success=False, error=f"Window '{params.title}' not found")
            window.resizeTo(params.width, params.height)
            return ToolResult(success=True, message=f"Resized '{window.title}' to {params.width}x{params.height}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class ChangeWindowStateTool(BaseTool[ChangeWindowStateParams]):
    name = "change_window_state"
    description = "Minimize, maximize, or restore a window"
    param_model = ChangeWindowStateParams

    async def execute(self, params: ChangeWindowStateParams) -> ToolResult:
        try:
            window = _find_window(params.title)
            if not window:
                return ToolResult(success=False, error=f"Window '{params.title}' not found")

            state = params.state.lower()
            if state == "minimize":
                window.minimize()
            elif state == "maximize":
                window.maximize()
            elif state == "restore":
                window.restore()
            else:
                return ToolResult(success=False, error=f"Invalid state: {state}. Use minimize, maximize, or restore.")

            return ToolResult(success=True, message=f"Changed '{window.title}' state to {state}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class CloseWindowTool(BaseTool[CloseWindowParams]):
    name = "close_window"
    description = "Close a window by its title"
    param_model = CloseWindowParams
    _requires_confirmation = True

    async def execute(self, params: CloseWindowParams) -> ToolResult:
        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="close_window",
                description=f"Close window matching '{params.title}'",
                severity=ActionSeverity.HIGH,
                details={"title": params.title},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            window = _find_window(params.title)
            if not window:
                return ToolResult(success=False, error=f"Window '{params.title}' not found")
            title = window.title
            window.close()
            return ToolResult(success=True, message=f"Closed window: {title}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_window_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all window management tools."""
    return [
        ListWindowsTool(confirmation_handler),
        FocusWindowTool(confirmation_handler),
        MoveWindowTool(confirmation_handler),
        ResizeWindowTool(confirmation_handler),
        ChangeWindowStateTool(confirmation_handler),
        CloseWindowTool(confirmation_handler),
    ]
