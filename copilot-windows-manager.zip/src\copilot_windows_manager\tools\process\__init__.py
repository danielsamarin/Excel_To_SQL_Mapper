"""Process management tools using psutil."""

import psutil
from pydantic import BaseModel, Field

from ..base import BaseTool, ToolResult, EmptyParams
from ...core.confirmation import ConfirmationHandler, ActionSeverity


class ListProcessesParams(BaseModel):
    """Parameters for list_processes tool."""
    sort_by: str = Field(default="memory", description="Sort by: memory, cpu, or name")
    limit: int = Field(default=20, description="Maximum number of processes to return")


class GetProcessInfoParams(BaseModel):
    """Parameters for get_process_info tool."""
    pid: int = Field(description="Process ID")


class KillProcessParams(BaseModel):
    """Parameters for kill_process tool."""
    pid: int = Field(description="Process ID to terminate")
    force: bool = Field(default=False, description="Force kill (SIGKILL) instead of graceful termination")


class GetSystemStatsParams(EmptyParams):
    """Parameters for get_system_stats tool."""
    pass


class ListProcessesTool(BaseTool[ListProcessesParams]):
    name = "list_processes"
    description = "List running processes with CPU and memory usage"
    param_model = ListProcessesParams

    async def execute(self, params: ListProcessesParams) -> ToolResult:
        try:
            processes = []
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
                try:
                    info = proc.info
                    processes.append({
                        "pid": info["pid"],
                        "name": info["name"],
                        "cpu_percent": info["cpu_percent"] or 0,
                        "memory_percent": round(info["memory_percent"] or 0, 2),
                        "status": info["status"],
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            if params.sort_by == "memory":
                processes.sort(key=lambda x: x["memory_percent"], reverse=True)
            elif params.sort_by == "cpu":
                processes.sort(key=lambda x: x["cpu_percent"], reverse=True)
            else:
                processes.sort(key=lambda x: x["name"].lower())

            processes = processes[: params.limit]

            return ToolResult(
                success=True,
                data=processes,
                message=f"Showing top {len(processes)} processes by {params.sort_by}",
            )
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class GetProcessInfoTool(BaseTool[GetProcessInfoParams]):
    name = "get_process_info"
    description = "Get detailed information about a specific process"
    param_model = GetProcessInfoParams

    async def execute(self, params: GetProcessInfoParams) -> ToolResult:
        try:
            proc = psutil.Process(params.pid)

            with proc.oneshot():
                info = {
                    "pid": proc.pid,
                    "name": proc.name(),
                    "exe": proc.exe(),
                    "cwd": proc.cwd(),
                    "status": proc.status(),
                    "username": proc.username(),
                    "create_time": proc.create_time(),
                    "cpu_percent": proc.cpu_percent(),
                    "memory_info": {
                        "rss": proc.memory_info().rss,
                        "vms": proc.memory_info().vms,
                    },
                    "memory_percent": round(proc.memory_percent(), 2),
                    "num_threads": proc.num_threads(),
                    "cmdline": proc.cmdline(),
                }

            return ToolResult(success=True, data=info)
        except psutil.NoSuchProcess:
            return ToolResult(success=False, error=f"Process {params.pid} not found")
        except psutil.AccessDenied:
            return ToolResult(success=False, error=f"Access denied to process {params.pid}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class KillProcessTool(BaseTool[KillProcessParams]):
    name = "kill_process"
    description = "Terminate a process by its PID"
    param_model = KillProcessParams
    _requires_confirmation = True

    async def execute(self, params: KillProcessParams) -> ToolResult:
        try:
            proc = psutil.Process(params.pid)
            proc_name = proc.name()
        except psutil.NoSuchProcess:
            return ToolResult(success=False, error=f"Process {params.pid} not found")
        except psutil.AccessDenied:
            return ToolResult(success=False, error=f"Access denied to process {params.pid}")

        if self._confirmation_handler:
            confirmed = await self._confirmation_handler.request_confirmation(
                action_name="kill_process",
                description=f"Terminate process: {proc_name} (PID: {params.pid})",
                severity=ActionSeverity.HIGH,
                details={"pid": params.pid, "name": proc_name, "force": params.force},
            )
            if not confirmed:
                return ToolResult(success=False, error="User denied confirmation")

        try:
            if params.force:
                proc.kill()
                action = "Force killed"
            else:
                proc.terminate()
                action = "Terminated"

            return ToolResult(success=True, message=f"{action} process: {proc_name} (PID: {params.pid})")
        except psutil.NoSuchProcess:
            return ToolResult(success=False, error=f"Process {params.pid} no longer exists")
        except psutil.AccessDenied:
            return ToolResult(success=False, error=f"Access denied to kill process {params.pid}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))


class GetSystemStatsTool(BaseTool[GetSystemStatsParams]):
    name = "get_system_stats"
    description = "Get system resource usage statistics (CPU, memory, disk)"
    param_model = GetSystemStatsParams

    async def execute(self, params: GetSystemStatsParams) -> ToolResult:
        try:
            cpu_percent = psutil.cpu_percent(interval=0.1)
            cpu_count = psutil.cpu_count()
            cpu_freq = psutil.cpu_freq()

            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            disks = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    disks.append({
                        "device": partition.device,
                        "mountpoint": partition.mountpoint,
                        "fstype": partition.fstype,
                        "total_gb": round(usage.total / (1024**3), 2),
                        "used_gb": round(usage.used / (1024**3), 2),
                        "free_gb": round(usage.free / (1024**3), 2),
                        "percent": usage.percent,
                    })
                except (PermissionError, OSError):
                    continue

            stats = {
                "cpu": {
                    "percent": cpu_percent,
                    "count": cpu_count,
                    "frequency_mhz": cpu_freq.current if cpu_freq else None,
                },
                "memory": {
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "used_gb": round(memory.used / (1024**3), 2),
                    "percent": memory.percent,
                },
                "swap": {
                    "total_gb": round(swap.total / (1024**3), 2),
                    "used_gb": round(swap.used / (1024**3), 2),
                    "percent": swap.percent,
                },
                "disks": disks,
            }

            return ToolResult(success=True, data=stats)
        except Exception as e:
            return ToolResult(success=False, error=str(e))


def get_process_tools(confirmation_handler: ConfirmationHandler | None = None) -> list[BaseTool]:
    """Get all process management tools."""
    return [
        ListProcessesTool(confirmation_handler),
        GetProcessInfoTool(confirmation_handler),
        KillProcessTool(confirmation_handler),
        GetSystemStatsTool(confirmation_handler),
    ]
