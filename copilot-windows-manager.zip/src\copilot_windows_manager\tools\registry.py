"""Tool registry for automatic discovery and registration."""

from typing import TYPE_CHECKING

from ..core.client import CopilotClient, ToolDefinition
from ..core.confirmation import ConfirmationHandler
from .base import BaseTool

if TYPE_CHECKING:
    pass


class ToolRegistry:
    """Registry for discovering and managing tools."""

    def __init__(self, confirmation_handler: ConfirmationHandler | None = None):
        self._tools: dict[str, BaseTool] = {}
        self._confirmation_handler = confirmation_handler

    def register(self, tool: BaseTool):
        """Register a tool instance."""
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name."""
        return self._tools.get(name)

    def all(self) -> list[BaseTool]:
        """Get all registered tools."""
        return list(self._tools.values())

    def register_with_client(self, client: CopilotClient):
        """Register all tools with a Copilot client."""
        for tool in self._tools.values():
            tool_def = ToolDefinition(
                name=tool.name,
                description=tool.description,
                parameters=tool.get_parameters_schema(),
                handler=tool,
                requires_confirmation=getattr(tool, "_requires_confirmation", False),
            )
            client.register_tool(tool_def)

    def get_by_category(self) -> dict[str, list[BaseTool]]:
        """Get tools organized by category."""
        categories: dict[str, list[BaseTool]] = {}
        for tool in self._tools.values():
            category = tool.name.split("_")[0] if "_" in tool.name else "general"
            if category not in categories:
                categories[category] = []
            categories[category].append(tool)
        return categories


def register_all_tools(
    confirmation_handler: ConfirmationHandler | None = None,
) -> ToolRegistry:
    """Register all available tools and return the registry."""
    registry = ToolRegistry(confirmation_handler)

    from .window import get_window_tools
    from .file import get_file_tools
    from .application import get_application_tools
    from .process import get_process_tools
    from .clipboard import get_clipboard_tools
    from .excel import get_excel_tools
    from .outlook import get_outlook_tools

    for tool in get_window_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_file_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_application_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_process_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_clipboard_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_excel_tools(confirmation_handler):
        registry.register(tool)

    for tool in get_outlook_tools(confirmation_handler):
        registry.register(tool)

    return registry
