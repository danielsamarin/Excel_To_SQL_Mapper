"""UI components for Copilot Windows Manager."""
