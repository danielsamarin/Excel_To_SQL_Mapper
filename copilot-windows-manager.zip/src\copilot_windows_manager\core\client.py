"""Copilot SDK client wrapper."""

import asyncio
import json
import subprocess
from dataclasses import dataclass, field
from typing import AsyncGenerator, Callable, Any

import structlog

from .exceptions import ConnectionError, ToolExecutionError
from .confirmation import ConfirmationHandler

logger = structlog.get_logger()


@dataclass
class Message:
    """A chat message."""

    role: str  # "user", "assistant", "system", "tool"
    content: str
    tool_calls: list[dict] | None = None
    tool_call_id: str | None = None
    name: str | None = None


@dataclass
class ToolDefinition:
    """Definition of an available tool."""

    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable
    requires_confirmation: bool = False


class CopilotClient:
    """Wrapper for GitHub Copilot interactions."""

    def __init__(self, confirmation_handler: ConfirmationHandler | None = None):
        self._tools: dict[str, ToolDefinition] = {}
        self._confirmation_handler = confirmation_handler
        self._connected = False
        self._messages: list[Message] = []
        self._on_message_callback: Callable[[Message], None] | None = None
        self._on_stream_callback: Callable[[str], None] | None = None

    def set_message_callback(self, callback: Callable[[Message], None]):
        """Set callback for new messages."""
        self._on_message_callback = callback

    def set_stream_callback(self, callback: Callable[[str], None]):
        """Set callback for streaming tokens."""
        self._on_stream_callback = callback

    def register_tool(self, tool_def: ToolDefinition):
        """Register a tool with the client."""
        self._tools[tool_def.name] = tool_def
        logger.info("Registered tool", tool_name=tool_def.name)

    def get_tools(self) -> list[ToolDefinition]:
        """Get all registered tools."""
        return list(self._tools.values())

    def get_tools_schema(self) -> list[dict]:
        """Get tools in OpenAI function calling schema format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for tool in self._tools.values()
        ]

    async def connect(self) -> bool:
        """Verify Copilot CLI is available and authenticated."""
        try:
            process = await asyncio.create_subprocess_exec(
                "gh", "copilot", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                self._connected = True
                logger.info("Copilot CLI connected", version=stdout.decode().strip())
                return True
            else:
                logger.error("Copilot CLI not available", error=stderr.decode())
                return False
        except FileNotFoundError:
            logger.error("GitHub CLI not found. Please install gh and gh copilot extension.")
            return False
        except Exception as e:
            logger.error("Failed to connect to Copilot", error=str(e))
            return False

    @property
    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self._connected

    async def send_message(self, content: str) -> AsyncGenerator[str, None]:
        """Send a message and stream the response.

        This method processes the user message, calls Copilot for a response,
        handles any tool calls, and yields response tokens.
        """
        user_message = Message(role="user", content=content)
        self._messages.append(user_message)

        if self._on_message_callback:
            self._on_message_callback(user_message)

        system_prompt = self._build_system_prompt()

        response_text = await self._call_copilot(system_prompt, content)

        tool_calls = self._extract_tool_calls(response_text)

        if tool_calls:
            tool_results = await self._execute_tool_calls(tool_calls)

            final_response = await self._call_copilot_with_tools(
                system_prompt, content, tool_calls, tool_results
            )
            response_text = final_response

        assistant_message = Message(role="assistant", content=response_text)
        self._messages.append(assistant_message)

        if self._on_message_callback:
            self._on_message_callback(assistant_message)

        for chunk in self._chunk_response(response_text):
            if self._on_stream_callback:
                self._on_stream_callback(chunk)
            yield chunk

    def _build_system_prompt(self) -> str:
        """Build the system prompt with tool descriptions."""
        tools_desc = "\n".join(
            f"- {t.name}: {t.description}" for t in self._tools.values()
        )
        return f"""You are a Windows system management assistant. You help users manage their Windows system including windows, files, applications, processes, clipboard, Excel, and Outlook.

Available tools:
{tools_desc}

To use a tool, respond with a JSON block like:
```tool
{{"tool": "tool_name", "params": {{"param1": "value1"}}}}
```

Always explain what you're doing and the results of tool executions."""

    async def _call_copilot(self, system_prompt: str, user_message: str) -> str:
        """Call Copilot CLI for a response."""
        full_prompt = f"{system_prompt}\n\nUser: {user_message}"

        try:
            process = await asyncio.create_subprocess_exec(
                "gh", "copilot", "suggest", "-t", "shell",
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate(input=full_prompt.encode())

            if process.returncode != 0:
                return await self._fallback_response(user_message)

            return stdout.decode().strip() or await self._fallback_response(user_message)
        except Exception as e:
            logger.error("Copilot call failed", error=str(e))
            return await self._fallback_response(user_message)

    async def _fallback_response(self, user_message: str) -> str:
        """Generate a response using local tool execution when Copilot is unavailable."""
        message_lower = user_message.lower()

        if "list" in message_lower and "window" in message_lower:
            return '```tool\n{"tool": "list_windows", "params": {}}\n```'
        elif "list" in message_lower and "process" in message_lower:
            return '```tool\n{"tool": "list_processes", "params": {}}\n```'
        elif "list" in message_lower and "file" in message_lower:
            return '```tool\n{"tool": "list_files", "params": {"path": "."}}\n```'
        elif "system" in message_lower and "stat" in message_lower:
            return '```tool\n{"tool": "get_system_stats", "params": {}}\n```'
        elif "clipboard" in message_lower:
            if "set" in message_lower or "copy" in message_lower:
                return '```tool\n{"tool": "set_clipboard", "params": {"content": ""}}\n```'
            return '```tool\n{"tool": "get_clipboard", "params": {}}\n```'
        elif "inbox" in message_lower or "email" in message_lower:
            return '```tool\n{"tool": "read_inbox", "params": {"count": 5}}\n```'

        return f"I understand you want help with: {user_message}. I have tools available for window management, file operations, process control, clipboard, Excel, and Outlook. What would you like me to do?"

    async def _call_copilot_with_tools(
        self,
        system_prompt: str,
        user_message: str,
        tool_calls: list[dict],
        tool_results: list[dict],
    ) -> str:
        """Call Copilot with tool results to get final response."""
        results_text = "\n".join(
            f"Tool {r['tool']}: {r['result']}" for r in tool_results
        )

        follow_up = f"""Based on the user request: {user_message}

Tool execution results:
{results_text}

Please provide a helpful summary of the results."""

        return await self._call_copilot(system_prompt, follow_up)

    def _extract_tool_calls(self, response: str) -> list[dict]:
        """Extract tool calls from response text."""
        tool_calls = []

        import re
        pattern = r'```tool\s*\n?(.*?)\n?```'
        matches = re.findall(pattern, response, re.DOTALL)

        for match in matches:
            try:
                tool_data = json.loads(match.strip())
                if "tool" in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                logger.warning("Failed to parse tool call", content=match)

        return tool_calls

    async def _execute_tool_calls(self, tool_calls: list[dict]) -> list[dict]:
        """Execute tool calls and return results."""
        results = []

        for call in tool_calls:
            tool_name = call.get("tool")
            params = call.get("params", {})

            if tool_name not in self._tools:
                results.append({
                    "tool": tool_name,
                    "result": f"Error: Tool '{tool_name}' not found",
                    "success": False,
                })
                continue

            tool_def = self._tools[tool_name]

            try:
                if asyncio.iscoroutinefunction(tool_def.handler):
                    result = await tool_def.handler(params)
                else:
                    result = tool_def.handler(params)

                results.append({
                    "tool": tool_name,
                    "result": result,
                    "success": True,
                })
            except Exception as e:
                logger.error("Tool execution failed", tool=tool_name, error=str(e))
                results.append({
                    "tool": tool_name,
                    "result": f"Error: {str(e)}",
                    "success": False,
                })

        return results

    def _chunk_response(self, text: str, chunk_size: int = 10) -> list[str]:
        """Split response into chunks for streaming simulation."""
        words = text.split()
        chunks = []
        current_chunk = []

        for word in words:
            current_chunk.append(word)
            if len(current_chunk) >= chunk_size:
                chunks.append(" ".join(current_chunk) + " ")
                current_chunk = []

        if current_chunk:
            chunks.append(" ".join(current_chunk))

        return chunks

    def get_history(self) -> list[Message]:
        """Get conversation history."""
        return self._messages.copy()

    def clear_history(self):
        """Clear conversation history."""
        self._messages.clear()
