"""Confirmation handler for destructive actions."""

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Any
from functools import wraps


class ActionSeverity(Enum):
    """Severity levels for actions requiring confirmation."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class ConfirmationRequest:
    """A pending confirmation request."""

    id: str
    action_name: str
    description: str
    severity: ActionSeverity
    details: dict[str, Any]
    future: asyncio.Future = field(default_factory=lambda: asyncio.get_event_loop().create_future())


class ConfirmationHandler:
    """Handles confirmation requests for destructive actions."""

    def __init__(self):
        self._pending: dict[str, ConfirmationRequest] = {}
        self._request_counter = 0
        self._on_request_callback: Callable[[ConfirmationRequest], None] | None = None

    def set_request_callback(self, callback: Callable[[ConfirmationRequest], None]):
        """Set callback to be invoked when a new confirmation is requested."""
        self._on_request_callback = callback

    async def request_confirmation(
        self,
        action_name: str,
        description: str,
        severity: ActionSeverity,
        details: dict[str, Any] | None = None,
    ) -> bool:
        """Request user confirmation for an action.

        Args:
            action_name: Name of the action requiring confirmation
            description: Human-readable description of what will happen
            severity: Severity level of the action
            details: Additional details about the action

        Returns:
            True if confirmed, False if denied
        """
        self._request_counter += 1
        request_id = f"confirm_{self._request_counter}"

        request = ConfirmationRequest(
            id=request_id,
            action_name=action_name,
            description=description,
            severity=severity,
            details=details or {},
        )

        self._pending[request_id] = request

        if self._on_request_callback:
            self._on_request_callback(request)

        try:
            result = await request.future
            return result
        finally:
            self._pending.pop(request_id, None)

    def confirm(self, request_id: str):
        """Confirm a pending request."""
        if request_id in self._pending:
            request = self._pending[request_id]
            if not request.future.done():
                request.future.set_result(True)

    def deny(self, request_id: str):
        """Deny a pending request."""
        if request_id in self._pending:
            request = self._pending[request_id]
            if not request.future.done():
                request.future.set_result(False)

    def get_pending(self) -> list[ConfirmationRequest]:
        """Get all pending confirmation requests."""
        return list(self._pending.values())


def requires_confirmation(
    severity: ActionSeverity,
    description_template: str,
    detail_keys: list[str] | None = None,
):
    """Decorator to mark a tool as requiring confirmation.

    Args:
        severity: Severity level of the action
        description_template: Template string for the description (uses params as format kwargs)
        detail_keys: Keys from params to include in details
    """

    def decorator(func):
        func._requires_confirmation = True
        func._confirmation_severity = severity
        func._confirmation_description_template = description_template
        func._confirmation_detail_keys = detail_keys or []

        @wraps(func)
        async def wrapper(self, params, *args, **kwargs):
            handler = getattr(self, "_confirmation_handler", None)
            if handler is None:
                return await func(self, params, *args, **kwargs)

            params_dict = params.model_dump() if hasattr(params, "model_dump") else params

            try:
                description = description_template.format(**params_dict)
            except KeyError:
                description = description_template

            details = {k: params_dict.get(k) for k in (detail_keys or []) if k in params_dict}

            confirmed = await handler.request_confirmation(
                action_name=func.__name__,
                description=description,
                severity=severity,
                details=details,
            )

            if not confirmed:
                from .exceptions import ConfirmationDeniedError

                raise ConfirmationDeniedError(func.__name__)

            return await func(self, params, *args, **kwargs)

        return wrapper

    return decorator
