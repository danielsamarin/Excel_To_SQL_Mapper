"""Custom exceptions for Copilot Windows Manager."""


class CopilotError(Exception):
    """Base exception for all Copilot-related errors."""

    pass


class ConnectionError(CopilotError):
    """Raised when connection to Copilot fails."""

    pass


class ToolExecutionError(CopilotError):
    """Raised when a tool fails to execute."""

    def __init__(self, tool_name: str, message: str, cause: Exception | None = None):
        self.tool_name = tool_name
        self.cause = cause
        super().__init__(f"Tool '{tool_name}' failed: {message}")


class ConfirmationDeniedError(CopilotError):
    """Raised when user denies a confirmation request."""

    def __init__(self, action_name: str):
        self.action_name = action_name
        super().__init__(f"User denied confirmation for action: {action_name}")


class ToolNotFoundError(CopilotError):
    """Raised when a requested tool is not found."""

    def __init__(self, tool_name: str):
        self.tool_name = tool_name
        super().__init__(f"Tool not found: {tool_name}")
