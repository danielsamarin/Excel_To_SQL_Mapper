"""Copilot Windows Manager - AI-powered Windows system management."""

__version__ = "0.1.0"
