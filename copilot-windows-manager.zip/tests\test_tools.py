"""Tests for tool implementations."""

import pytest
from copilot_windows_manager.tools.base import ToolResult, EmptyParams


def test_tool_result_success():
    """Test successful tool result."""
    result = ToolResult(success=True, data={"key": "value"})
    assert result.success is True
    assert result.error is None
    assert "key" in result.to_string()


def test_tool_result_error():
    """Test error tool result."""
    result = ToolResult(success=False, error="Something went wrong")
    assert result.success is False
    assert "Something went wrong" in result.to_string()


def test_tool_result_message():
    """Test tool result with message."""
    result = ToolResult(success=True, message="Operation completed")
    assert "Operation completed" in result.to_string()


def test_empty_params():
    """Test empty parameters model."""
    params = EmptyParams()
    assert params.model_dump() == {}
