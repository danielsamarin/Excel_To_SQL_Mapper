import type { CommandDefinition } from "@shared/contracts";

export const filterCommands = (commands: CommandDefinition[], query: string) => {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) {
    return commands;
  }

  return commands.filter((command) => {
    const haystack = [
      command.title,
      command.subtitle ?? "",
      ...(command.keywords ?? []),
      command.extensionId ?? ""
    ]
      .join(" ")
      .toLowerCase();

    return haystack.includes(normalizedQuery);
  });
};
