import { Toaster } from "sonner";

export function Sonner() {
  return (
    <Toaster
      closeButton
      position="bottom-right"
      richColors
      toastOptions={{
        classNames: {
          toast: "border border-border bg-popover text-popover-foreground shadow-2xl",
          description: "text-muted-foreground"
        }
      }}
    />
  );
}
