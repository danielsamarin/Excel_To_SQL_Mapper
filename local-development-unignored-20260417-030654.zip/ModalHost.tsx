import type { AppSettings, CommandExecutionPayload, NoteSummary } from "@shared/contracts";

import { BrowseNotesModal } from "@components/Modals/BrowseNotesModal";
import { ClipboardActionsModal } from "@components/Modals/ClipboardActionsModal";
import { ClipboardHistoryModal } from "@components/Modals/ClipboardHistoryModal";
import { CreateFolderModal } from "@components/Modals/CreateFolderModal";
import { CreateNoteModal } from "@components/Modals/CreateNoteModal";
import { ExtensionPromptModal } from "@components/Modals/ExtensionPromptModal";
import { SettingsModal } from "@components/Modals/SettingsModal";
import { ViewNoteModal } from "@components/Modals/ViewNoteModal";
import { Dialog } from "@components/UI/Dialog";
import type { ActiveModal } from "@/Types/Launcher";

interface ModalHostProps {
  activeModal: ActiveModal;
  isBusy: boolean;
  onClose: () => void;
  onOpenNote: (note: NoteSummary) => void;
  onReopenNotesBrowser: () => void;
  onRunCommand: (payload?: CommandExecutionPayload) => void;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
  settings: AppSettings;
}

export function ModalHost({
  activeModal,
  isBusy,
  onClose,
  onOpenNote,
  onReopenNotesBrowser,
  onRunCommand,
  onSaveSettings,
  settings
}: ModalHostProps) {
  if (!activeModal) {
    return null;
  }

  return (
    <Dialog open={Boolean(activeModal)} onOpenChange={(open) => (!open ? onClose() : undefined)}>
      {activeModal.type === "create-note" ? (
        <CreateNoteModal command={activeModal.command} isBusy={isBusy} onCancel={onClose} onSubmit={onRunCommand} />
      ) : null}
      {activeModal.type === "create-folder" ? (
        <CreateFolderModal
          command={activeModal.command}
          isBusy={isBusy}
          onCancel={onClose}
          onSubmit={onRunCommand}
          rootPath={settings.folderTemplateRootPath}
          subfolders={settings.folderTemplateSubfolders}
        />
      ) : null}
      {activeModal.type === "settings" ? (
        <SettingsModal
          command={activeModal.command}
          initialSettings={settings}
          onCancel={onClose}
          onSave={onSaveSettings}
        />
      ) : null}
      {activeModal.type === "browse-notes" ? (
        <BrowseNotesModal command={activeModal.command} onCancel={onClose} onSelectNote={onOpenNote} />
      ) : null}
      {activeModal.type === "clipboard-actions" ? (
        <ClipboardActionsModal
          command={activeModal.command}
          isBusy={isBusy}
          onCancel={onClose}
          onSubmit={onRunCommand}
        />
      ) : null}
      {activeModal.type === "clipboard-history" ? (
        <ClipboardHistoryModal command={activeModal.command} onCancel={onClose} />
      ) : null}
      {activeModal.type === "view-note" && "note" in activeModal ? (
        <ViewNoteModal
          command={activeModal.command}
          note={activeModal.note}
          onBack={onReopenNotesBrowser}
          onCancel={onClose}
        />
      ) : null}
      {activeModal.type === "extension-prompt" ? (
        <ExtensionPromptModal
          command={activeModal.command}
          isBusy={isBusy}
          onCancel={onClose}
          onSubmit={onRunCommand}
        />
      ) : null}
    </Dialog>
  );
}
