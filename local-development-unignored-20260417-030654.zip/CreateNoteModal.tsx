import { useState } from "react";
import type { CommandDefinition, CommandExecutionPayload } from "@shared/contracts";

import { Button } from "@components/UI/Button";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { Field, FieldGroup, FieldLabel } from "@components/UI/Field";
import { Input } from "@components/UI/Input";

interface CreateNoteModalProps {
  command: CommandDefinition;
  isBusy: boolean;
  onCancel: () => void;
  onSubmit: (payload?: CommandExecutionPayload) => void;
}

export function CreateNoteModal({ command, isBusy, onCancel, onSubmit }: CreateNoteModalProps) {
  const [title, setTitle] = useState("");

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>{command.subtitle ?? "Save a markdown note in your configured notes directory."}</DialogDescription>
      </DialogHeader>
      <div className="px-6 py-1">
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="note-title">Note title</FieldLabel>
            <Input
              autoFocus
              id="note-title"
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Sprint planning notes"
              value={title}
            />
          </Field>
        </FieldGroup>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button disabled={isBusy || !title.trim()} onClick={() => onSubmit({ title })}>
          {isBusy ? "Creating..." : "Create Note"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
