import { useState } from "react";
import type { AppSettings, CommandDefinition } from "@shared/contracts";
import { Code2, FolderTree, NotebookPen, Settings2, Workflow } from "lucide-react";

import { Button } from "@components/UI/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";
import { Checkbox } from "@components/UI/Checkbox";
import {
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@components/UI/Dialog";
import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldSet,
  FieldLegend
} from "@components/UI/Field";
import { Input } from "@components/UI/Input";
import { InputGroup, InputGroupAddon, InputGroupInput } from "@components/UI/InputGroup";
import { ScrollArea } from "@components/UI/ScrollArea";
import { Separator } from "@components/UI/Separator";
import { Textarea } from "@components/UI/Textarea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface SettingsModalProps {
  command: CommandDefinition;
  initialSettings: AppSettings;
  onCancel: () => void;
  onSave: (settings: AppSettings) => Promise<void>;
}

type SettingsSectionId = "general" | "notes" | "folders" | "developer";

const parseSubfolders = (value: string) => value.split("\n").map((entry) => entry.trim()).filter(Boolean);

const settingsSections = [
  {
    id: "general",
    title: "General",
    description: "Launcher behavior and global shortcuts.",
    icon: Settings2
  },
  {
    id: "notes",
    title: "Notes",
    description: "Choose where markdown notes should live.",
    icon: NotebookPen
  },
  {
    id: "folders",
    title: "Folder Templates",
    description: "Project roots and generated subfolders.",
    icon: FolderTree
  },
  {
    id: "developer",
    title: "Developer",
    description: "Diagnostics and future code workflows.",
    icon: Code2
  }
] as const satisfies ReadonlyArray<{
  id: SettingsSectionId;
  title: string;
  description: string;
  icon: typeof Settings2;
}>;

export function SettingsModal({ command, initialSettings, onCancel, onSave }: SettingsModalProps) {
  const [activeSection, setActiveSection] = useState<SettingsSectionId>("general");
  const [draft, setDraft] = useState<AppSettings>(initialSettings);

  const updateField = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setDraft((current) => ({ ...current, [key]: value }));
  };

  const browseFor = async (key: "notesRootPath" | "folderTemplateRootPath") => {
    const value = await getWorkLauncherApi()?.pickDirectory();
    if (value) {
      updateField(key, value);
    }
  };

  const currentSection =
    settingsSections.find((section) => section.id === activeSection) ?? settingsSections[0];

  return (
    <DialogContent className="overflow-hidden p-0 md:max-h-[560px] md:max-w-[860px]">
      <DialogTitle className="sr-only">{command.title}</DialogTitle>
      <DialogDescription className="sr-only">
        {command.subtitle ?? "Configure the launcher paths, hotkey, and development experience."}
      </DialogDescription>
      <div className="flex h-[min(80vh,35rem)] min-h-0 flex-col md:flex-row">
        <aside className="hidden w-72 shrink-0 border-r border-border bg-muted/20 md:flex md:flex-col">
          <DialogHeader className="border-b-0 pb-3">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl border border-border bg-background/80">
                <Workflow data-icon="inline-start" />
              </div>
              <div className="flex min-w-0 flex-col gap-1">
                <DialogTitle className="text-base">{command.title}</DialogTitle>
                <DialogDescription className="text-xs">
                  App preferences, paths, and developer tools.
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          <ScrollArea className="min-h-0 flex-1">
            <div className="flex flex-col gap-1 px-3 pb-4">
              {settingsSections.map((section) => {
                const Icon = section.icon;

                return (
                  <Button
                    key={section.id}
                    className="h-auto items-start justify-start gap-3 px-3 py-3 text-left"
                    onClick={() => setActiveSection(section.id)}
                    variant={activeSection === section.id ? "secondary" : "ghost"}
                  >
                    <Icon data-icon="inline-start" />
                    <div className="flex min-w-0 flex-col gap-1">
                      <span className="truncate text-sm font-medium">{section.title}</span>
                      <span className="line-clamp-2 text-xs text-muted-foreground">
                        {section.description}
                      </span>
                    </div>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>
        </aside>
        <main className="flex min-h-0 flex-1 flex-col">
          <header className="flex shrink-0 flex-col gap-3 border-b border-border px-6 py-5">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>{command.title}</span>
              <span>/</span>
              <span className="text-foreground">{currentSection.title}</span>
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="text-lg font-semibold text-foreground">{currentSection.title}</h2>
              <p className="text-sm text-muted-foreground">{currentSection.description}</p>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 md:hidden">
              {settingsSections.map((section) => {
                const Icon = section.icon;

                return (
                  <Button
                    key={section.id}
                    className="shrink-0"
                    onClick={() => setActiveSection(section.id)}
                    size="sm"
                    variant={activeSection === section.id ? "secondary" : "outline"}
                  >
                    <Icon data-icon="inline-start" />
                    {section.title}
                  </Button>
                );
              })}
            </div>
          </header>
          <ScrollArea className="min-h-0 flex-1">
            <div className="flex flex-col gap-6 p-6">
              {activeSection === "general" ? (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle>Global Shortcut</CardTitle>
                      <CardDescription>
                        Choose the launcher shortcut and basic runtime behavior.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <FieldGroup>
                        <Field>
                          <FieldLabel htmlFor="hotkey">Global hotkey</FieldLabel>
                          <Input
                            id="hotkey"
                            onChange={(event) => updateField("globalHotkey", event.target.value)}
                            value={draft.globalHotkey}
                          />
                          <FieldDescription>
                            Use Electron accelerator syntax like `Control+Alt+Space`.
                          </FieldDescription>
                        </Field>
                        <FieldSet>
                          <FieldLegend>Launcher Behavior</FieldLegend>
                          <label
                            htmlFor="auto-minimize-after-action"
                            className="flex cursor-pointer items-start gap-3 rounded-lg px-1 py-1"
                          >
                            <Checkbox
                              checked={draft.autoMinimizeAfterAction}
                              id="auto-minimize-after-action"
                              onCheckedChange={(checked) =>
                                updateField("autoMinimizeAfterAction", Boolean(checked))
                              }
                            />
                            <div className="flex flex-col gap-1">
                              <span className="text-sm font-medium text-foreground">
                                Auto minimize after actions
                              </span>
                              <FieldDescription>
                                Hide the launcher automatically after a command completes
                                successfully.
                              </FieldDescription>
                            </div>
                          </label>
                        </FieldSet>
                      </FieldGroup>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Workflow Authoring</CardTitle>
                      <CardDescription>
                        Control how the launcher exposes future automation-building features.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <FieldSet>
                        <FieldLegend>Preferences</FieldLegend>
                        <label
                          htmlFor="code-workflows"
                          className="flex cursor-pointer items-start gap-3 rounded-lg px-1 py-1"
                        >
                          <Checkbox
                            checked={draft.enableCodeWorkflows}
                            id="code-workflows"
                            onCheckedChange={(checked) =>
                              updateField("enableCodeWorkflows", Boolean(checked))
                            }
                          />
                          <div className="flex flex-col gap-1">
                            <span className="text-sm font-medium text-foreground">
                              Enable code workflows
                            </span>
                            <FieldDescription>
                              Reserved for future code-based automation authoring.
                            </FieldDescription>
                          </div>
                        </label>
                      </FieldSet>
                    </CardContent>
                  </Card>
                </>
              ) : null}

              {activeSection === "notes" ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Notes Directory</CardTitle>
                    <CardDescription>
                      Store markdown notes in a predictable local path.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FieldGroup>
                      <Field>
                        <FieldLabel htmlFor="notes-path">Notes root path</FieldLabel>
                        <InputGroup>
                          <InputGroupInput>
                            <Input
                              id="notes-path"
                              onChange={(event) => updateField("notesRootPath", event.target.value)}
                              placeholder="C:\\Notes"
                              value={draft.notesRootPath}
                            />
                          </InputGroupInput>
                          <InputGroupAddon>
                            <Button
                              onClick={() => void browseFor("notesRootPath")}
                              type="button"
                              variant="outline"
                            >
                              Browse
                            </Button>
                          </InputGroupAddon>
                        </InputGroup>
                        <FieldDescription>
                          New notes are saved as markdown files directly into this folder.
                        </FieldDescription>
                      </Field>
                    </FieldGroup>
                  </CardContent>
                </Card>
              ) : null}

              {activeSection === "folders" ? (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle>Template Root</CardTitle>
                      <CardDescription>
                        Choose where new project folders should be created.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <FieldGroup>
                        <Field>
                          <FieldLabel htmlFor="folder-root">Folder template root path</FieldLabel>
                          <InputGroup>
                            <InputGroupInput>
                              <Input
                                id="folder-root"
                                onChange={(event) =>
                                  updateField("folderTemplateRootPath", event.target.value)
                                }
                                placeholder="C:\\Development\\Projects"
                                value={draft.folderTemplateRootPath}
                              />
                            </InputGroupInput>
                            <InputGroupAddon>
                              <Button
                                onClick={() => void browseFor("folderTemplateRootPath")}
                                type="button"
                                variant="outline"
                              >
                                Browse
                              </Button>
                            </InputGroupAddon>
                          </InputGroup>
                        </Field>
                      </FieldGroup>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Generated Subfolders</CardTitle>
                      <CardDescription>
                        These folders will be created under each new project folder.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <FieldGroup>
                        <Field>
                          <FieldLabel htmlFor="subfolders">Subfolders</FieldLabel>
                          <Textarea
                            id="subfolders"
                            onChange={(event) =>
                              updateField(
                                "folderTemplateSubfolders",
                                parseSubfolders(event.target.value)
                              )
                            }
                            placeholder={"docs\nsrc\nassets"}
                            value={draft.folderTemplateSubfolders.join("\n")}
                          />
                          <FieldDescription>
                            One folder per line. These are created beneath the project folder.
                          </FieldDescription>
                        </Field>
                      </FieldGroup>
                    </CardContent>
                  </Card>
                </>
              ) : null}

              {activeSection === "developer" ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Developer Tools</CardTitle>
                    <CardDescription>
                      Show extension diagnostics and development-only controls.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    <FieldSet>
                      <FieldLegend>Flags</FieldLegend>
                      <label
                        htmlFor="developer-mode"
                        className="flex cursor-pointer items-start gap-3 rounded-lg px-1 py-1"
                      >
                        <Checkbox
                          checked={draft.developerMode}
                          id="developer-mode"
                          onCheckedChange={(checked) =>
                            updateField("developerMode", Boolean(checked))
                          }
                        />
                        <div className="flex flex-col gap-1">
                          <span className="text-sm font-medium text-foreground">
                            Developer mode
                          </span>
                          <FieldDescription>
                            Show extension diagnostics and reload tools.
                          </FieldDescription>
                        </div>
                      </label>
                    </FieldSet>
                    <Separator />
                    <div className="rounded-xl border border-border bg-muted/20 p-4">
                      <p className="text-sm font-medium text-foreground">What this unlocks</p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Developer mode surfaces extension diagnostics, reload actions, and future
                        SDK tooling inside the launcher.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ) : null}
            </div>
          </ScrollArea>
          <DialogFooter className="border-t border-border px-6 py-4">
            <Button onClick={onCancel} variant="ghost">
              Cancel
            </Button>
            <Button onClick={() => void onSave(draft)}>Save Settings</Button>
          </DialogFooter>
        </main>
      </div>
    </DialogContent>
  );
}
