import { useEffect, useMemo, useState } from "react";
import type { CommandDefinition, NoteFile, NoteSummary } from "@shared/contracts";
import { FileText, RefreshCw } from "lucide-react";

import { Button } from "@components/UI/Button";
import { Card, CardContent } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { ScrollArea } from "@components/UI/ScrollArea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface ViewNoteModalProps {
  command: CommandDefinition;
  note: NoteSummary;
  onBack: () => void;
  onCancel: () => void;
}

const formatModifiedAt = (modifiedAt: number) =>
  new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(modifiedAt));

export function ViewNoteModal({ command, note, onBack, onCancel }: ViewNoteModalProps) {
  const launcherApi = getWorkLauncherApi();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [noteFile, setNoteFile] = useState<NoteFile | null>(null);

  const loadNote = async () => {
    if (!launcherApi) {
      setError("Restart the Electron app to reload the desktop bridge.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const nextNote = await launcherApi.readNote(note.path);
      setNoteFile(nextNote);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadNote();
  }, [note.path]);

  const content = useMemo(() => {
    if (error) {
      return error;
    }

    if (isLoading) {
      return "Loading note...";
    }

    return noteFile?.content || "This note is empty.";
  }, [error, isLoading, noteFile?.content]);

  return (
    <DialogContent className="w-[min(96vw,52rem)]">
      <DialogHeader>
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl border border-border bg-background/70">
            <FileText data-icon="inline-start" />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <DialogTitle className="truncate">{note.title}</DialogTitle>
            <DialogDescription>
              {command.title} / {formatModifiedAt(note.modifiedAt)}
            </DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <ScrollArea className="max-h-[60vh] min-h-[20rem] px-6 py-1">
        <Card className="border-border/60 bg-background/40 shadow-none">
          <CardContent className="p-4">
            <pre className="whitespace-pre-wrap break-words font-[inherit] text-sm leading-6 text-foreground">
              {content}
            </pre>
          </CardContent>
        </Card>
      </ScrollArea>
      <DialogFooter>
        <Button onClick={onBack} variant="ghost">
          Back
        </Button>
        <Button disabled={isLoading} onClick={() => void loadNote()} variant="outline">
          Refresh
        </Button>
        <Button onClick={onCancel}>Close</Button>
      </DialogFooter>
    </DialogContent>
  );
}
