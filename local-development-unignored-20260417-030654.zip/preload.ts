import { contextBridge, ipcRenderer } from "electron";
import type {
  AppSettings,
  ClipboardHistoryEntry,
  CommandDefinition,
  CommandExecutionPayload,
  CommandExecutionResult,
  DevState,
  NoteFile,
  NoteSummary
} from "@shared/contracts";

contextBridge.exposeInMainWorld("workLauncher", {
  listCommands: (): Promise<CommandDefinition[]> => ipcRenderer.invoke("app:list-commands"),
  executeCommand: (
    commandId: string,
    payload?: CommandExecutionPayload
  ): Promise<CommandExecutionResult> => ipcRenderer.invoke("app:execute-command", commandId, payload),
  getSettings: (): Promise<AppSettings> => ipcRenderer.invoke("app:get-settings"),
  updateSettings: (settings: AppSettings): Promise<AppSettings> =>
    ipcRenderer.invoke("app:update-settings", settings),
  pickDirectory: (): Promise<string | null> => ipcRenderer.invoke("app:pick-directory"),
  getDevState: (): Promise<DevState> => ipcRenderer.invoke("app:get-dev-state"),
  hideLauncher: (): Promise<void> => ipcRenderer.invoke("app:hide-launcher"),
  quitApp: (): void => ipcRenderer.send("app:quit"),
  listNotes: (): Promise<NoteSummary[]> => ipcRenderer.invoke("app:list-notes"),
  readNote: (notePath: string): Promise<NoteFile> => ipcRenderer.invoke("app:read-note", notePath),
  getClipboardText: (): Promise<string> => ipcRenderer.invoke("app:get-clipboard-text"),
  setClipboardText: (text: string): Promise<void> => ipcRenderer.invoke("app:set-clipboard-text", text),
  listClipboardHistory: (): Promise<ClipboardHistoryEntry[]> => ipcRenderer.invoke("app:list-clipboard-history"),
  clearClipboardHistory: (): Promise<void> => ipcRenderer.invoke("app:clear-clipboard-history"),
  onStateChanged: (callback: () => void) => {
    const handler = () => callback();
    ipcRenderer.on("app:state-changed", handler);
    return () => ipcRenderer.removeListener("app:state-changed", handler);
  }
});
