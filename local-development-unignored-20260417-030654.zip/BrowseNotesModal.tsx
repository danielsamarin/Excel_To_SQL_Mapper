import { useEffect, useMemo, useState } from "react";
import type { CommandDefinition, NoteSummary } from "@shared/contracts";
import { FileText, RefreshCw } from "lucide-react";

import { Button } from "@components/UI/Button";
import { Card, CardContent } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { ScrollArea } from "@components/UI/ScrollArea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface BrowseNotesModalProps {
  command: CommandDefinition;
  onCancel: () => void;
  onSelectNote: (note: NoteSummary) => void;
}

const formatModifiedAt = (modifiedAt: number) =>
  new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(modifiedAt));

export function BrowseNotesModal({ command, onCancel, onSelectNote }: BrowseNotesModalProps) {
  const launcherApi = getWorkLauncherApi();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notes, setNotes] = useState<NoteSummary[]>([]);

  const loadNotes = async () => {
    if (!launcherApi) {
      setError("Restart the Electron app to reload the desktop bridge.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const nextNotes = await launcherApi.listNotes();
      setNotes(nextNotes);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadNotes();
  }, []);

  const emptyMessage = useMemo(() => {
    if (error) {
      return error;
    }

    if (!isLoading && notes.length === 0) {
      return "No markdown files were found in your configured notes directory.";
    }

    return null;
  }, [error, isLoading, notes.length]);

  return (
    <DialogContent className="w-[min(96vw,46rem)]">
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>
          {command.subtitle ?? "View markdown notes from your configured notes directory."}
        </DialogDescription>
      </DialogHeader>
      <ScrollArea className="max-h-[60vh] min-h-[18rem] px-6 py-1">
        <div className="flex flex-col gap-3 pb-4">
          {isLoading ? (
            <Card>
              <CardContent className="flex items-center gap-3 p-4 text-sm text-muted-foreground">
                <RefreshCw className="size-4 animate-spin" />
                Loading notes...
              </CardContent>
            </Card>
          ) : null}
          {emptyMessage ? (
            <Card>
              <CardContent className="p-4 text-sm text-muted-foreground">{emptyMessage}</CardContent>
            </Card>
          ) : null}
          {!isLoading && !emptyMessage
            ? notes.map((note) => (
                <Button
                  key={note.path}
                  className="h-auto justify-start gap-3 rounded-xl border border-border bg-background/60 px-4 py-4 text-left hover:bg-accent/70"
                  onClick={() => onSelectNote(note)}
                  variant="outline"
                >
                  <FileText data-icon="inline-start" />
                  <div className="flex min-w-0 flex-1 flex-col gap-1">
                    <span className="truncate text-sm font-medium text-foreground">{note.title}</span>
                    <span className="truncate text-xs text-muted-foreground">{note.name}</span>
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {formatModifiedAt(note.modifiedAt)}
                  </span>
                </Button>
              ))
            : null}
        </div>
      </ScrollArea>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button disabled={isLoading} onClick={() => void loadNotes()} variant="outline">
          Refresh
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
