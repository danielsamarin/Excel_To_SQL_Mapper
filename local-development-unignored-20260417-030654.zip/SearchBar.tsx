import type { KeyboardEventHandler, RefObject } from "react";

import { Settings2 } from "lucide-react";

import { Badge } from "@components/UI/Badge";
import { Button } from "@components/UI/Button";
import { CommandInput } from "@components/UI/Command";

interface SearchBarProps {
  inputRef: RefObject<HTMLInputElement | null>;
  onKeyDown: KeyboardEventHandler<HTMLInputElement>;
  onOpenSettings: () => void;
  onQueryChange: (value: string) => void;
  query: string;
}

export function SearchBar({
  inputRef,
  onKeyDown,
  onOpenSettings,
  onQueryChange,
  query
}: SearchBarProps) {
  return (
    <div className="drag-region relative border-b border-border">
      <CommandInput
        aria-label="Search commands"
        autoComplete="off"
        ref={inputRef}
        className="pr-36 text-base"
        name="launcher-search"
        onKeyDown={onKeyDown}
        onValueChange={onQueryChange}
        placeholder="Search commands, notes, folders, extensions..."
        value={query}
      />
      <div className="no-drag absolute top-1/2 right-4 flex -translate-y-1/2 items-center gap-2">
        <Button className="h-8 gap-2 px-3" onClick={onOpenSettings} size="sm" variant="ghost">
          <Settings2 data-icon="inline-start" className="size-4" />
          Quick Settings
        </Button>
        <Badge variant="outline">Tab</Badge>
      </div>
    </div>
  );
}
