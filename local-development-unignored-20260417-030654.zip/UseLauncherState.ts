import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import type {
  AppSettings,
  CommandDefinition,
  CommandExecutionPayload,
  CommandExecutionResult,
  NoteSummary
} from "@shared/contracts";

import { useLauncherData } from "@/Hooks/UseLauncherData";
import { getWorkLauncherApi } from "@/Services/LauncherApi";
import { loadRecentCommands, recordRecentCommand, saveRecentCommands } from "@/Services/RecentCommands";
import type { ActiveModal, ModalType } from "@/Types/Launcher";
import { filterCommands } from "@/Utils/CommandSearch";
import { buildCommandSections } from "@/Utils/CommandSections";

const commandViewMap: Record<string, ModalType> = {
  "browse-notes": "browse-notes",
  "clipboard-actions": "clipboard-actions",
  "clipboard-history": "clipboard-history",
  "create-note": "create-note",
  "create-folder": "create-folder",
  settings: "settings",
  "extension-prompt": "extension-prompt"
};

const maxRecentCommands = 1;

export const useLauncherState = () => {
  const launcherApi = getWorkLauncherApi();
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [isBusy, setIsBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [recentCommandIds, setRecentCommandIds] = useState<string[]>(loadRecentCommands);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const { commands, refreshState, setSettings, settings } = useLauncherData({ inputRef, launcherApi });

  useEffect(() => inputRef.current?.focus(), [activeModal]);
  useEffect(() => saveRecentCommands(recentCommandIds), [recentCommandIds]);
  useEffect(() => setSelectedIndex(0), [commands, query]);

  const filteredCommands = useMemo(() => filterCommands(commands, query), [commands, query]);
  const sections = useMemo(
    () => buildCommandSections(filteredCommands, recentCommandIds),
    [filteredCommands, recentCommandIds]
  );
  const visibleCommands = useMemo(
    () => sections.flatMap((section) => section.items.map(({ command }) => command)),
    [sections]
  );

  const closeModal = () => setActiveModal(null);
  const selectedCommand = visibleCommands[selectedIndex];

  const hideLauncher = async () => {
    setActiveModal(null);
    setQuery("");
    await launcherApi?.hideLauncher();
  };

  const handleExecutionResult = async (result: CommandExecutionResult) => {
    if (!result.ok) {
      toast.error(result.title ?? "Command Failed", { description: result.message });
      return;
    }

    toast.success(result.title ?? "Success", { description: result.message });
    await refreshState();
    if (settings.autoMinimizeAfterAction) {
      await hideLauncher();
      return;
    }

    closeModal();
  };

  const runCommand = async (command: CommandDefinition, payload: CommandExecutionPayload = {}) => {
    if (!launcherApi) {
      toast.error("Desktop Bridge Missing", {
        description: "Restart the Electron app to reload the preload script."
      });
      return;
    }

    setIsBusy(true);
    try {
      const result = await launcherApi.executeCommand(command.id, payload);
      await handleExecutionResult(result);
    } finally {
      setIsBusy(false);
    }
  };

  const recordUsage = (commandId: string) => {
    setRecentCommandIds((current) => recordRecentCommand(commandId, current, maxRecentCommands));
  };

  const openSettings = () => {
    const settingsCommand = commands.find((command) => command.id === "builtin.open-settings");
    if (!settingsCommand) {
      return;
    }

    recordUsage(settingsCommand.id);
    setActiveModal({ type: "settings", command: settingsCommand });
  };

  const openNoteDetail = (note: NoteSummary) => {
    const notesCommand =
      commands.find((command) => command.id === "builtin.browse-notes") ?? activeModal?.command;

    if (!notesCommand) {
      return;
    }

    setActiveModal({ type: "view-note", command: notesCommand, note });
  };

  const reopenNotesBrowser = () => {
    const notesCommand = commands.find((command) => command.id === "builtin.browse-notes");
    if (!notesCommand) {
      return;
    }

    setActiveModal({ type: "browse-notes", command: notesCommand });
  };

  const handleCommandSelection = async (command: CommandDefinition) => {
    recordUsage(command.id);
    if (command.mode === "run") {
      await runCommand(command);
      return;
    }

    const modalType = command.viewId ? commandViewMap[command.viewId] : undefined;
    if (!modalType) {
      toast.error("Unsupported View", { description: command.title });
      return;
    }

    setActiveModal({ type: modalType, command });
  };

  const saveSettings = async (nextSettings: AppSettings) => {
    if (!launcherApi) {
      return;
    }

    setIsBusy(true);
    try {
      const savedSettings = await launcherApi.updateSettings(nextSettings);
      setSettings(savedSettings);
      toast.success("Settings Saved", { description: "Your launcher preferences were updated." });
      closeModal();
    } finally {
      setIsBusy(false);
    }
  };

  return {
    activeModal,
    closeModal,
    handleCommandSelection,
    hideLauncher,
    inputRef,
    isBusy,
    launcherApi,
    openSettings,
    openNoteDetail,
    query,
    reopenNotesBrowser,
    runCommand,
    sections,
    selectedCommand,
    selectedIndex,
    setQuery,
    setSelectedIndex,
    settings,
    saveSettings,
    visibleCommands
  };
};
