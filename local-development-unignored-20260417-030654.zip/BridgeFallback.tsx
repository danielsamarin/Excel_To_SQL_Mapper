import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";

export function BridgeFallback() {
  return (
    <div className="flex h-full w-full items-center justify-center p-6">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle>Desktop Bridge Not Available</CardTitle>
          <CardDescription>
            Restart the Electron dev process. The renderer loaded, but the preload bridge did not.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          The preload bridge did not attach, so launcher actions are unavailable in this session.
        </CardContent>
      </Card>
    </div>
  );
}
