import type { ReactNode } from "react";
import {
  Clipboard,
  Command,
  FolderTree,
  Globe,
  History,
  Monitor,
  NotebookPen,
  Puzzle,
  RefreshCw,
  Settings2,
  Sparkles
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import type { CommandDefinition } from "@shared/contracts";

const commandCategoryLabels: Record<string, string> = {
  "builtin.browse-notes": "Notes",
  "builtin.clipboard-actions": "Clipboard",
  "builtin.clipboard-history": "Clipboard",
  "builtin.create-folder-structure": "Workspace",
  "builtin.create-note": "Notes",
  "builtin.launch-chrome": "Browser",
  "builtin.open-settings": "App Settings",
  "builtin.open-windows-settings": "Windows Settings"
};

const commandIcons: Record<string, LucideIcon> = {
  "builtin.browse-notes": NotebookPen,
  "builtin.clipboard-actions": Clipboard,
  "builtin.clipboard-history": History,
  "builtin.create-folder-structure": FolderTree,
  "builtin.create-note": NotebookPen,
  "builtin.launch-chrome": Globe,
  "builtin.open-settings": Settings2,
  "builtin.open-windows-settings": Monitor,
  "builtin.reload-extensions": RefreshCw,
  "hello-world.say-hello": Sparkles
};

const applicationCommandIds = new Set(["builtin.launch-chrome", "builtin.open-windows-settings"]);

export const getCommandCategoryLabel = (command: CommandDefinition) => {
  return commandCategoryLabels[command.id] ?? (command.source === "extension" ? "Extension" : "Command");
};

export const getCommandRowLabel = (command: CommandDefinition) => {
  if (applicationCommandIds.has(command.id)) {
    return "Application";
  }

  return command.mode === "view" ? "Command" : "Action";
};

export const renderCommandIcon = (command: CommandDefinition): ReactNode => {
  if (command.iconDataUrl) {
    return <img className="size-5 object-contain" src={command.iconDataUrl} alt="" />;
  }

  const Icon = commandIcons[command.id] ?? (command.source === "extension" ? Puzzle : Command);
  return <Icon className="size-4.5" />;
};
