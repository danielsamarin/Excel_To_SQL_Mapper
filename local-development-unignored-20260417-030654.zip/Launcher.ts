import type {
  AppSettings,
  ClipboardHistoryEntry,
  CommandDefinition,
  CommandExecutionPayload,
  CommandExecutionResult,
  DevState,
  NoteFile,
  NoteSummary
} from "@shared/contracts";

export type ModalType =
  | "create-note"
  | "create-folder"
  | "settings"
  | "extension-prompt"
  | "browse-notes"
  | "clipboard-actions"
  | "clipboard-history"
  | "view-note";

export interface ModalCommandState {
  type: ModalType;
  command: CommandDefinition;
}

export interface ViewNoteModalState extends ModalCommandState {
  type: "view-note";
  note: NoteSummary;
}

export type ActiveModal = ModalCommandState | ViewNoteModalState | null;

export interface CommandSectionEntry {
  command: CommandDefinition;
  index: number;
}

export interface CommandSection {
  title: string;
  items: CommandSectionEntry[];
}

export interface WorkLauncherApi {
  listCommands: () => Promise<CommandDefinition[]>;
  executeCommand: (
    commandId: string,
    payload?: CommandExecutionPayload
  ) => Promise<CommandExecutionResult>;
  getSettings: () => Promise<AppSettings>;
  updateSettings: (settings: AppSettings) => Promise<AppSettings>;
  pickDirectory: () => Promise<string | null>;
  getDevState: () => Promise<DevState>;
  hideLauncher: () => Promise<void>;
  quitApp: () => void;
  listNotes: () => Promise<NoteSummary[]>;
  readNote: (notePath: string) => Promise<NoteFile>;
  getClipboardText: () => Promise<string>;
  setClipboardText: (text: string) => Promise<void>;
  listClipboardHistory: () => Promise<ClipboardHistoryEntry[]>;
  clearClipboardHistory: () => Promise<void>;
  onStateChanged: (callback: () => void) => () => void;
}

declare global {
  interface Window {
    workLauncher: WorkLauncherApi;
  }
}
