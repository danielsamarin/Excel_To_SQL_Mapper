import type { KeyboardEvent } from "react";

import type { CommandDefinition } from "@shared/contracts";

import type { ActiveModal } from "@/Types/Launcher";

interface UseRootInputKeyDownOptions {
  activeModal: ActiveModal;
  hideLauncher: () => Promise<void>;
  onSelectCommand: (command: CommandDefinition) => Promise<void>;
  selectedIndex: number;
  setSelectedIndex: (value: number | ((current: number) => number)) => void;
  visibleCommands: CommandDefinition[];
}

export const useRootInputKeyDown = ({
  activeModal,
  hideLauncher,
  onSelectCommand,
  selectedIndex,
  setSelectedIndex,
  visibleCommands
}: UseRootInputKeyDownOptions) => {
  return async (event: KeyboardEvent<HTMLInputElement>) => {
    if (activeModal) {
      return;
    }

    if (event.key === "ArrowDown") {
      event.preventDefault();
      setSelectedIndex((current) => Math.min(current + 1, Math.max(visibleCommands.length - 1, 0)));
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      setSelectedIndex((current) => Math.max(current - 1, 0));
    }

    if (event.key === "Enter") {
      event.preventDefault();
      const selectedCommand = visibleCommands[selectedIndex];
      if (selectedCommand) {
        await onSelectCommand(selectedCommand);
      }
    }

    if (event.key === "Escape") {
      event.preventDefault();
      await hideLauncher();
    }
  };
};
