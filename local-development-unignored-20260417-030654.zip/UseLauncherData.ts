import { useEffect, useState, type RefObject } from "react";

import type { AppSettings, CommandDefinition } from "@shared/contracts";
import { defaultAppSettings } from "@shared/contracts";

import type { WorkLauncherApi } from "@/Types/Launcher";

interface UseLauncherDataOptions {
  inputRef: RefObject<HTMLInputElement | null>;
  launcherApi: WorkLauncherApi | undefined;
}

export const useLauncherData = ({ inputRef, launcherApi }: UseLauncherDataOptions) => {
  const [commands, setCommands] = useState<CommandDefinition[]>([]);
  const [settings, setSettings] = useState<AppSettings>(defaultAppSettings);

  const refreshState = async () => {
    if (!launcherApi) {
      return;
    }

    const [nextCommands, nextSettings] = await Promise.all([
      launcherApi.listCommands(),
      launcherApi.getSettings()
    ]);
    setCommands(nextCommands);
    setSettings(nextSettings);
  };

  useEffect(() => {
    if (!launcherApi) {
      return;
    }

    void refreshState();
    const unsubscribe = launcherApi.onStateChanged(() => void refreshState());
    const handleFocus = () => inputRef.current?.focus();
    window.addEventListener("focus", handleFocus);
    return () => {
      unsubscribe();
      window.removeEventListener("focus", handleFocus);
    };
  }, []);

  return { commands, refreshState, setSettings, settings };
};
