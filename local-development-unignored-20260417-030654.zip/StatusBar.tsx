import { Badge } from "@components/UI/Badge";
import { Separator } from "@components/UI/Separator";

interface StatusBarProps {
  hotkey: string;
  subtitle?: string;
}

export function StatusBar({ hotkey, subtitle }: StatusBarProps) {
  return (
    <div className="flex items-center justify-between gap-4 border-t border-border px-4 py-3 text-xs text-muted-foreground">
      <div className="flex items-center gap-3">
        <span>Enter to run</span>
        <Separator orientation="vertical" className="h-3" />
        <span>Esc to hide</span>
        <Separator orientation="vertical" className="h-3" />
        <span>Arrow keys to move</span>
        <Separator orientation="vertical" className="h-3" />
        <span>Ctrl+Q to exit</span>
      </div>
      <span className="min-w-0 flex-1 truncate text-center">{subtitle ?? "Launcher ready"}</span>
      <Badge variant="outline">Hotkey {hotkey}</Badge>
    </div>
  );
}
