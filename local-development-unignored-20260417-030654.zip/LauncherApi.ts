import type { WorkLauncherApi } from "@/Types/Launcher";

export const getWorkLauncherApi = (): WorkLauncherApi | undefined => {
  if (typeof window === "undefined") {
    return undefined;
  }

  return window.workLauncher;
};
