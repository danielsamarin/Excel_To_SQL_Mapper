import { useEffect, useMemo, useState } from "react";
import { Clipboard, History, RefreshCw, Trash2 } from "lucide-react";
import type { ClipboardHistoryEntry, CommandDefinition } from "@shared/contracts";

import { Button } from "@components/UI/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { ScrollArea } from "@components/UI/ScrollArea";
import { Textarea } from "@components/UI/Textarea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface ClipboardHistoryModalProps {
  command: CommandDefinition;
  onCancel: () => void;
}

const getHistoryPreview = (value: string) => {
  const singleLine = value.replace(/\s+/g, " ").trim();
  return singleLine.length > 100 ? `${singleLine.slice(0, 100)}...` : singleLine;
};

const formatCopiedAt = (copiedAt: number) =>
  new Intl.DateTimeFormat(undefined, {
    dateStyle: "short",
    timeStyle: "short"
  }).format(new Date(copiedAt));

const formatCharacterCount = (value: string) =>
  `${value.length.toLocaleString()} character${value.length === 1 ? "" : "s"}`;

export function ClipboardHistoryModal({ command, onCancel }: ClipboardHistoryModalProps) {
  const launcherApi = getWorkLauncherApi();
  const [history, setHistory] = useState<ClipboardHistoryEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isClearing, setIsClearing] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [selectedEntryId, setSelectedEntryId] = useState<string | null>(null);

  const loadHistory = async () => {
    if (!launcherApi) {
      setError("Restart the Electron app to reload the desktop bridge.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const nextHistory = await launcherApi.listClipboardHistory();
      setHistory(nextHistory);
      setSelectedEntryId((current) =>
        current && nextHistory.some((entry) => entry.id === current) ? current : nextHistory[0]?.id ?? null
      );
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadHistory();
  }, []);

  const selectedEntry = useMemo(
    () => history.find((entry) => entry.id === selectedEntryId) ?? history[0] ?? null,
    [history, selectedEntryId]
  );

  const restoreSelectedEntry = async () => {
    if (!launcherApi || !selectedEntry) {
      return;
    }

    setIsRestoring(true);
    try {
      await launcherApi.setClipboardText(selectedEntry.text);
      await loadHistory();
    } catch (restoreError) {
      setError(restoreError instanceof Error ? restoreError.message : String(restoreError));
    } finally {
      setIsRestoring(false);
    }
  };

  const clearHistory = async () => {
    if (!launcherApi) {
      return;
    }

    setIsClearing(true);
    try {
      await launcherApi.clearClipboardHistory();
      setHistory([]);
      setSelectedEntryId(null);
      setError(null);
    } catch (clearError) {
      setError(clearError instanceof Error ? clearError.message : String(clearError));
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <DialogContent className="flex max-h-[min(85vh,38rem)] flex-col overflow-hidden p-0 md:max-w-[900px]">
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>
          {command.subtitle ?? "Browse and restore recent clipboard text."}
        </DialogDescription>
      </DialogHeader>
      <div className="grid min-h-0 flex-1 gap-0 lg:grid-cols-[20rem_minmax(0,1fr)]">
        <aside className="flex min-h-0 flex-col border-b border-border bg-muted/20 lg:border-r lg:border-b-0">
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-4">
            <div className="flex items-center gap-2">
              <History className="size-4 text-muted-foreground" />
              <div className="flex flex-col">
                <span className="text-sm font-medium text-foreground">Recent Entries</span>
                <span className="text-xs text-muted-foreground">Text-only clipboard history</span>
              </div>
            </div>
            <Button disabled={isLoading} onClick={() => void loadHistory()} size="sm" variant="outline">
              <RefreshCw data-icon="inline-start" className={isLoading ? "animate-spin" : undefined} />
              Refresh
            </Button>
          </div>
          <ScrollArea className="min-h-0 flex-1">
            <div className="flex flex-col gap-2 p-4">
              {isLoading ? (
                <Card>
                  <CardContent className="p-3 text-sm text-muted-foreground">
                    Loading clipboard history...
                  </CardContent>
                </Card>
              ) : null}
              {error ? (
                <Card>
                  <CardContent className="p-3 text-sm text-muted-foreground">{error}</CardContent>
                </Card>
              ) : null}
              {!isLoading && !error && history.length === 0 ? (
                <Card>
                  <CardContent className="p-3 text-sm text-muted-foreground">
                    Copy some text and it will start appearing here.
                  </CardContent>
                </Card>
              ) : null}
              {!isLoading && !error
                ? history.map((entry) => (
                    <Button
                      key={entry.id}
                      className="h-auto items-start justify-start px-3 py-3 text-left"
                      onClick={() => setSelectedEntryId(entry.id)}
                      variant={selectedEntry?.id === entry.id ? "secondary" : "outline"}
                    >
                      <div className="flex min-w-0 flex-1 flex-col gap-1">
                        <span className="truncate text-xs text-muted-foreground">
                          {formatCopiedAt(entry.copiedAt)}
                        </span>
                        <span className="whitespace-normal break-words text-sm font-medium text-foreground">
                          {getHistoryPreview(entry.text)}
                        </span>
                      </div>
                    </Button>
                  ))
                : null}
            </div>
          </ScrollArea>
        </aside>
        <main className="flex min-h-0 flex-col">
          <div className="border-b border-border px-6 py-4">
            <h2 className="text-sm font-medium text-foreground">Selected Entry</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Review the full text before restoring it to the clipboard.
            </p>
          </div>
          <div className="flex min-h-0 flex-1 flex-col gap-4 px-6 py-5">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Preview</CardTitle>
                <CardDescription>
                  {selectedEntry ? formatCopiedAt(selectedEntry.copiedAt) : "No history item selected."}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex min-h-0 flex-col gap-3">
                <Textarea
                  className="min-h-[14rem] flex-1 resize-y"
                  readOnly
                  value={selectedEntry?.text ?? ""}
                />
                <p className="text-sm text-muted-foreground">
                  {formatCharacterCount(selectedEntry?.text ?? "")}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-start gap-3 p-4">
                <Clipboard data-icon="inline-start" className="mt-0.5 size-4 text-muted-foreground" />
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-medium text-foreground">Restore to Clipboard</p>
                  <p className="text-sm text-muted-foreground">
                    Restoring an entry copies it back to your clipboard and moves it to the top of the history.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Close
        </Button>
        <div className="flex items-center gap-2">
          <Button
            disabled={isLoading || isClearing || history.length === 0}
            onClick={() => void clearHistory()}
            variant="outline"
          >
            <Trash2 data-icon="inline-start" />
            {isClearing ? "Clearing..." : "Clear History"}
          </Button>
          <Button disabled={!selectedEntry || isRestoring} onClick={() => void restoreSelectedEntry()}>
            {isRestoring ? "Restoring..." : "Restore to Clipboard"}
          </Button>
        </div>
      </DialogFooter>
    </DialogContent>
  );
}
