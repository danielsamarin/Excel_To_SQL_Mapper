import { BridgeFallback } from "@components/BridgeFallback";
import { LauncherResults } from "@components/LauncherResults";
import { ModalHost } from "@components/ModalHost";
import { SearchBar } from "@components/SearchBar";
import { StatusBar } from "@components/StatusBar";
import { Card } from "@components/UI/Card";
import { Command } from "@components/UI/Command";
import { Sonner } from "@components/UI/Sonner";
import { useGlobalLauncherKeys } from "@/Hooks/UseGlobalLauncherKeys";
import { useLauncherState } from "@/Hooks/UseLauncherState";
import { useRootInputKeyDown } from "@/Hooks/UseRootInputKeyDown";

export function App() {
  const {
    activeModal,
    closeModal,
    handleCommandSelection,
    hideLauncher,
    inputRef,
    isBusy,
    launcherApi,
    openNoteDetail,
    openSettings,
    query,
    reopenNotesBrowser,
    runCommand,
    sections,
    selectedCommand,
    selectedIndex,
    setQuery,
    setSelectedIndex,
    settings,
    saveSettings,
    visibleCommands
  } = useLauncherState();

  useGlobalLauncherKeys({
    activeModal,
    closeModal,
    openSettings,
    quitApp: () => launcherApi?.quitApp()
  });

  const handleRootInputKeyDown = useRootInputKeyDown({
    activeModal,
    hideLauncher,
    onSelectCommand: handleCommandSelection,
    selectedIndex,
    setSelectedIndex,
    visibleCommands
  });

  if (!launcherApi) {
    return <BridgeFallback />;
  }

  return (
    <div className="flex h-full w-full p-1">
      <Card className="flex h-full w-full overflow-hidden rounded-2xl border-white/6 bg-zinc-950/96 shadow-[0_24px_80px_rgba(0,0,0,0.55)]">
        <Command className="h-full" shouldFilter={false}>
          <SearchBar
            inputRef={inputRef}
            onKeyDown={handleRootInputKeyDown}
            onOpenSettings={openSettings}
            onQueryChange={setQuery}
            query={query}
          />
          <LauncherResults
            onHover={setSelectedIndex}
            onSelect={handleCommandSelection}
            sections={sections}
            selectedIndex={selectedIndex}
            visibleCommands={visibleCommands}
          />
          <StatusBar hotkey={settings.globalHotkey} subtitle={selectedCommand?.subtitle} />
        </Command>
      </Card>
      <ModalHost
        activeModal={activeModal}
        isBusy={isBusy}
        onClose={closeModal}
        onOpenNote={openNoteDetail}
        onReopenNotesBrowser={reopenNotesBrowser}
        onRunCommand={(payload) => {
          if (activeModal) {
            void runCommand(activeModal.command, payload);
          }
        }}
        onSaveSettings={saveSettings}
        settings={settings}
      />
      <Sonner />
    </div>
  );
}
