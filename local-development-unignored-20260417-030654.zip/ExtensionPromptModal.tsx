import { useState } from "react";
import type { CommandDefinition, CommandExecutionPayload } from "@shared/contracts";

import { Button } from "@components/UI/Button";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { Field, FieldGroup, FieldLabel } from "@components/UI/Field";
import { Input } from "@components/UI/Input";

interface ExtensionPromptModalProps {
  command: CommandDefinition;
  isBusy: boolean;
  onCancel: () => void;
  onSubmit: (payload?: CommandExecutionPayload) => void;
}

export function ExtensionPromptModal({
  command,
  isBusy,
  onCancel,
  onSubmit
}: ExtensionPromptModalProps) {
  const [input, setInput] = useState("");

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>{command.subtitle ?? "Run an extension-provided command."}</DialogDescription>
      </DialogHeader>
      <div className="px-6 py-1">
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="extension-input">{command.promptLabel ?? "Input"}</FieldLabel>
            <Input
              autoFocus
              id="extension-input"
              onChange={(event) => setInput(event.target.value)}
              placeholder={command.promptPlaceholder ?? "Type a value"}
              value={input}
            />
          </Field>
        </FieldGroup>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button disabled={isBusy} onClick={() => onSubmit({ input })}>
          {isBusy ? "Running..." : "Run Command"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
