import type { ExtensionExecutionContext } from "../../../../src/shared/contracts";

export default async function execute({ payload, settings }: ExtensionExecutionContext) {
  const inputValue = typeof payload.input === "string" ? payload.input.trim() : "";
  const configuredTarget = typeof settings.greetingTarget === "string" ? settings.greetingTarget : "World";
  const greetingTarget = inputValue || configuredTarget;

  return {
    ok: true,
    title: "Hello World",
    message: `Hello, ${greetingTarget}!`
  };
}
