import { useEffect } from "react";

import type { ActiveModal } from "@/Types/Launcher";

interface UseGlobalLauncherKeysOptions {
  activeModal: ActiveModal;
  closeModal: () => void;
  openSettings: () => void;
  quitApp: () => void;
}

export const useGlobalLauncherKeys = ({
  activeModal,
  closeModal,
  openSettings,
  quitApp
}: UseGlobalLauncherKeysOptions) => {
  useEffect(() => {
    const handleGlobalKeys = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key.toLowerCase() === "q") {
        event.preventDefault();
        quitApp();
        return;
      }

      if (event.key === "Escape" && activeModal) {
        event.preventDefault();
        closeModal();
        return;
      }

      if (event.key !== "Tab") {
        return;
      }

      if (activeModal) {
        if (activeModal.type === "settings") {
          event.preventDefault();
          closeModal();
        }
        return;
      }

      event.preventDefault();
      openSettings();
    };

    window.addEventListener("keydown", handleGlobalKeys, true);
    return () => window.removeEventListener("keydown", handleGlobalKeys, true);
  }, [activeModal, closeModal, openSettings, quitApp]);
};
