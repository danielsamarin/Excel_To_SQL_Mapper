import { fork, type ChildProcess } from "node:child_process";
import path from "node:path";
import type {
  CommandExecutionPayload,
  CommandExecutionResult,
  ExtensionHostIncomingMessage,
  ExtensionHostOutgoingMessage,
  ExtensionHostRegistration
} from "@shared/contracts";

type PendingRequest = {
  resolve: (result: CommandExecutionResult) => void;
  reject: (error: Error) => void;
};

export class ExtensionHostBridge {
  private child: ChildProcess | null = null;
  private pendingRequests = new Map<string, PendingRequest>();
  private requestCounter = 0;
  private readyPromise: Promise<void> | null = null;
  private readyResolver: (() => void) | null = null;

  constructor(private readonly onDiagnostic: (message: string) => void) {}

  async start() {
    if (this.child) {
      return;
    }

    const child = fork(path.join(__dirname, "extension-host.js"), [], {
      stdio: ["pipe", "pipe", "pipe", "ipc"],
      execPath: process.execPath,
      env: {
        ...process.env,
        ELECTRON_RUN_AS_NODE: "1"
      }
    });

    this.child = child;
    this.readyPromise = new Promise<void>((resolve) => {
      this.readyResolver = resolve;
    });

    child.on("message", (message: ExtensionHostOutgoingMessage) => {
      this.handleMessage(message);
    });

    child.stdout?.on("data", (chunk) => {
      this.onDiagnostic(String(chunk).trim());
    });

    child.stderr?.on("data", (chunk) => {
      const message = String(chunk).trim();
      if (message) {
        this.onDiagnostic(message);
      }
    });

    child.on("exit", (code, signal) => {
      const reason = `Extension host exited (code=${code ?? "null"}, signal=${signal ?? "null"})`;
      this.onDiagnostic(reason);
      this.child = null;
      this.readyPromise = null;
      this.readyResolver = null;

      for (const pending of this.pendingRequests.values()) {
        pending.reject(new Error(reason));
      }
      this.pendingRequests.clear();
    });

    if (this.readyPromise) {
      await this.readyPromise;
    }
  }

  async sync(extensions: ExtensionHostRegistration[]): Promise<string[]> {
    await this.start();

    const child = this.getChild();

    return await new Promise<string[]>((resolve, reject) => {
      const handleBootstrap = (message: ExtensionHostOutgoingMessage) => {
        if (message.type === "bootstrap-complete") {
          cleanup();
          resolve(message.diagnostics);
        }
      };

      const cleanup = () => {
        child.off("message", handleBootstrap);
        clearTimeout(timeoutId);
      };

      const timeoutId = setTimeout(() => {
        cleanup();
        reject(new Error("Extension host bootstrap timed out."));
      }, 15000);

      child.on("message", handleBootstrap);
      child.send({
        type: "bootstrap",
        extensions
      } satisfies ExtensionHostIncomingMessage);
    });
  }

  async execute(
    extensionId: string,
    commandId: string,
    payload: CommandExecutionPayload,
    settings: Record<string, unknown>
  ): Promise<CommandExecutionResult> {
    await this.start();

    const child = this.getChild();
    const requestId = `req-${++this.requestCounter}`;

    return await new Promise<CommandExecutionResult>((resolve, reject) => {
      this.pendingRequests.set(requestId, { resolve, reject });
      child.send({
        type: "execute",
        requestId,
        extensionId,
        commandId,
        payload,
        settings
      } satisfies ExtensionHostIncomingMessage);
    });
  }

  dispose() {
    if (this.child) {
      this.child.kill();
      this.child = null;
    }
  }

  private getChild() {
    if (!this.child) {
      throw new Error("Extension host is not running.");
    }

    return this.child;
  }

  private handleMessage(message: ExtensionHostOutgoingMessage) {
    if (message.type === "ready") {
      this.readyResolver?.();
      this.readyResolver = null;
      return;
    }

    if (message.type === "execute-result") {
      const pending = this.pendingRequests.get(message.requestId);
      if (!pending) {
        return;
      }

      this.pendingRequests.delete(message.requestId);
      pending.resolve(message.result);
      return;
    }

    if (message.type === "execute-error") {
      const pending = this.pendingRequests.get(message.requestId);
      if (!pending) {
        this.onDiagnostic(message.error);
        return;
      }

      this.pendingRequests.delete(message.requestId);
      pending.reject(new Error(message.error));
    }
  }
}
