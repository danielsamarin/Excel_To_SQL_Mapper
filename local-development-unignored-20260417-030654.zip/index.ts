import { app, BrowserWindow, clipboard, dialog, globalShortcut, ipcMain, Menu, nativeImage, Notification, shell, Tray } from "electron";
import { existsSync, watch, type FSWatcher } from "node:fs";
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { ExtensionHostBridge } from "./extensionHostBridge";
import {
  getClipboardTransformOption,
  transformClipboardText,
  type ClipboardTransformId
} from "@shared/clipboard";
import {
  appSettingsSchema,
  clipboardHistoryEntrySchema,
  commandDefinitionSchema,
  commandExecutionPayloadSchema,
  defaultAppSettings,
  extensionManifestSchema,
  type AppSettings,
  type ClipboardHistoryEntry,
  type CommandDefinition,
  type CommandExecutionPayload,
  type CommandExecutionResult,
  type DevState,
  type ExtensionManifest,
  type ExtensionHostRegistration,
  type ExtensionSettingsMap,
  type NoteFile,
  type NoteSummary,
  type PermissionKey,
  type TrustState
} from "@shared/contracts";

type SettingsFile = {
  app: AppSettings;
  extensions: ExtensionSettingsMap;
};

type LoadedExtension = {
  manifest: ExtensionManifest;
  extensionPath: string;
};

const PROJECT_ROOT = process.cwd();
const EXTENSIONS_DIR = path.join(PROJECT_ROOT, "extensions");
const isDevelopment = !app.isPackaged;

let launcherWindow: BrowserWindow | null = null;
let currentSettings: AppSettings = defaultAppSettings;
let extensionSettings: ExtensionSettingsMap = {};
let trustState: TrustState = {};
let commands: CommandDefinition[] = [];
let loadedExtensions: LoadedExtension[] = [];
let diagnostics: string[] = [];
let extensionWatcher: FSWatcher | null = null;
let tray: Tray | null = null;
let isQuitting = false;
let clipboardHistory: ClipboardHistoryEntry[] = [];
let clipboardPoller: NodeJS.Timeout | null = null;
let lastObservedClipboardText = "";
const extensionHost = new ExtensionHostBridge((message) => {
  if (message) {
    diagnostics.push(message);
    emitStateChanged();
  }
});

const clipboardHistoryLimit = 25;
const clipboardPollIntervalMs = 1500;
const maxClipboardTextLength = 20000;

const createNoteFile = async (notesRootPath: string, title: string): Promise<string> => {
  const safeTitle = title.trim();
  if (!safeTitle) {
    throw new Error("A note title is required.");
  }

  if (!notesRootPath.trim()) {
    throw new Error("Set a notes directory in Settings before creating a note.");
  }

  const filename = `${safeTitle
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "note"}.md`;
  const targetDirectory = path.resolve(notesRootPath);
  const targetPath = path.join(targetDirectory, filename);

  await mkdir(targetDirectory, { recursive: true });
  await writeFile(targetPath, `# ${safeTitle}\n\n`, "utf8");

  return targetPath;
};

const sanitizeSubfolder = (value: string): string => {
  const trimmed = value.trim().replace(/\//g, path.sep);
  if (!trimmed) {
    throw new Error("Folder template contains an empty subfolder entry.");
  }

  if (path.isAbsolute(trimmed) || trimmed.split(path.sep).includes("..")) {
    throw new Error(`Invalid subfolder path: ${value}`);
  }

  return trimmed;
};

const createFolderStructure = async (
  rootPath: string,
  projectName: string,
  subfolders: string[]
): Promise<string> => {
  const safeProjectName = projectName.trim();
  if (!safeProjectName) {
    throw new Error("A folder name is required.");
  }

  if (!rootPath.trim()) {
    throw new Error("Set a root path in Settings before creating folders.");
  }

  const basePath = path.join(path.resolve(rootPath), safeProjectName);
  await mkdir(basePath, { recursive: true });

  for (const subfolder of subfolders) {
    const relativePath = sanitizeSubfolder(subfolder);
    await mkdir(path.join(basePath, relativePath), { recursive: true });
  }

  return basePath;
};

const getResolvedNotesRootPath = () => {
  const notesRootPath = currentSettings.notesRootPath.trim();
  if (!notesRootPath) {
    throw new Error("Set a notes directory in Settings before browsing notes.");
  }

  return path.resolve(notesRootPath);
};

const assertNotePathWithinRoot = (notePath: string) => {
  const notesRootPath = getResolvedNotesRootPath();
  const resolvedNotePath = path.resolve(notePath);

  if (
    resolvedNotePath !== notesRootPath &&
    !resolvedNotePath.startsWith(`${notesRootPath}${path.sep}`)
  ) {
    throw new Error("The selected note is outside of the configured notes directory.");
  }

  return resolvedNotePath;
};

const listNotes = async (): Promise<NoteSummary[]> => {
  const notesRootPath = getResolvedNotesRootPath();
  if (!existsSync(notesRootPath)) {
    return [];
  }

  const entries = await readdir(notesRootPath, { withFileTypes: true });
  const noteEntries = await Promise.all(
    entries
      .filter((entry) => entry.isFile() && path.extname(entry.name).toLowerCase() === ".md")
      .map(async (entry) => {
        const notePath = path.join(notesRootPath, entry.name);
        const noteStat = await stat(notePath);

        return {
          path: notePath,
          name: entry.name,
          title: path.basename(entry.name, path.extname(entry.name)),
          modifiedAt: noteStat.mtimeMs
        } satisfies NoteSummary;
      })
  );

  noteEntries.sort((left, right) => right.modifiedAt - left.modifiedAt);
  return noteEntries;
};

const readNoteFile = async (notePath: string): Promise<NoteFile> => {
  const resolvedNotePath = assertNotePathWithinRoot(notePath);
  if (!existsSync(resolvedNotePath)) {
    throw new Error("The selected note no longer exists.");
  }

  const [content, noteStat] = await Promise.all([
    readFile(resolvedNotePath, "utf8"),
    stat(resolvedNotePath)
  ]);

  return {
    path: resolvedNotePath,
    name: path.basename(resolvedNotePath),
    title: path.basename(resolvedNotePath, path.extname(resolvedNotePath)),
    modifiedAt: noteStat.mtimeMs,
    content
  };
};

const findChromeExecutable = () => {
  const candidatePaths = [
    path.join(process.env["ProgramFiles"] ?? "C:\\Program Files", "Google", "Chrome", "Application", "chrome.exe"),
    path.join(
      process.env["ProgramFiles(x86)"] ?? "C:\\Program Files (x86)",
      "Google",
      "Chrome",
      "Application",
      "chrome.exe"
    ),
    path.join(process.env.LOCALAPPDATA ?? "", "Google", "Chrome", "Application", "chrome.exe")
  ];

  return candidatePaths.find((candidatePath) => candidatePath && existsSync(candidatePath)) ?? null;
};

const getFileIconDataUrl = async (filePath: string | null) => {
  if (!filePath) {
    return undefined;
  }

  try {
    const icon = await app.getFileIcon(filePath, { size: "normal" });
    return icon.isEmpty() ? undefined : icon.toDataURL();
  } catch {
    return undefined;
  }
};

const getSettingsPaths = () => {
  const userDataPath = app.getPath("userData");
  return {
    directory: userDataPath,
    settingsPath: path.join(userDataPath, "settings.json"),
    trustPath: path.join(userDataPath, "trusted-extensions.json"),
    clipboardHistoryPath: path.join(userDataPath, "clipboard-history.json")
  };
};

const readJsonFile = async <T>(filePath: string, fallback: T): Promise<T> => {
  if (!existsSync(filePath)) {
    return fallback;
  }

  try {
    const raw = await readFile(filePath, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
};

const writeJsonFile = async (filePath: string, value: unknown) => {
  await writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
};

const loadSettingsState = async () => {
  const { directory, settingsPath, trustPath } = getSettingsPaths();
  await mkdir(directory, { recursive: true });

  const settingsFile = await readJsonFile<SettingsFile>(settingsPath, {
    app: defaultAppSettings,
    extensions: {}
  });
  const trustedExtensions = await readJsonFile<TrustState>(trustPath, {});

  currentSettings = appSettingsSchema.parse({
    ...defaultAppSettings,
    ...settingsFile.app
  });
  extensionSettings = settingsFile.extensions ?? {};
  trustState = trustedExtensions;
};

const persistSettingsState = async () => {
  const { settingsPath, trustPath } = getSettingsPaths();
  await writeJsonFile(settingsPath, {
    app: currentSettings,
    extensions: extensionSettings
  } satisfies SettingsFile);
  await writeJsonFile(trustPath, trustState);
};

const normalizeClipboardText = (text: string) => text.replace(/\r\n/g, "\n");

const shouldTrackClipboardText = (text: string) => {
  const normalizedText = normalizeClipboardText(text);
  return Boolean(normalizedText.trim()) && normalizedText.length <= maxClipboardTextLength;
};

const persistClipboardHistoryState = async () => {
  const { clipboardHistoryPath } = getSettingsPaths();
  await writeJsonFile(clipboardHistoryPath, clipboardHistory);
};

const recordClipboardHistory = (text: string) => {
  const normalizedText = normalizeClipboardText(text);
  if (!shouldTrackClipboardText(normalizedText)) {
    return;
  }

  clipboardHistory = [
    {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      text: normalizedText,
      copiedAt: Date.now()
    },
    ...clipboardHistory.filter((entry) => entry.text !== normalizedText)
  ].slice(0, clipboardHistoryLimit);

  void persistClipboardHistoryState();
};

const loadClipboardHistoryState = async () => {
  const { clipboardHistoryPath } = getSettingsPaths();
  const nextClipboardHistory = await readJsonFile<ClipboardHistoryEntry[]>(clipboardHistoryPath, []);

  clipboardHistory = nextClipboardHistory
    .map((entry) => clipboardHistoryEntrySchema.safeParse(entry))
    .flatMap((result) => (result.success ? [result.data] : []))
    .filter((entry) => shouldTrackClipboardText(entry.text))
    .sort((left, right) => right.copiedAt - left.copiedAt)
    .slice(0, clipboardHistoryLimit);
};

const startClipboardPolling = () => {
  if (clipboardPoller) {
    return;
  }

  lastObservedClipboardText = normalizeClipboardText(clipboard.readText());
  recordClipboardHistory(lastObservedClipboardText);

  clipboardPoller = setInterval(() => {
    const nextClipboardText = normalizeClipboardText(clipboard.readText());
    if (nextClipboardText === lastObservedClipboardText) {
      return;
    }

    lastObservedClipboardText = nextClipboardText;
    recordClipboardHistory(nextClipboardText);
  }, clipboardPollIntervalMs);
};

const buildBuiltinCommands = async (): Promise<CommandDefinition[]> => {
  const chromeExecutable = findChromeExecutable();
  const chromeIconDataUrl = await getFileIconDataUrl(chromeExecutable);

  const builtinCommands: CommandDefinition[] = [
    {
      id: "builtin.clipboard-actions",
      title: "Clipboard Actions",
      subtitle: "Transform and rewrite the current clipboard text",
      source: "builtin",
      mode: "view",
      viewId: "clipboard-actions",
      keywords: ["clipboard", "copy", "paste", "transform", "text"]
    },
    {
      id: "builtin.clipboard-history",
      title: "Clipboard History",
      subtitle: "Browse and restore recent clipboard text",
      source: "builtin",
      mode: "view",
      viewId: "clipboard-history",
      keywords: ["clipboard", "history", "recent", "copy", "paste", "text"]
    },
    {
      id: "builtin.browse-notes",
      title: "Browse Notes",
      subtitle: "View markdown notes from your configured notes directory",
      source: "builtin",
      mode: "view",
      viewId: "browse-notes",
      keywords: ["notes", "markdown", "browse", "files"]
    },
    {
      id: "builtin.create-note",
      title: "Create Note",
      subtitle: "Save a markdown note to your configured notes directory",
      source: "builtin",
      mode: "view",
      viewId: "create-note",
      keywords: ["markdown", "note", "notes"]
    },
    {
      id: "builtin.create-folder-structure",
      title: "Create Folder Structure",
      subtitle: "Create a project folder with your configured subfolders",
      source: "builtin",
      mode: "view",
      viewId: "create-folder",
      keywords: ["folder", "project", "template"]
    },
    {
      id: "builtin.open-settings",
      title: "Settings",
      subtitle: "Configure paths, hotkeys, and developer mode",
      source: "builtin",
      mode: "view",
      viewId: "settings",
      keywords: ["settings", "preferences", "config"]
    },
    {
      id: "builtin.open-windows-settings",
      title: "Settings",
      subtitle: "Open Windows Settings",
      source: "builtin",
      mode: "run",
      keywords: ["windows", "system", "settings"]
    },
    {
      id: "builtin.launch-chrome",
      title: "Google Chrome",
      subtitle: "Launch Google Chrome",
      iconDataUrl: chromeIconDataUrl,
      source: "builtin",
      mode: "run",
      keywords: ["chrome", "browser", "google", "launch"]
    }
  ];

  if (currentSettings.developerMode) {
    builtinCommands.push({
      id: "builtin.reload-extensions",
      title: "Reload Extensions",
      subtitle: "Refresh manifests and development diagnostics",
      source: "builtin",
      mode: "run",
      keywords: ["extensions", "reload", "developer"]
    });
  }

  return builtinCommands.map((command) => commandDefinitionSchema.parse(command));
};

const getTrustRecord = (extensionId: string, permissions: PermissionKey[]) => {
  const existingRecord = trustState[extensionId];
  if (existingRecord) {
    return existingRecord;
  }

  const record = {
    trusted: true,
    grantedPermissions: permissions
  };
  trustState[extensionId] = record;
  return record;
};

const canNotifyLauncher = () => {
  if (isQuitting || !launcherWindow || launcherWindow.isDestroyed()) {
    return false;
  }

  const { webContents } = launcherWindow;
  return !webContents.isDestroyed() && !webContents.isCrashed();
};

const emitStateChanged = () => {
  if (!canNotifyLauncher()) {
    return;
  }

  const window = launcherWindow;
  if (!window) {
    return;
  }

  window.webContents.send("app:state-changed");
};

const showLauncher = () => {
  if (!launcherWindow) {
    return;
  }

  launcherWindow.center();
  launcherWindow.show();
  launcherWindow.focus();
};

const toggleLauncher = () => {
  if (!launcherWindow) {
    return;
  }

  if (launcherWindow.isVisible()) {
    launcherWindow.hide();
    return;
  }

  showLauncher();
};

const loadExtensions = async () => {
  diagnostics = [];
  loadedExtensions = [];

  if (!existsSync(EXTENSIONS_DIR)) {
    commands = await buildBuiltinCommands();
    emitStateChanged();
    return;
  }

  const entries = await readdir(EXTENSIONS_DIR, { withFileTypes: true });

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    const extensionPath = path.join(EXTENSIONS_DIR, entry.name);
    const manifestPath = path.join(extensionPath, "manifest.json");

    if (!existsSync(manifestPath)) {
      diagnostics.push(`Skipped ${entry.name}: missing manifest.json`);
      continue;
    }

    try {
      const manifestRaw = await readFile(manifestPath, "utf8");
      const manifest = extensionManifestSchema.parse(JSON.parse(manifestRaw));
      getTrustRecord(manifest.id, manifest.permissions);
      loadedExtensions.push({ manifest, extensionPath });

      if (!extensionSettings[manifest.id]) {
        extensionSettings[manifest.id] = Object.fromEntries(
          (manifest.settings ?? []).map((setting) => [setting.key, setting.defaultValue ?? ""])
        );
      }
    } catch (error) {
      diagnostics.push(
        `Failed to load ${entry.name}: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }

  const extensionCommands = loadedExtensions.flatMap(({ manifest }) =>
    manifest.commands.map((command) =>
      commandDefinitionSchema.parse({
        id: command.id,
        title: command.title,
        subtitle: command.description ?? manifest.name,
        source: "extension",
        extensionId: manifest.id,
        mode: command.mode,
        viewId: command.mode === "view" ? "extension-prompt" : undefined,
        keywords: command.keywords,
        permissions: manifest.permissions,
        promptLabel: command.promptLabel,
        promptPlaceholder: command.promptPlaceholder
      })
    )
  );

  commands = [...(await buildBuiltinCommands()), ...extensionCommands];
  const hostRegistrations: ExtensionHostRegistration[] = loadedExtensions.map(
    ({ manifest, extensionPath }) => ({
      extensionId: manifest.id,
      extensionName: manifest.name,
      extensionPath,
      commands: manifest.commands.map((command) => ({
        commandId: command.id,
        entryPath: path.resolve(extensionPath, command.entry)
      }))
    })
  );

  try {
    const hostDiagnostics = await extensionHost.sync(hostRegistrations);
    diagnostics.push(...hostDiagnostics);
  } catch (error) {
    diagnostics.push(
      `Failed to sync extension host: ${error instanceof Error ? error.message : String(error)}`
    );
  }

  await persistSettingsState();
  emitStateChanged();
};

const getDevState = (): DevState => ({
  loadedExtensions: loadedExtensions.map(({ manifest }) => ({
    id: manifest.id,
    name: manifest.name,
    commandCount: manifest.commands.length,
    permissions: manifest.permissions
  })),
  diagnostics
});

const registerExtensionWatcher = () => {
  if (!isDevelopment || extensionWatcher || !existsSync(EXTENSIONS_DIR)) {
    return;
  }

  let refreshTimer: NodeJS.Timeout | undefined;
  extensionWatcher = watch(
    EXTENSIONS_DIR,
    { recursive: true },
    () => {
      if (refreshTimer) {
        clearTimeout(refreshTimer);
      }
      refreshTimer = setTimeout(() => {
        void loadExtensions();
      }, 150);
    }
  );
};

const registerGlobalHotkey = () => {
  globalShortcut.unregisterAll();
  const accelerator = currentSettings.globalHotkey.trim();
  const didRegister = globalShortcut.register(accelerator, () => {
    toggleLauncher();
  });

  if (!didRegister) {
    diagnostics.push(`Failed to register global hotkey: ${accelerator}`);
  }
};

const createLauncherWindow = () => {
  const window = new BrowserWindow({
    width: 760,
    height: 560,
    minWidth: 680,
    minHeight: 440,
    show: false,
    frame: false,
    thickFrame: false,
    transparent: true,
    resizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    backgroundColor: "#00000000",
    webPreferences: {
      preload: path.join(__dirname, "../preload/preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  if (!isDevelopment) {
    window.on("blur", () => {
      window.hide();
    });
  }

  window.on("close", (event) => {
    if (isQuitting) {
      return;
    }

    event.preventDefault();
    window.hide();
  });

  window.on("closed", () => {
    if (launcherWindow === window) {
      launcherWindow = null;
    }
  });

  window.webContents.on("did-finish-load", () => {
    console.log("[main] Renderer finished loading");
    if (isDevelopment) {
      window.show();
      window.focus();
      window.webContents.openDevTools({ mode: "detach" });
    }
  });

  window.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
    console.error(
      `[main] Renderer failed to load (${errorCode}): ${errorDescription} -> ${validatedURL}`
    );
  });

  window.webContents.on("render-process-gone", (_event, details) => {
    console.error(`[main] Renderer process gone: ${details.reason}`);
  });

  window.webContents.on("console-message", (_event, level, message, line, sourceId) => {
    console.log(`[renderer:${level}] ${message} (${sourceId}:${line})`);
  });

  if (process.env.ELECTRON_RENDERER_URL) {
    console.log(`[main] Loading renderer URL: ${process.env.ELECTRON_RENDERER_URL}`);
    void window.loadURL(process.env.ELECTRON_RENDERER_URL);
  } else {
    console.log("[main] Loading packaged renderer");
    void window.loadFile(path.join(__dirname, "../renderer/index.html"));
  }

  return window;
};

const createTrayIcon = () => {
  const pngBase64 =
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIqSURBVFhH7ZexSxxBGMUtLVNafS/TiKUggSsP7KwsBRsrsRFNIxYW6YJa+AdYCIIcwoGgRaKVqVKlNpgiRYp0XqWGNBu+2Vlv983c7Ozd2uXBj2u+nfdm9pvZuamp/xpTAOYBdEvMc02rAjANYE3E9ETMM2CyECLmAsAGgDc8xtjSAUXMbzaLIWIGALY1OI+XLJ2FiPnKgzdBxNwBeMtj10ofEjE/ecBxcKvRZY+RcjNvxbzAhZhjL0/6ziZd9lHkk6ppzrxxhg8tLq1lR2e/spPPWZDjqz/Z5t55xWhr6312e/vF/gZCHLHni9zsK90eMy9T1B8cHGaPj0+Wh4dBNjs7xwGeAcywt1W+f6uJV9f3PbMQbK70+31vBVyIj+xtJWI+cXGMcgA2v76+8WZfCnDH3kXnjzzhQpQDpJoPoR0BoOMXxQkFSDNXsMwBlv2iOBwg3VzBNgfwGjCGvvNygGbmlg8cYCVQFKRouNObYYCG5roCuxyg6xf5lLv92/e/1nxzr+fV1YMVDjDjF1VpstXqQacSQBX7BrRprqcte1tpY3CxsrOz25q5ImJO2NtKX0PoMLq//9GaeU7k/qhfK36gWP7Ly6uJzfXOyJ4VuVXw7n8LC++8wZrivoRJl5JO6FVMDm29mLS45RDVky9FejjldzlvsGTcsqfPnOV6oscDp+D+pNS/8xTp1tH9G2pQMh3kgRtcw5sqvzvYy6seXA77L+j1TF9L/wCRDSeFntxCbQAAAABJRU5ErkJggg==";

  return nativeImage
    .createFromDataURL(`data:image/png;base64,${pngBase64}`)
    .resize({ width: 16, height: 16 });
};

const registerTray = () => {
  if (tray) {
    tray.destroy();
  }

  tray = new Tray(createTrayIcon());
  tray.setToolTip("Work Launcher");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: "Open Launcher",
        click: () => {
          showLauncher();
        }
      },
      {
        type: "separator"
      },
      {
        label: "Exit",
        click: () => {
          isQuitting = true;
          app.quit();
        }
      }
    ])
  );
  tray.on("click", () => {
    toggleLauncher();
  });
};

const notify = (title: string, body: string) => {
  if (Notification.isSupported()) {
    new Notification({ title, body }).show();
  }
};

const executeBuiltinCommand = async (
  commandId: string,
  payload: CommandExecutionPayload
): Promise<CommandExecutionResult> => {
  switch (commandId) {
    case "builtin.create-note": {
      const title = typeof payload.title === "string" ? payload.title : "";
      const outputPath = await createNoteFile(currentSettings.notesRootPath, title);
      notify("Note Created", path.basename(outputPath));
      return {
        ok: true,
        title: "Note Created",
        message: `Saved ${path.basename(outputPath)}`,
        detail: outputPath
      };
    }
    case "builtin.create-folder-structure": {
      const projectName = typeof payload.projectName === "string" ? payload.projectName : "";
      const outputPath = await createFolderStructure(
        currentSettings.folderTemplateRootPath,
        projectName,
        currentSettings.folderTemplateSubfolders
      );
      notify("Folder Structure Created", path.basename(outputPath));
      return {
        ok: true,
        title: "Folders Created",
        message: `Created ${path.basename(outputPath)}`,
        detail: outputPath
      };
    }
    case "builtin.clipboard-actions": {
      const action = typeof payload.action === "string" ? payload.action : "";
      const text = typeof payload.text === "string" ? payload.text : "";

      const selectedAction = getClipboardTransformOption(action as ClipboardTransformId);
      if (!selectedAction) {
        throw new Error("Choose a clipboard action before running the command.");
      }

      const nextClipboardText = transformClipboardText(selectedAction.id, text);
      clipboard.writeText(nextClipboardText);
      lastObservedClipboardText = normalizeClipboardText(nextClipboardText);
      recordClipboardHistory(nextClipboardText);
      notify("Clipboard Updated", selectedAction.title);
      return {
        ok: true,
        title: "Clipboard Updated",
        message: `${selectedAction.title} copied back to your clipboard.`,
        detail: selectedAction.id
      };
    }
    case "builtin.reload-extensions": {
      await loadExtensions();
      return {
        ok: true,
        title: "Extensions Reloaded",
        message: `Loaded ${loadedExtensions.length} extension${loadedExtensions.length === 1 ? "" : "s"}`
      };
    }
    case "builtin.open-windows-settings": {
      await shell.openExternal("ms-settings:");
      return {
        ok: true,
        title: "Windows Settings",
        message: "Opened Windows Settings"
      };
    }
    case "builtin.launch-chrome": {
      const chromeExecutable = findChromeExecutable();
      if (!chromeExecutable) {
        return {
          ok: false,
          title: "Chrome Not Found",
          message: "Google Chrome was not found in the standard Windows install locations."
        };
      }

      const launchError = await shell.openPath(chromeExecutable);
      if (launchError) {
        return {
          ok: false,
          title: "Chrome Launch Failed",
          message: launchError
        };
      }

      return {
        ok: true,
        title: "Google Chrome",
        message: "Launched Google Chrome"
      };
    }
    default:
      throw new Error(`Unknown built-in command: ${commandId}`);
  }
};

const executeExtensionCommand = async (
  commandId: string,
  payload: CommandExecutionPayload
): Promise<CommandExecutionResult> => {
  const command = commands.find((entry) => entry.id === commandId && entry.source === "extension");

  if (!command?.extensionId) {
    throw new Error(`Unknown extension command: ${commandId}`);
  }

  const trustRecord = trustState[command.extensionId];
  if (!trustRecord?.trusted) {
    throw new Error(`The extension ${command.extensionId} is not trusted.`);
  }

  const result = await extensionHost.execute(
    command.extensionId,
    commandId,
    payload,
    extensionSettings[command.extensionId] ?? {}
  );

  if (result.ok) {
    notify(result.title ?? command.title, result.message);
  }

  return result;
};

const registerIpcHandlers = () => {
  ipcMain.handle("app:list-commands", async () => commands);
  ipcMain.handle("app:get-settings", async () => currentSettings);
  ipcMain.handle("app:get-dev-state", async () => getDevState());
  ipcMain.handle("app:hide-launcher", async () => {
    launcherWindow?.hide();
  });
  ipcMain.handle("app:list-notes", async () => listNotes());
  ipcMain.handle("app:read-note", async (_event, notePath: string) => readNoteFile(notePath));
  ipcMain.handle("app:get-clipboard-text", async () => clipboard.readText());
  ipcMain.handle("app:set-clipboard-text", async (_event, text: string) => {
    const normalizedText = normalizeClipboardText(text);
    clipboard.writeText(normalizedText);
    lastObservedClipboardText = normalizedText;
    recordClipboardHistory(normalizedText);
  });
  ipcMain.handle("app:list-clipboard-history", async () => clipboardHistory);
  ipcMain.handle("app:clear-clipboard-history", async () => {
    clipboardHistory = [];
    await persistClipboardHistoryState();
  });
  ipcMain.on("app:quit", () => {
    isQuitting = true;
    app.quit();
  });
  ipcMain.handle("app:pick-directory", async () => {
    const response = await dialog.showOpenDialog({
      properties: ["openDirectory", "createDirectory"]
    });
    if (response.canceled || response.filePaths.length === 0) {
      return null;
    }

    return response.filePaths[0];
  });
  ipcMain.handle("app:update-settings", async (_event, nextSettings: AppSettings) => {
    currentSettings = appSettingsSchema.parse(nextSettings);
    await persistSettingsState();
    registerGlobalHotkey();
    await loadExtensions();
    return currentSettings;
  });
  ipcMain.handle("app:execute-command", async (_event, commandId: string, payload?: unknown) => {
    const parsedPayload = commandExecutionPayloadSchema.parse(payload ?? {});

    try {
      return commandId.startsWith("builtin.")
        ? await executeBuiltinCommand(commandId, parsedPayload)
        : await executeExtensionCommand(commandId, parsedPayload);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      diagnostics.push(`Command failed (${commandId}): ${message}`);
      emitStateChanged();
      return {
        ok: false,
        title: "Command Failed",
        message,
        detail: commandId
      } satisfies CommandExecutionResult;
    }
  });
};

app.whenReady().then(async () => {
  await loadSettingsState();
  await loadClipboardHistoryState();
  await loadExtensions();
  registerIpcHandlers();
  launcherWindow = createLauncherWindow();
  registerGlobalHotkey();
  registerExtensionWatcher();
  registerTray();
  startClipboardPolling();
});

app.on("before-quit", () => {
  isQuitting = true;
});

app.on("will-quit", () => {
  launcherWindow = null;
  tray?.destroy();
  extensionWatcher?.close();
  if (clipboardPoller) {
    clearInterval(clipboardPoller);
    clipboardPoller = null;
  }
  extensionHost.dispose();
  globalShortcut.unregisterAll();
});
