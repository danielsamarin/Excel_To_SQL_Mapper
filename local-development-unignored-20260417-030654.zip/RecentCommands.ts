import { z } from "zod";

const recentCommandsSchema = z.array(z.string());
const recentCommandsKey = "work-launcher:recent-commands";

export const loadRecentCommands = (): string[] => {
  if (typeof window === "undefined") {
    return [];
  }

  try {
    const storedValue = window.localStorage.getItem(recentCommandsKey);
    if (!storedValue) {
      return [];
    }

    return recentCommandsSchema.parse(JSON.parse(storedValue));
  } catch {
    return [];
  }
};

export const saveRecentCommands = (commandIds: string[]) => {
  if (typeof window === "undefined") {
    return;
  }

  try {
    window.localStorage.setItem(recentCommandsKey, JSON.stringify(commandIds));
  } catch {
    // Ignore storage failures in locked-down environments.
  }
};

export const recordRecentCommand = (commandId: string, commandIds: string[], limit: number) => {
  const nextCommandIds = [commandId, ...commandIds.filter((value) => value !== commandId)];
  return nextCommandIds.slice(0, limit);
};
