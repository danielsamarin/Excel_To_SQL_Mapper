import { useEffect, useRef } from "react";
import type { CommandDefinition } from "@shared/contracts";

import { CommandRow } from "@components/CommandRow";
import { CommandEmpty, CommandGroup, CommandList, CommandSeparator } from "@components/UI/Command";
import { ScrollArea } from "@components/UI/ScrollArea";
import type { CommandSection } from "@/Types/Launcher";

interface LauncherResultsProps {
  onHover: (index: number) => void;
  onSelect: (command: CommandDefinition) => void | Promise<void>;
  sections: CommandSection[];
  selectedIndex: number;
  visibleCommands: CommandDefinition[];
}

export function LauncherResults({
  onHover,
  onSelect,
  sections,
  selectedIndex,
  visibleCommands
}: LauncherResultsProps) {
  const selectedRowRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    selectedRowRef.current?.scrollIntoView({
      block: "nearest"
    });
  }, [selectedIndex, visibleCommands]);

  return (
    <ScrollArea className="min-h-0 flex-1 bg-[radial-gradient(circle_at_24%_74%,rgba(121,128,44,0.12),transparent_24%),radial-gradient(circle_at_64%_84%,rgba(130,52,44,0.12),transparent_22%),linear-gradient(180deg,rgba(24,24,27,0.98),rgba(18,18,20,0.98))]">
      <CommandList className="py-3">
        <CommandEmpty>
          <div className="flex flex-col gap-1">
            <span className="font-medium text-foreground">No command matched</span>
            <span>Try Create Note or open Settings to configure your paths.</span>
          </div>
        </CommandEmpty>
        {visibleCommands.length > 0
          ? sections.map((section, sectionIndex) => (
              <div key={section.title}>
                {sectionIndex > 0 ? <CommandSeparator className="mx-4 my-2" /> : null}
                <CommandGroup heading={section.title}>
                  {section.items.map(({ command, index }) => (
                    <CommandRow
                      key={command.id}
                      command={command}
                      index={index}
                      isSelected={index === selectedIndex}
                      onHover={onHover}
                      onSelect={onSelect}
                      rowRef={index === selectedIndex ? selectedRowRef : undefined}
                    />
                  ))}
                </CommandGroup>
              </div>
            ))
          : null}
      </CommandList>
    </ScrollArea>
  );
}
