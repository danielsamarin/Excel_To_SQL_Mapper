"""Process management tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    GetProcessInfoParams,
    GetTopProcessesParams,
    KillProcessParams,
    ListProcessesParams,
    PermissionLevel,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.process")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Process List Tool
async def process_list_handler(params: dict[str, Any]) -> str:
    """List running processes."""
    adapter = get_adapter()
    list_params = ListProcessesParams(**params)
    result = await adapter.list_processes(list_params)

    if not result.success:
        return f"Failed to list processes: {result.error}"

    processes = result.data or []
    if not processes:
        return "No processes found."

    lines = [f"Top {len(processes)} processes (sorted by {list_params.sort_by}):"]
    lines.append(f"{'PID':<8} {'Name':<30} {'CPU %':<8} {'Memory %':<10}")
    lines.append("-" * 60)

    for p in processes:
        lines.append(f"{p.pid:<8} {p.name[:28]:<30} {p.cpu:<8.1f} {p.memory:<10.1f}")

    return "\n".join(lines)


PROCESS_LIST = ToolDefinition(
    name="process_list",
    description="List running processes sorted by CPU or memory usage",
    parameters={
        "type": "object",
        "properties": {
            "sort_by": {
                "type": "string",
                "enum": ["cpu", "memory", "name"],
                "description": "Sort field",
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of processes to return",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=process_list_handler,
)


# Process Info Tool
async def process_info_handler(params: dict[str, Any]) -> str:
    """Get process information."""
    adapter = get_adapter()
    info_params = GetProcessInfoParams(**params)
    result = await adapter.get_process_info(info_params)

    if not result.success:
        return f"Failed to get process info: {result.error}"

    p = result.data
    if not p:
        return "Process not found."

    lines = [
        f"Process: {p.name}",
        f"PID: {p.pid}",
        f"Status: {p.status}",
        f"CPU: {p.cpu:.1f}%",
        f"Memory: {p.memory:.1f}%",
    ]

    return "\n".join(lines)


PROCESS_INFO = ToolDefinition(
    name="process_info",
    description="Get detailed information about a specific process",
    parameters={
        "type": "object",
        "properties": {
            "pid": {
                "type": "integer",
                "description": "Process ID",
            },
            "name": {
                "type": "string",
                "description": "Process name (returns first match)",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=process_info_handler,
)


# Process Kill Tool
async def process_kill_handler(params: dict[str, Any]) -> str:
    """Kill a process."""
    adapter = get_adapter()
    kill_params = KillProcessParams(**params)
    result = await adapter.kill_process(kill_params)

    if not result.success:
        return f"Failed to kill process: {result.error}"

    target = kill_params.pid or kill_params.name
    return f"Successfully killed process: {target}"


PROCESS_KILL = ToolDefinition(
    name="process_kill",
    description="Kill a process by PID or name",
    parameters={
        "type": "object",
        "properties": {
            "pid": {
                "type": "integer",
                "description": "Process ID to kill",
            },
            "name": {
                "type": "string",
                "description": "Process name to kill (kills all matching)",
            },
            "force": {
                "type": "boolean",
                "description": "Force kill without cleanup",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.DANGEROUS,
    handler=process_kill_handler,
)


# Process Top Tool
async def process_top_handler(params: dict[str, Any]) -> str:
    """Get top processes by resource usage."""
    adapter = get_adapter()
    top_params = GetTopProcessesParams(**params)
    result = await adapter.get_top_processes(top_params)

    if not result.success:
        return f"Failed to get top processes: {result.error}"

    processes = result.data or []
    if not processes:
        return "No processes found."

    resource = top_params.resource
    lines = [f"Top {len(processes)} processes by {resource.upper()}:"]

    for i, p in enumerate(processes, 1):
        value = p.cpu if resource == "cpu" else p.memory
        lines.append(f"  {i}. {p.name}: {value:.1f}%")

    return "\n".join(lines)


PROCESS_TOP = ToolDefinition(
    name="process_top",
    description="Get top processes by CPU or memory usage",
    parameters={
        "type": "object",
        "properties": {
            "resource": {
                "type": "string",
                "enum": ["cpu", "memory"],
                "description": "Resource to sort by",
            },
            "limit": {
                "type": "integer",
                "description": "Number of top processes",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=process_top_handler,
)


# Export all process tools
PROCESS_TOOLS = [
    PROCESS_LIST,
    PROCESS_INFO,
    PROCESS_KILL,
    PROCESS_TOP,
]
