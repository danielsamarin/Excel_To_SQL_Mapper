"""Clipboard tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    PermissionLevel,
    ReadClipboardParams,
    WriteClipboardParams,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.clipboard")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Clipboard Read Tool
async def clipboard_read_handler(params: dict[str, Any]) -> str:
    """Read clipboard contents."""
    adapter = get_adapter()
    read_params = ReadClipboardParams(**params)
    result = await adapter.read_clipboard(read_params)

    if not result.success:
        return f"Failed to read clipboard: {result.error}"

    clip = result.data
    if not clip or not clip.content:
        return "Clipboard is empty."

    content = clip.content
    if len(content) > 1000:
        content = content[:1000] + f"... ({len(clip.content)} total chars)"

    return f"Clipboard contents ({clip.format}):\n{content}"


CLIPBOARD_READ = ToolDefinition(
    name="clipboard_read",
    description="Read the contents of the clipboard",
    parameters={
        "type": "object",
        "properties": {
            "format": {
                "type": "string",
                "enum": ["text", "html"],
                "description": "Content format to read",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=clipboard_read_handler,
)


# Clipboard Write Tool
async def clipboard_write_handler(params: dict[str, Any]) -> str:
    """Write to clipboard."""
    adapter = get_adapter()
    write_params = WriteClipboardParams(**params)
    result = await adapter.write_clipboard(write_params)

    if not result.success:
        return f"Failed to write to clipboard: {result.error}"

    return f"Copied {len(write_params.content)} characters to clipboard"


CLIPBOARD_WRITE = ToolDefinition(
    name="clipboard_write",
    description="Write content to the clipboard",
    parameters={
        "type": "object",
        "properties": {
            "content": {
                "type": "string",
                "description": "Content to copy to clipboard",
            },
            "format": {
                "type": "string",
                "enum": ["text", "html"],
                "description": "Content format",
            },
        },
        "required": ["content"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=clipboard_write_handler,
)


# Clipboard Clear Tool
async def clipboard_clear_handler(params: dict[str, Any]) -> str:
    """Clear the clipboard."""
    adapter = get_adapter()
    result = await adapter.clear_clipboard()

    if not result.success:
        return f"Failed to clear clipboard: {result.error}"

    return "Clipboard cleared"


CLIPBOARD_CLEAR = ToolDefinition(
    name="clipboard_clear",
    description="Clear the clipboard contents",
    parameters={
        "type": "object",
        "properties": {},
        "required": [],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=clipboard_clear_handler,
)


# Export all clipboard tools
CLIPBOARD_TOOLS = [
    CLIPBOARD_READ,
    CLIPBOARD_WRITE,
    CLIPBOARD_CLEAR,
]
