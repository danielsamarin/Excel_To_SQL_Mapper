"""Office document tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    PermissionLevel,
    PowerPointCreateParams,
    SlideContent,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.office")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Office Create Tool
async def office_create_handler(params: dict[str, Any]) -> str:
    """Create an Office document."""
    import subprocess
    from pathlib import Path

    doc_type = params.get("type", "word")
    path = params.get("path", "")

    # Map type to Office application
    app_map = {
        "word": "winword",
        "excel": "excel",
        "powerpoint": "powerpnt",
        "outlook": "outlook",
    }

    app = app_map.get(doc_type)
    if not app:
        return f"Unknown document type: {doc_type}"

    try:
        if path:
            # Create parent directory if needed
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            # Open with specific file
            subprocess.Popen([app, path], shell=True)
            return f"Opening {doc_type} with file: {path}"
        else:
            # Open new document
            subprocess.Popen([app], shell=True)
            return f"Opened new {doc_type} document"
    except Exception as e:
        return f"Failed to open {doc_type}: {e}"


OFFICE_CREATE = ToolDefinition(
    name="office_create",
    description="Create or open a Microsoft Office document",
    parameters={
        "type": "object",
        "properties": {
            "type": {
                "type": "string",
                "enum": ["word", "excel", "powerpoint", "outlook"],
                "description": "Type of document to create",
            },
            "path": {
                "type": "string",
                "description": "File path (optional - creates new if not specified)",
            },
        },
        "required": ["type"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=office_create_handler,
)


# PowerPoint Create Tool
async def powerpoint_create_handler(params: dict[str, Any]) -> str:
    """Create a PowerPoint presentation with slides."""
    adapter = get_adapter()

    # Parse slides
    slides_data = params.get("slides", [])
    slides = [SlideContent(**s) for s in slides_data]

    if not slides:
        return "No slides provided"

    ppt_params = PowerPointCreateParams(
        save_path=params.get("save_path", "presentation.pptx"),
        slides=slides,
    )

    result = await adapter.create_powerpoint(ppt_params)

    if not result.success:
        return f"Failed to create presentation: {result.error}"

    return f"Created PowerPoint with {len(slides)} slides: {ppt_params.save_path}"


POWERPOINT_CREATE = ToolDefinition(
    name="powerpoint_create",
    description="Create a PowerPoint presentation with multiple slides",
    parameters={
        "type": "object",
        "properties": {
            "save_path": {
                "type": "string",
                "description": "Path to save the presentation",
            },
            "slides": {
                "type": "array",
                "description": "Array of slides to create",
                "items": {
                    "type": "object",
                    "properties": {
                        "layout": {
                            "type": "string",
                            "enum": ["title", "title_content", "two_column", "blank"],
                            "description": "Slide layout",
                        },
                        "title": {
                            "type": "string",
                            "description": "Slide title",
                        },
                        "content": {
                            "type": "string",
                            "description": "Slide content/body text",
                        },
                        "notes": {
                            "type": "string",
                            "description": "Speaker notes",
                        },
                    },
                },
            },
        },
        "required": ["save_path", "slides"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=powerpoint_create_handler,
)


# Export all office tools
OFFICE_TOOLS = [
    OFFICE_CREATE,
    POWERPOINT_CREATE,
]
