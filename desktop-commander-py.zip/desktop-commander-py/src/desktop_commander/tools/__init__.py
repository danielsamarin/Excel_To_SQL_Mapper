"""Tool definitions for Desktop Commander.

This module provides all tool definitions that can be used with the Copilot SDK.
Tools are organized by category and can be loaded individually or all at once.
"""

from desktop_commander.tools.window import WINDOW_TOOLS
from desktop_commander.tools.files import FILE_TOOLS
from desktop_commander.tools.apps import APP_TOOLS
from desktop_commander.tools.system import SYSTEM_TOOLS
from desktop_commander.tools.process import PROCESS_TOOLS
from desktop_commander.tools.clipboard import CLIPBOARD_TOOLS
from desktop_commander.tools.office import OFFICE_TOOLS

# All tools combined
ALL_TOOLS = [
    *WINDOW_TOOLS,
    *FILE_TOOLS,
    *APP_TOOLS,
    *SYSTEM_TOOLS,
    *PROCESS_TOOLS,
    *CLIPBOARD_TOOLS,
    *OFFICE_TOOLS,
]

__all__ = [
    "ALL_TOOLS",
    "WINDOW_TOOLS",
    "FILE_TOOLS",
    "APP_TOOLS",
    "SYSTEM_TOOLS",
    "PROCESS_TOOLS",
    "CLIPBOARD_TOOLS",
    "OFFICE_TOOLS",
]
