"""Window management tools."""

from typing import Any

from pydantic import BaseModel, Field

from desktop_commander.models.types import (
    ArrangeWindowsParams,
    CloseWindowParams,
    FocusWindowParams,
    MaximizeWindowParams,
    MinimizeWindowParams,
    MoveWindowParams,
    PermissionLevel,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.window")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Window List Tool
class WindowListParams(BaseModel):
    """Parameters for window_list (none required)."""
    pass


async def window_list_handler(params: dict[str, Any]) -> str:
    """List all open windows."""
    adapter = get_adapter()
    result = await adapter.list_windows()

    if not result.success:
        return f"Failed to list windows: {result.error}"

    windows = result.data or []
    if not windows:
        return "No windows found."

    lines = [f"Found {len(windows)} windows:"]
    for w in windows:
        status = []
        if w.is_focused:
            status.append("focused")
        if w.is_minimized:
            status.append("minimized")
        if w.is_maximized:
            status.append("maximized")
        status_str = f" ({', '.join(status)})" if status else ""
        lines.append(f"  - [{w.id}] {w.app}: {w.title}{status_str}")

    return "\n".join(lines)


WINDOW_LIST = ToolDefinition(
    name="window_list",
    description="List all open windows with their IDs, titles, and states",
    parameters={
        "type": "object",
        "properties": {},
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=window_list_handler,
)


# Window Focus Tool
async def window_focus_handler(params: dict[str, Any]) -> str:
    """Focus a window."""
    adapter = get_adapter()
    focus_params = FocusWindowParams(**params)
    result = await adapter.focus_window(focus_params)

    if not result.success:
        return f"Failed to focus window: {result.error}"

    target = focus_params.window_id or focus_params.app_name or focus_params.title_contains
    return f"Successfully focused window: {target}"


WINDOW_FOCUS = ToolDefinition(
    name="window_focus",
    description="Focus a window by ID, app name, or title. Brings the window to the foreground.",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID (from window_list)",
            },
            "app_name": {
                "type": "string",
                "description": "Application name to match",
            },
            "title_contains": {
                "type": "string",
                "description": "Substring to match in window title",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_focus_handler,
)


# Window Resize Tool
async def window_resize_handler(params: dict[str, Any]) -> str:
    """Resize and/or move a window."""
    adapter = get_adapter()
    move_params = MoveWindowParams(**params)
    result = await adapter.move_window(move_params)

    if not result.success:
        return f"Failed to resize window: {result.error}"

    changes = []
    if move_params.x is not None or move_params.y is not None:
        changes.append(f"position ({move_params.x}, {move_params.y})")
    if move_params.width is not None or move_params.height is not None:
        changes.append(f"size ({move_params.width}x{move_params.height})")

    return f"Successfully updated window {move_params.window_id}: {', '.join(changes)}"


WINDOW_RESIZE = ToolDefinition(
    name="window_resize",
    description="Resize and/or move a window to specific dimensions and position",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID to resize",
            },
            "x": {
                "type": "integer",
                "description": "New X position (pixels from left)",
            },
            "y": {
                "type": "integer",
                "description": "New Y position (pixels from top)",
            },
            "width": {
                "type": "integer",
                "description": "New width in pixels",
            },
            "height": {
                "type": "integer",
                "description": "New height in pixels",
            },
        },
        "required": ["window_id"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_resize_handler,
)


# Window Move Tool (alias for resize with position only)
WINDOW_MOVE = ToolDefinition(
    name="window_move",
    description="Move a window to a specific position",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID to move",
            },
            "x": {
                "type": "integer",
                "description": "New X position (pixels from left)",
            },
            "y": {
                "type": "integer",
                "description": "New Y position (pixels from top)",
            },
        },
        "required": ["window_id"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_resize_handler,  # Same handler
)


# Window Close Tool
async def window_close_handler(params: dict[str, Any]) -> str:
    """Close a window."""
    adapter = get_adapter()
    close_params = CloseWindowParams(**params)
    result = await adapter.close_window(close_params)

    if not result.success:
        return f"Failed to close window: {result.error}"

    target = close_params.window_id or close_params.app_name
    return f"Successfully closed window: {target}"


WINDOW_CLOSE = ToolDefinition(
    name="window_close",
    description="Close a window by ID or app name",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID to close",
            },
            "app_name": {
                "type": "string",
                "description": "Application name to close",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.SENSITIVE,
    handler=window_close_handler,
)


# Window Minimize Tool
async def window_minimize_handler(params: dict[str, Any]) -> str:
    """Minimize a window."""
    adapter = get_adapter()
    min_params = MinimizeWindowParams(**params)
    result = await adapter.minimize_window(min_params)

    if not result.success:
        return f"Failed to minimize window: {result.error}"

    return f"Successfully minimized window: {min_params.window_id}"


WINDOW_MINIMIZE = ToolDefinition(
    name="window_minimize",
    description="Minimize a window to the taskbar",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID to minimize",
            },
        },
        "required": ["window_id"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_minimize_handler,
)


# Window Maximize Tool
async def window_maximize_handler(params: dict[str, Any]) -> str:
    """Maximize a window."""
    adapter = get_adapter()
    max_params = MaximizeWindowParams(**params)
    result = await adapter.maximize_window(max_params)

    if not result.success:
        return f"Failed to maximize window: {result.error}"

    return f"Successfully maximized window: {max_params.window_id}"


WINDOW_MAXIMIZE = ToolDefinition(
    name="window_maximize",
    description="Maximize a window to fill the screen",
    parameters={
        "type": "object",
        "properties": {
            "window_id": {
                "type": "string",
                "description": "Window ID to maximize",
            },
        },
        "required": ["window_id"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_maximize_handler,
)


# Window Arrange Tool
async def window_arrange_handler(params: dict[str, Any]) -> str:
    """Arrange windows in a layout."""
    adapter = get_adapter()
    arrange_params = ArrangeWindowsParams(**params)
    result = await adapter.arrange_windows(arrange_params)

    if not result.success:
        return f"Failed to arrange windows: {result.error}"

    target = f"{len(arrange_params.windows)} windows" if arrange_params.windows else "all windows"
    return f"Successfully arranged {target} in {arrange_params.layout} layout"


WINDOW_ARRANGE = ToolDefinition(
    name="window_arrange",
    description="Arrange windows in a layout (left-half, right-half, grid, side-by-side, stacked, cascade)",
    parameters={
        "type": "object",
        "properties": {
            "layout": {
                "type": "string",
                "enum": ["left-half", "right-half", "top-half", "bottom-half", "grid", "side-by-side", "stacked", "cascade"],
                "description": "Layout to apply to windows",
            },
            "windows": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Window IDs to arrange (optional, defaults to all)",
            },
        },
        "required": ["layout"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=window_arrange_handler,
)


# Export all window tools
WINDOW_TOOLS = [
    WINDOW_LIST,
    WINDOW_FOCUS,
    WINDOW_RESIZE,
    WINDOW_MOVE,
    WINDOW_CLOSE,
    WINDOW_MINIMIZE,
    WINDOW_MAXIMIZE,
    WINDOW_ARRANGE,
]
