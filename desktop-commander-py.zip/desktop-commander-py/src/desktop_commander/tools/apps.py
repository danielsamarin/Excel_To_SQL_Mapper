"""Application management tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    LaunchAppParams,
    ListAppsParams,
    PermissionLevel,
    QuitAppParams,
    SwitchAppParams,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.apps")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Apps List Tool
async def apps_list_handler(params: dict[str, Any]) -> str:
    """List applications."""
    adapter = get_adapter()
    list_params = ListAppsParams(**params)
    result = await adapter.list_apps(list_params)

    if not result.success:
        return f"Failed to list apps: {result.error}"

    apps = result.data or []
    if not apps:
        return "No applications found."

    running = [a for a in apps if a.is_running]
    installed = [a for a in apps if not a.is_running]

    lines = []
    if running:
        lines.append(f"Running applications ({len(running)}):")
        for app in running[:20]:
            lines.append(f"  🟢 {app.name}")

    if installed and list_params.filter in ("installed", "all"):
        if lines:
            lines.append("")
        lines.append(f"Installed applications ({len(installed)}):")
        for app in installed[:30]:
            lines.append(f"  ⚪ {app.name}")

    return "\n".join(lines)


APPS_LIST = ToolDefinition(
    name="apps_list",
    description="List running and/or installed applications",
    parameters={
        "type": "object",
        "properties": {
            "filter": {
                "type": "string",
                "enum": ["running", "installed", "all"],
                "description": "Filter: running, installed, or all",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=apps_list_handler,
)


# Apps Launch Tool
async def apps_launch_handler(params: dict[str, Any]) -> str:
    """Launch an application."""
    adapter = get_adapter()
    launch_params = LaunchAppParams(**params)
    result = await adapter.launch_app(launch_params)

    if not result.success:
        return f"Failed to launch app: {result.error}"

    target = launch_params.name or launch_params.path
    return f"Successfully launched: {target}"


APPS_LAUNCH = ToolDefinition(
    name="apps_launch",
    description="Launch an application by name or path",
    parameters={
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Application name (e.g., 'chrome', 'notepad', 'vscode')",
            },
            "path": {
                "type": "string",
                "description": "Full path to executable",
            },
            "args": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Command line arguments",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=apps_launch_handler,
)


# Apps Quit Tool
async def apps_quit_handler(params: dict[str, Any]) -> str:
    """Quit an application."""
    adapter = get_adapter()
    quit_params = QuitAppParams(**params)
    result = await adapter.quit_app(quit_params)

    if not result.success:
        return f"Failed to quit app: {result.error}"

    return f"Successfully quit: {quit_params.name}"


APPS_QUIT = ToolDefinition(
    name="apps_quit",
    description="Quit a running application",
    parameters={
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Application name to quit",
            },
            "force": {
                "type": "boolean",
                "description": "Force quit without saving",
            },
        },
        "required": ["name"],
    },
    permission_level=PermissionLevel.SENSITIVE,
    handler=apps_quit_handler,
)


# Apps Switch Tool
async def apps_switch_handler(params: dict[str, Any]) -> str:
    """Switch to an application."""
    adapter = get_adapter()
    switch_params = SwitchAppParams(**params)
    result = await adapter.switch_app(switch_params)

    if not result.success:
        return f"Failed to switch app: {result.error}"

    return f"Switched to: {switch_params.name}"


APPS_SWITCH = ToolDefinition(
    name="apps_switch",
    description="Switch to a running application (bring to foreground)",
    parameters={
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Application name to switch to",
            },
        },
        "required": ["name"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=apps_switch_handler,
)


# Export all app tools
APP_TOOLS = [
    APPS_LIST,
    APPS_LAUNCH,
    APPS_QUIT,
    APPS_SWITCH,
]
