"""File system tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    CopyFilesParams,
    CreateFolderParams,
    DeleteFilesParams,
    FileFilter,
    GetFileInfoParams,
    ListFilesParams,
    MoveFilesParams,
    PermissionLevel,
    ReadFileParams,
    RenameFileParams,
    SearchFilesParams,
    WriteFileParams,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.files")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# Files List Tool
async def files_list_handler(params: dict[str, Any]) -> str:
    """List files in a directory."""
    adapter = get_adapter()

    # Build filter if provided
    file_filter = None
    if "filter" in params and params["filter"]:
        file_filter = FileFilter(**params["filter"])

    list_params = ListFilesParams(
        path=params.get("path", "."),
        recursive=params.get("recursive", False),
        filter=file_filter,
    )
    result = await adapter.list_files(list_params)

    if not result.success:
        return f"Failed to list files: {result.error}"

    files = result.data or []
    if not files:
        return f"No files found in {list_params.path}"

    lines = [f"Found {len(files)} items in {list_params.path}:"]
    for f in files[:50]:  # Limit output
        type_indicator = "📁" if f.is_directory else "📄"
        size_str = f" ({_format_size(f.size)})" if not f.is_directory else ""
        lines.append(f"  {type_indicator} {f.name}{size_str}")

    if len(files) > 50:
        lines.append(f"  ... and {len(files) - 50} more items")

    return "\n".join(lines)


FILES_LIST = ToolDefinition(
    name="files_list",
    description="List files and folders in a directory",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path to list",
            },
            "recursive": {
                "type": "boolean",
                "description": "Include subdirectories",
            },
            "filter": {
                "type": "object",
                "description": "Filter criteria",
                "properties": {
                    "extension": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "File extensions to include",
                    },
                    "name_contains": {
                        "type": "string",
                        "description": "Filter by name substring",
                    },
                },
            },
        },
        "required": ["path"],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=files_list_handler,
)


# Files Search Tool
async def files_search_handler(params: dict[str, Any]) -> str:
    """Search for files."""
    adapter = get_adapter()
    search_params = SearchFilesParams(**params)
    result = await adapter.search_files(search_params)

    if not result.success:
        return f"Failed to search files: {result.error}"

    files = result.data or []
    if not files:
        return f"No files found matching '{search_params.query}'"

    lines = [f"Found {len(files)} files matching '{search_params.query}':"]
    for f in files[:30]:
        type_indicator = "📁" if f.is_directory else "📄"
        lines.append(f"  {type_indicator} {f.path}")

    if len(files) > 30:
        lines.append(f"  ... and {len(files) - 30} more results")

    return "\n".join(lines)


FILES_SEARCH = ToolDefinition(
    name="files_search",
    description="Search for files by name pattern",
    parameters={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search pattern (supports wildcards: *.txt, doc*)",
            },
            "start_path": {
                "type": "string",
                "description": "Directory to start search from",
            },
            "max_results": {
                "type": "integer",
                "description": "Maximum number of results",
            },
        },
        "required": ["query", "start_path"],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=files_search_handler,
)


# Files Move Tool
async def files_move_handler(params: dict[str, Any]) -> str:
    """Move files."""
    adapter = get_adapter()
    move_params = MoveFilesParams(**params)
    result = await adapter.move_files(move_params)

    if not result.success:
        return f"Failed to move files: {result.error}"

    return f"Successfully moved {move_params.source} to {move_params.destination}"


FILES_MOVE = ToolDefinition(
    name="files_move",
    description="Move a file or folder to a new location",
    parameters={
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "description": "Source path",
            },
            "destination": {
                "type": "string",
                "description": "Destination path",
            },
            "overwrite": {
                "type": "boolean",
                "description": "Overwrite if destination exists",
            },
        },
        "required": ["source", "destination"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=files_move_handler,
)


# Files Copy Tool
async def files_copy_handler(params: dict[str, Any]) -> str:
    """Copy files."""
    adapter = get_adapter()
    copy_params = CopyFilesParams(**params)
    result = await adapter.copy_files(copy_params)

    if not result.success:
        return f"Failed to copy files: {result.error}"

    return f"Successfully copied {copy_params.source} to {copy_params.destination}"


FILES_COPY = ToolDefinition(
    name="files_copy",
    description="Copy a file or folder to a new location",
    parameters={
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "description": "Source path",
            },
            "destination": {
                "type": "string",
                "description": "Destination path",
            },
            "overwrite": {
                "type": "boolean",
                "description": "Overwrite if destination exists",
            },
        },
        "required": ["source", "destination"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=files_copy_handler,
)


# Files Delete Tool
async def files_delete_handler(params: dict[str, Any]) -> str:
    """Delete files."""
    adapter = get_adapter()
    delete_params = DeleteFilesParams(**params)
    result = await adapter.delete_files(delete_params)

    if not result.success:
        return f"Failed to delete files: {result.error}"

    count = len(delete_params.paths)
    action = "moved to trash" if delete_params.move_to_trash else "permanently deleted"
    return f"Successfully {action} {count} item(s)"


FILES_DELETE = ToolDefinition(
    name="files_delete",
    description="Delete files or folders (moves to trash by default)",
    parameters={
        "type": "object",
        "properties": {
            "paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Paths to delete",
            },
            "move_to_trash": {
                "type": "boolean",
                "description": "Move to trash instead of permanent delete (default: true)",
            },
        },
        "required": ["paths"],
    },
    permission_level=PermissionLevel.DANGEROUS,
    handler=files_delete_handler,
)


# Files Rename Tool
async def files_rename_handler(params: dict[str, Any]) -> str:
    """Rename a file."""
    adapter = get_adapter()
    rename_params = RenameFileParams(**params)
    result = await adapter.rename_file(rename_params)

    if not result.success:
        return f"Failed to rename file: {result.error}"

    return f"Successfully renamed to {rename_params.new_name}"


FILES_RENAME = ToolDefinition(
    name="files_rename",
    description="Rename a file or folder",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Current file path",
            },
            "new_name": {
                "type": "string",
                "description": "New name (not full path)",
            },
        },
        "required": ["path", "new_name"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=files_rename_handler,
)


# Files Create Folder Tool
async def files_create_folder_handler(params: dict[str, Any]) -> str:
    """Create a folder."""
    adapter = get_adapter()
    create_params = CreateFolderParams(**params)
    result = await adapter.create_folder(create_params)

    if not result.success:
        return f"Failed to create folder: {result.error}"

    return f"Successfully created folder: {create_params.path}"


FILES_CREATE_FOLDER = ToolDefinition(
    name="files_create_folder",
    description="Create a new folder",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Folder path to create",
            },
        },
        "required": ["path"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=files_create_folder_handler,
)


# Files Read Tool
async def files_read_handler(params: dict[str, Any]) -> str:
    """Read file contents."""
    adapter = get_adapter()
    read_params = ReadFileParams(**params)
    result = await adapter.read_file(read_params)

    if not result.success:
        return f"Failed to read file: {result.error}"

    content = result.data or ""
    lines = content.count('\n') + 1
    return f"File contents ({lines} lines):\n\n{content}"


FILES_READ = ToolDefinition(
    name="files_read",
    description="Read the contents of a text file",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path to read",
            },
            "encoding": {
                "type": "string",
                "description": "File encoding (default: utf-8)",
            },
            "max_size": {
                "type": "integer",
                "description": "Maximum file size in bytes",
            },
        },
        "required": ["path"],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=files_read_handler,
)


# Files Write Tool
async def files_write_handler(params: dict[str, Any]) -> str:
    """Write to a file."""
    adapter = get_adapter()
    write_params = WriteFileParams(**params)
    result = await adapter.write_file(write_params)

    if not result.success:
        return f"Failed to write file: {result.error}"

    action = "appended to" if write_params.append else "wrote to"
    return f"Successfully {action} {write_params.path}"


FILES_WRITE = ToolDefinition(
    name="files_write",
    description="Write content to a file",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path to write",
            },
            "content": {
                "type": "string",
                "description": "Content to write",
            },
            "encoding": {
                "type": "string",
                "description": "File encoding (default: utf-8)",
            },
            "append": {
                "type": "boolean",
                "description": "Append to file instead of overwriting",
            },
        },
        "required": ["path", "content"],
    },
    permission_level=PermissionLevel.SENSITIVE,
    handler=files_write_handler,
)


# Files Info Tool
async def files_info_handler(params: dict[str, Any]) -> str:
    """Get file information."""
    adapter = get_adapter()
    info_params = GetFileInfoParams(**params)
    result = await adapter.get_file_info(info_params)

    if not result.success:
        return f"Failed to get file info: {result.error}"

    f = result.data
    if not f:
        return "File not found"

    type_str = "Directory" if f.is_directory else "File"
    lines = [
        f"Name: {f.name}",
        f"Type: {type_str}",
        f"Path: {f.path}",
        f"Size: {_format_size(f.size)}",
        f"Created: {f.created.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Modified: {f.modified.strftime('%Y-%m-%d %H:%M:%S')}",
    ]
    if f.extension:
        lines.append(f"Extension: .{f.extension}")

    return "\n".join(lines)


FILES_INFO = ToolDefinition(
    name="files_info",
    description="Get detailed information about a file or folder",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path",
            },
        },
        "required": ["path"],
    },
    permission_level=PermissionLevel.READ_ONLY,
    handler=files_info_handler,
)


def _format_size(size: int) -> str:
    """Format file size to human-readable string."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


# Export all file tools
FILE_TOOLS = [
    FILES_LIST,
    FILES_SEARCH,
    FILES_MOVE,
    FILES_COPY,
    FILES_DELETE,
    FILES_RENAME,
    FILES_CREATE_FOLDER,
    FILES_READ,
    FILES_WRITE,
    FILES_INFO,
]
