"""System control tools."""

from typing import Any

from pydantic import BaseModel

from desktop_commander.models.types import (
    Bounds,
    BrightnessParams,
    DndParams,
    PermissionLevel,
    ScreenshotParams,
    VolumeParams,
)
from desktop_commander.platform import get_adapter
from desktop_commander.utils.logger import get_logger

logger = get_logger("tools.system")


class ToolDefinition(BaseModel):
    """Tool definition for Copilot SDK."""
    name: str
    description: str
    parameters: dict[str, Any]
    permission_level: PermissionLevel = PermissionLevel.STANDARD
    handler: Any = None


# System Volume Tool
async def system_volume_handler(params: dict[str, Any]) -> str:
    """Control system volume."""
    adapter = get_adapter()
    volume_params = VolumeParams(**params)
    result = await adapter.control_volume(volume_params)

    if not result.success:
        return f"Failed to control volume: {result.error}"

    vol = result.data
    if not vol:
        return "Could not get volume status"

    mute_str = " (muted)" if vol.is_muted else ""
    return f"Volume: {vol.level}%{mute_str}"


SYSTEM_VOLUME = ToolDefinition(
    name="system_volume",
    description="Get or set system volume level",
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["get", "set", "mute", "unmute"],
                "description": "Action to perform",
            },
            "level": {
                "type": "integer",
                "minimum": 0,
                "maximum": 100,
                "description": "Volume level (0-100) for set action",
            },
        },
        "required": ["action"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=system_volume_handler,
)


# System Brightness Tool
async def system_brightness_handler(params: dict[str, Any]) -> str:
    """Control display brightness."""
    adapter = get_adapter()
    brightness_params = BrightnessParams(**params)
    result = await adapter.control_brightness(brightness_params)

    if not result.success:
        return f"Failed to control brightness: {result.error}"

    br = result.data
    if not br:
        return "Could not get brightness"

    return f"Brightness: {br.level}%"


SYSTEM_BRIGHTNESS = ToolDefinition(
    name="system_brightness",
    description="Get or set display brightness level",
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["get", "set"],
                "description": "Action to perform",
            },
            "level": {
                "type": "integer",
                "minimum": 0,
                "maximum": 100,
                "description": "Brightness level (0-100) for set action",
            },
        },
        "required": ["action"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=system_brightness_handler,
)


# System Screenshot Tool
async def system_screenshot_handler(params: dict[str, Any]) -> str:
    """Take a screenshot."""
    adapter = get_adapter()

    # Build region if provided
    region = None
    if "region" in params and params["region"]:
        region = Bounds(**params["region"])

    screenshot_params = ScreenshotParams(
        region=region,
        save_path=params.get("save_path"),
        filename=params.get("filename"),
    )
    result = await adapter.take_screenshot(screenshot_params)

    if not result.success:
        return f"Failed to take screenshot: {result.error}"

    ss = result.data
    if not ss:
        return "Screenshot failed"

    return f"Screenshot saved: {ss.path} ({ss.width}x{ss.height})"


SYSTEM_SCREENSHOT = ToolDefinition(
    name="system_screenshot",
    description="Take a screenshot of the screen or a specific region",
    parameters={
        "type": "object",
        "properties": {
            "region": {
                "type": "object",
                "description": "Region to capture",
                "properties": {
                    "x": {"type": "integer"},
                    "y": {"type": "integer"},
                    "width": {"type": "integer"},
                    "height": {"type": "integer"},
                },
            },
            "save_path": {
                "type": "string",
                "description": "Directory to save screenshot",
            },
            "filename": {
                "type": "string",
                "description": "Custom filename (without extension)",
            },
        },
        "required": [],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=system_screenshot_handler,
)


# System DND Tool
async def system_dnd_handler(params: dict[str, Any]) -> str:
    """Control Do Not Disturb mode."""
    adapter = get_adapter()
    dnd_params = DndParams(**params)
    result = await adapter.control_dnd(dnd_params)

    if not result.success:
        return f"Failed to control DND: {result.error}"

    dnd = result.data
    if not dnd:
        return "Could not get DND status"

    status = "enabled" if dnd.enabled else "disabled"
    return f"Do Not Disturb is {status}"


SYSTEM_DND = ToolDefinition(
    name="system_dnd",
    description="Control Do Not Disturb / Focus Assist mode",
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["status", "on", "off"],
                "description": "Action to perform",
            },
            "duration": {
                "type": "integer",
                "description": "Duration in minutes (for 'on' action)",
            },
        },
        "required": ["action"],
    },
    permission_level=PermissionLevel.STANDARD,
    handler=system_dnd_handler,
)


# System Lock Tool
async def system_lock_handler(params: dict[str, Any]) -> str:
    """Lock the screen."""
    adapter = get_adapter()
    result = await adapter.lock_screen()

    if not result.success:
        return f"Failed to lock screen: {result.error}"

    return "Screen locked"


SYSTEM_LOCK = ToolDefinition(
    name="system_lock",
    description="Lock the computer screen",
    parameters={
        "type": "object",
        "properties": {},
        "required": [],
    },
    permission_level=PermissionLevel.SENSITIVE,
    handler=system_lock_handler,
)


# System Sleep Tool
async def system_sleep_handler(params: dict[str, Any]) -> str:
    """Put the system to sleep."""
    adapter = get_adapter()
    result = await adapter.sleep()

    if not result.success:
        return f"Failed to sleep: {result.error}"

    return "System going to sleep"


SYSTEM_SLEEP = ToolDefinition(
    name="system_sleep",
    description="Put the computer to sleep",
    parameters={
        "type": "object",
        "properties": {},
        "required": [],
    },
    permission_level=PermissionLevel.DANGEROUS,
    handler=system_sleep_handler,
)


# Export all system tools
SYSTEM_TOOLS = [
    SYSTEM_VOLUME,
    SYSTEM_BRIGHTNESS,
    SYSTEM_SCREENSHOT,
    SYSTEM_DND,
    SYSTEM_LOCK,
    SYSTEM_SLEEP,
]
