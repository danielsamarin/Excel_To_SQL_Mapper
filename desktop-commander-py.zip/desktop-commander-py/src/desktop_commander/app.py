"""Main application module for Desktop Commander."""

import asyncio
import sys

from nicegui import app, ui

from desktop_commander.copilot import get_copilot_controller
from desktop_commander.services.hotkeys import get_hotkey_manager, setup_default_hotkey
from desktop_commander.services.store import get_store
from desktop_commander.services.tray import create_tray
from desktop_commander.ui.main_window import CommandPalette
from desktop_commander.utils.logger import get_logger, setup_logging

logger = get_logger("app")


class DesktopCommanderApp:
    """Main application class for Desktop Commander."""

    def __init__(self, debug: bool = False) -> None:
        """Initialize the application.

        Args:
            debug: Enable debug logging
        """
        # Set up logging
        setup_logging(debug=debug)
        logger.info("Desktop Commander starting...")

        # Initialize components
        self.store = get_store()
        self.copilot = get_copilot_controller()
        self.hotkey_manager = get_hotkey_manager()
        self.tray = None
        self.palette: CommandPalette | None = None

        self._window_visible = True
        self._debug = debug

    def run(self, native: bool = True, port: int = 8080) -> None:
        """Run the application.

        Args:
            native: Run in native mode (pywebview window)
            port: Port for browser mode
        """
        # Set up system tray
        self._setup_tray()

        # Set up global hotkey
        self._setup_hotkey()

        # Create UI
        self._create_ui()

        # Run the application
        if native:
            self._run_native()
        else:
            self._run_browser(port)

    def _setup_tray(self) -> None:
        """Set up the system tray."""
        settings = self.store.get_settings()

        if settings.ui.show_in_tray:
            self.tray = create_tray(
                on_show=self._toggle_window,
                on_settings=self._show_settings,
                on_quit=self._quit,
            )
            self.tray.start()
            logger.info("System tray started")

    def _setup_hotkey(self) -> None:
        """Set up the global hotkey."""
        success = setup_default_hotkey(self._toggle_window)
        if success:
            settings = self.store.get_settings()
            logger.info(f"Global hotkey registered: {settings.hotkey}")
        else:
            logger.warning("Failed to register global hotkey")

    def _create_ui(self) -> None:
        """Create the main UI."""
        # Dark mode
        ui.dark_mode().enable()

        # Create command palette
        self.palette = CommandPalette()
        self.palette.build()

        # Set up shutdown handler
        app.on_shutdown(self._cleanup)

    def _run_native(self) -> None:
        """Run in native mode with pywebview."""
        settings = self.store.get_settings()

        ui.run(
            title="Desktop Commander",
            native=True,
            window_size=(600, 700),
            reload=False,
            show=True,
        )

    def _run_browser(self, port: int) -> None:
        """Run in browser mode.

        Args:
            port: Server port
        """
        ui.run(
            port=port,
            title="Desktop Commander",
            reload=self._debug,
            show=True,
        )

    def _toggle_window(self) -> None:
        """Toggle window visibility."""
        self._window_visible = not self._window_visible

        if self._window_visible:
            # Show window
            ui.run_javascript("window.focus()")
            logger.info("Window shown")
        else:
            # Hide window (minimize in native mode)
            ui.run_javascript("window.blur()")
            logger.info("Window hidden")

    def _show_settings(self) -> None:
        """Show settings dialog."""
        if self.palette:
            self.palette._show_settings()

    def _quit(self) -> None:
        """Quit the application."""
        logger.info("Quit requested")
        self._cleanup()
        app.shutdown()

    def _cleanup(self) -> None:
        """Clean up resources."""
        logger.info("Cleaning up...")

        # Stop tray
        if self.tray:
            self.tray.stop()

        # Unregister hotkeys
        self.hotkey_manager.unregister_all()

        # Destroy Copilot session
        asyncio.create_task(self.copilot.destroy())

        logger.info("Cleanup complete")


def main() -> None:
    """Main entry point for the application."""
    import argparse

    parser = argparse.ArgumentParser(description="Desktop Commander - AI-powered desktop automation")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--browser", action="store_true", help="Run in browser mode instead of native")
    parser.add_argument("--port", type=int, default=8080, help="Port for browser mode")

    args = parser.parse_args()

    app_instance = DesktopCommanderApp(debug=args.debug)
    app_instance.run(native=not args.browser, port=args.port)


if __name__ == "__main__":
    main()
