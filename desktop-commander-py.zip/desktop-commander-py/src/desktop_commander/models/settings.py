"""Settings models for Desktop Commander."""

from typing import Literal

from pydantic import BaseModel, Field

from desktop_commander.models.types import PermissionLevel


class PermissionSettings(BaseModel):
    """Permission-related settings."""
    default_level: PermissionLevel = PermissionLevel.STANDARD
    remember_choices: bool = True
    require_confirm_for: list[str] = Field(
        default_factory=lambda: ["files_delete", "process_kill", "system_sleep", "system_lock"]
    )


class ToolSettings(BaseModel):
    """Tool enable/disable settings."""
    enabled: list[str] = Field(default_factory=list)
    disabled: list[str] = Field(default_factory=list)


class UISettings(BaseModel):
    """UI-related settings."""
    show_in_tray: bool = True
    floating_window: bool = False
    toast_notifications: bool = True


class SafetySettings(BaseModel):
    """Safety-related settings."""
    max_files_per_operation: int = 100
    protected_paths: list[str] = Field(
        default_factory=lambda: [
            "C:\\Windows",
            "C:\\Program Files",
            "C:\\Program Files (x86)",
        ]
    )
    require_confirm_above: int = 10  # Confirm if operating on more than this many files


class Settings(BaseModel):
    """Application settings."""
    hotkey: str = "ctrl+shift+space"
    theme: Literal["light", "dark", "system"] = "system"
    permissions: PermissionSettings = Field(default_factory=PermissionSettings)
    tools: ToolSettings = Field(default_factory=ToolSettings)
    ui: UISettings = Field(default_factory=UISettings)
    safety: SafetySettings = Field(default_factory=SafetySettings)

    @classmethod
    def default(cls) -> "Settings":
        """Create default settings."""
        return cls()
