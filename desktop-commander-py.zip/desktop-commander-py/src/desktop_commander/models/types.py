"""Core type definitions for Desktop Commander."""

from datetime import datetime
from enum import Enum
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, Field


class PermissionLevel(str, Enum):
    """Permission levels for tool operations."""
    READ_ONLY = "read_only"
    STANDARD = "standard"
    SENSITIVE = "sensitive"
    DANGEROUS = "dangerous"


class Bounds(BaseModel):
    """Window or region bounds."""
    x: int
    y: int
    width: int
    height: int


class WindowInfo(BaseModel):
    """Information about a window."""
    id: str
    title: str
    app: str
    process_id: int
    bounds: Bounds
    is_minimized: bool = False
    is_maximized: bool = False
    is_focused: bool = False


class FileInfo(BaseModel):
    """Information about a file or directory."""
    name: str
    path: str
    is_directory: bool
    size: int
    created: datetime
    modified: datetime
    extension: str | None = None


class FileFilter(BaseModel):
    """Filter criteria for file operations."""
    extension: list[str] | None = None
    name_contains: str | None = None
    modified_after: datetime | None = None
    modified_before: datetime | None = None
    size_greater_than: int | None = None
    size_less_than: int | None = None


class AppInfo(BaseModel):
    """Information about an application."""
    name: str
    path: str
    is_running: bool = False
    process_id: int | None = None
    icon: str | None = None


class ProcessInfo(BaseModel):
    """Information about a process."""
    pid: int
    name: str
    cpu: float
    memory: float
    status: str


class VolumeResult(BaseModel):
    """Result of a volume operation."""
    level: int
    is_muted: bool


class BrightnessResult(BaseModel):
    """Result of a brightness operation."""
    level: int


class ScreenshotResult(BaseModel):
    """Result of a screenshot operation."""
    path: str
    width: int
    height: int


class DndResult(BaseModel):
    """Result of a Do Not Disturb operation."""
    enabled: bool


class ClipboardResult(BaseModel):
    """Result of a clipboard read operation."""
    content: str
    format: str


T = TypeVar("T")


class OperationResult(BaseModel, Generic[T]):
    """Standardized result wrapper for all operations."""
    success: bool
    data: T | None = None
    error: str | None = None

    @classmethod
    def ok(cls, data: T | None = None) -> "OperationResult[T]":
        """Create a successful result."""
        return cls(success=True, data=data)

    @classmethod
    def fail(cls, error: str) -> "OperationResult[T]":
        """Create a failed result."""
        return cls(success=False, error=error)


class ToolCallStatus(str, Enum):
    """Status of a tool call."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"


class ToolCall(BaseModel):
    """Information about a tool call."""
    id: str
    name: str
    params: dict[str, Any] = Field(default_factory=dict)
    result: Any | None = None
    status: ToolCallStatus = ToolCallStatus.PENDING
    error: str | None = None


class MessageRole(str, Enum):
    """Role of a message sender."""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class Message(BaseModel):
    """A chat message."""
    id: str
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    tool_calls: list[ToolCall] = Field(default_factory=list)
    error: str | None = None


class StreamEventType(str, Enum):
    """Types of streaming events."""
    TEXT = "text"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    ERROR = "error"
    DONE = "done"


class StreamEvent(BaseModel):
    """A streaming event from the Copilot session."""
    type: StreamEventType
    content: str | None = None
    tool_name: str | None = None
    tool_args: dict[str, Any] | None = None
    result: Any | None = None
    error: str | None = None


# Parameter models for tool operations
class FocusWindowParams(BaseModel):
    """Parameters for focusing a window."""
    window_id: str | None = Field(None, description="Window ID to focus")
    app_name: str | None = Field(None, description="App name to focus")
    title_contains: str | None = Field(None, description="Window title substring")


class MoveWindowParams(BaseModel):
    """Parameters for moving/resizing a window."""
    window_id: str
    x: int | None = None
    y: int | None = None
    width: int | None = None
    height: int | None = None


class CloseWindowParams(BaseModel):
    """Parameters for closing a window."""
    window_id: str | None = None
    app_name: str | None = None


class MinimizeWindowParams(BaseModel):
    """Parameters for minimizing a window."""
    window_id: str


class MaximizeWindowParams(BaseModel):
    """Parameters for maximizing a window."""
    window_id: str


class ArrangeWindowsParams(BaseModel):
    """Parameters for arranging windows."""
    layout: Literal[
        "left-half", "right-half", "top-half", "bottom-half",
        "grid", "side-by-side", "stacked", "cascade"
    ]
    windows: list[str] | None = Field(None, description="Window IDs to arrange")


class ListFilesParams(BaseModel):
    """Parameters for listing files."""
    path: str = Field(description="Directory path to list")
    recursive: bool = False
    filter: FileFilter | None = None


class SearchFilesParams(BaseModel):
    """Parameters for searching files."""
    query: str = Field(description="Search query (filename pattern)")
    start_path: str = Field(description="Directory to start search from")
    max_results: int = 100


class MoveFilesParams(BaseModel):
    """Parameters for moving files."""
    source: str = Field(description="Source path")
    destination: str = Field(description="Destination path")
    overwrite: bool = False


class CopyFilesParams(BaseModel):
    """Parameters for copying files."""
    source: str = Field(description="Source path")
    destination: str = Field(description="Destination path")
    overwrite: bool = False


class DeleteFilesParams(BaseModel):
    """Parameters for deleting files."""
    paths: list[str] = Field(description="Paths to delete")
    move_to_trash: bool = True


class RenameFileParams(BaseModel):
    """Parameters for renaming a file."""
    path: str = Field(description="Current file path")
    new_name: str = Field(description="New file name")


class CreateFolderParams(BaseModel):
    """Parameters for creating a folder."""
    path: str = Field(description="Folder path to create")


class ReadFileParams(BaseModel):
    """Parameters for reading a file."""
    path: str = Field(description="File path to read")
    encoding: str = "utf-8"
    max_size: int = 1024 * 1024  # 1MB default


class WriteFileParams(BaseModel):
    """Parameters for writing a file."""
    path: str = Field(description="File path to write")
    content: str = Field(description="Content to write")
    encoding: str = "utf-8"
    append: bool = False


class GetFileInfoParams(BaseModel):
    """Parameters for getting file info."""
    path: str = Field(description="File path")


class ListAppsParams(BaseModel):
    """Parameters for listing applications."""
    filter: Literal["running", "installed", "all"] = "all"


class LaunchAppParams(BaseModel):
    """Parameters for launching an application."""
    name: str | None = Field(None, description="App name")
    path: str | None = Field(None, description="App path")
    args: list[str] = Field(default_factory=list, description="Launch arguments")


class QuitAppParams(BaseModel):
    """Parameters for quitting an application."""
    name: str = Field(description="App name to quit")
    force: bool = False


class SwitchAppParams(BaseModel):
    """Parameters for switching to an application."""
    name: str = Field(description="App name to switch to")


class VolumeParams(BaseModel):
    """Parameters for volume control."""
    action: Literal["get", "set", "mute", "unmute"]
    level: int | None = Field(None, ge=0, le=100, description="Volume level (0-100)")


class BrightnessParams(BaseModel):
    """Parameters for brightness control."""
    action: Literal["get", "set"]
    level: int | None = Field(None, ge=0, le=100, description="Brightness level (0-100)")


class ScreenshotParams(BaseModel):
    """Parameters for taking a screenshot."""
    region: Bounds | None = None
    save_path: str | None = None
    filename: str | None = None


class DndParams(BaseModel):
    """Parameters for Do Not Disturb control."""
    action: Literal["status", "on", "off"]
    duration: int | None = Field(None, description="Duration in minutes")


class ListProcessesParams(BaseModel):
    """Parameters for listing processes."""
    sort_by: Literal["cpu", "memory", "name"] = "cpu"
    limit: int = 20


class GetProcessInfoParams(BaseModel):
    """Parameters for getting process info."""
    pid: int | None = None
    name: str | None = None


class KillProcessParams(BaseModel):
    """Parameters for killing a process."""
    pid: int | None = None
    name: str | None = None
    force: bool = False


class GetTopProcessesParams(BaseModel):
    """Parameters for getting top processes."""
    resource: Literal["cpu", "memory"] = "cpu"
    limit: int = 10


class ReadClipboardParams(BaseModel):
    """Parameters for reading clipboard."""
    format: Literal["text", "html"] = "text"


class WriteClipboardParams(BaseModel):
    """Parameters for writing to clipboard."""
    content: str = Field(description="Content to write")
    format: Literal["text", "html"] = "text"


class OfficeCreateParams(BaseModel):
    """Parameters for creating an Office document."""
    type: Literal["word", "excel", "powerpoint", "outlook"]
    path: str = Field(description="Save path for the document")


class SlideContent(BaseModel):
    """Content for a PowerPoint slide."""
    layout: Literal["title", "title_content", "two_column", "blank"] = "title_content"
    title: str | None = None
    content: str | None = None
    notes: str | None = None


class PowerPointCreateParams(BaseModel):
    """Parameters for creating a PowerPoint presentation."""
    save_path: str = Field(description="Save path for the presentation")
    slides: list[SlideContent] = Field(description="Slides to create")
