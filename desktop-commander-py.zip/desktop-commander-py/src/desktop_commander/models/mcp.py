"""MCP (Model Context Protocol) server configuration models."""

from typing import Literal, Union

from pydantic import BaseModel, Field


class MCPServerConfigBase(BaseModel):
    """Base configuration for MCP servers."""
    name: str
    tools: Literal["*"] | list[str] = "*"
    enabled: bool = True
    timeout: int | None = None


class MCPLocalServerConfig(MCPServerConfigBase):
    """Configuration for local/stdio MCP servers."""
    type: Literal["local", "stdio"]
    command: str
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] | None = None
    cwd: str | None = None


class MCPRemoteServerConfig(MCPServerConfigBase):
    """Configuration for remote HTTP/SSE MCP servers."""
    type: Literal["http", "sse"]
    url: str
    headers: dict[str, str] | None = None


MCPServerConfig = Union[MCPLocalServerConfig, MCPRemoteServerConfig]


class StoredMCPServer(BaseModel):
    """Stored MCP server with metadata."""
    id: str
    config: MCPServerConfig
    created_at: int
    updated_at: int
