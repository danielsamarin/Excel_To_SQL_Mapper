"""Copilot SDK integration for Desktop Commander."""

from desktop_commander.copilot.client import CopilotController, get_copilot_controller

__all__ = ["CopilotController", "get_copilot_controller"]
