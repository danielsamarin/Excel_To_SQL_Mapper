"""Copilot SDK client controller for Desktop Commander.

This module provides the CopilotController class that manages:
- Copilot session lifecycle
- Tool registration and execution
- Streaming message handling
- MCP server configuration

Note: This implementation is designed to work with the github-copilot-sdk
when it becomes available. Currently includes a mock implementation for
development and testing.
"""

import asyncio
from collections.abc import AsyncGenerator
from typing import Any, Callable

from desktop_commander.models.mcp import MCPLocalServerConfig, MCPRemoteServerConfig
from desktop_commander.models.types import StreamEvent, StreamEventType
from desktop_commander.services.store import get_store
from desktop_commander.tools import ALL_TOOLS
from desktop_commander.utils.logger import get_logger

logger = get_logger("copilot")

_controller_instance: "CopilotController | None" = None


# System prompt for Desktop Commander
SYSTEM_PROMPT = """You are Desktop Commander, an AI assistant that helps users control their computer using natural language.

You have access to the following tools for desktop automation:

WINDOW MANAGEMENT:
- window_list: List all open windows
- window_focus: Focus a specific window
- window_resize/window_move: Move or resize windows
- window_close: Close a window
- window_minimize/window_maximize: Minimize or maximize windows
- window_arrange: Arrange windows in layouts (grid, side-by-side, etc.)

FILE OPERATIONS:
- files_list: List files in a directory
- files_search: Search for files by name
- files_move/files_copy: Move or copy files
- files_delete: Delete files (moves to trash by default)
- files_rename: Rename files
- files_create_folder: Create new folders
- files_read/files_write: Read or write file contents
- files_info: Get file information

APPLICATION MANAGEMENT:
- apps_list: List running or installed applications
- apps_launch: Launch applications
- apps_quit: Quit applications
- apps_switch: Switch to an application

SYSTEM CONTROL:
- system_volume: Get/set volume or mute/unmute
- system_brightness: Get/set screen brightness
- system_screenshot: Take screenshots
- system_dnd: Control Do Not Disturb mode
- system_lock: Lock the screen
- system_sleep: Put computer to sleep

PROCESS MANAGEMENT:
- process_list: List running processes
- process_info: Get process details
- process_kill: Kill a process
- process_top: Get top processes by CPU/memory

CLIPBOARD:
- clipboard_read: Read clipboard contents
- clipboard_write: Copy to clipboard
- clipboard_clear: Clear clipboard

OFFICE:
- office_create: Create Office documents
- powerpoint_create: Create PowerPoint presentations

GUIDELINES:
1. Always confirm understanding before executing destructive operations (delete, kill, quit)
2. Use window_list before window operations if the user doesn't specify which window
3. Provide clear feedback about what actions were taken
4. If a tool fails, explain what went wrong and suggest alternatives
5. Be helpful and concise in responses
"""


class CopilotController:
    """Controller for Copilot SDK integration.

    Manages the Copilot session, tool registration, and message streaming.
    Implements the singleton pattern for app-wide access.
    """

    def __init__(self) -> None:
        """Initialize the Copilot controller."""
        self._is_initialized = False
        self._session_id: str | None = None
        self._event_queue: asyncio.Queue[StreamEvent] = asyncio.Queue()
        self._is_streaming = False
        self._tool_handlers: dict[str, Callable] = {}
        self._mcp_servers_changed = False

        # Register tool handlers
        self._register_tools()

        logger.info("CopilotController initialized")

    def _register_tools(self) -> None:
        """Register all tool handlers."""
        for tool in ALL_TOOLS:
            if tool.handler:
                self._tool_handlers[tool.name] = tool.handler
                logger.debug(f"Registered tool: {tool.name}")

        logger.info(f"Registered {len(self._tool_handlers)} tools")

    async def initialize(self) -> None:
        """Initialize the Copilot session.

        Creates a new session with all registered tools and MCP servers.
        """
        if self._is_initialized:
            logger.info("Session already initialized")
            return

        try:
            # Build MCP server configuration
            mcp_config = self._build_mcp_config()

            # TODO: Replace with actual Copilot SDK initialization
            # Example expected API:
            # self._client = CopilotClient()
            # self._session = await self._client.create_session(
            #     tools=self._get_tool_definitions(),
            #     mcp_servers=mcp_config,
            #     system_prompt=SYSTEM_PROMPT,
            # )

            self._session_id = "mock-session-id"
            self._is_initialized = True
            self._mcp_servers_changed = False

            logger.info("Copilot session initialized")

        except Exception as e:
            logger.error(f"Failed to initialize Copilot session: {e}")
            raise

    def _build_mcp_config(self) -> dict[str, Any]:
        """Build MCP server configuration from stored servers.

        Returns:
            Dictionary of MCP server configurations for the SDK
        """
        store = get_store()
        servers = store.get_enabled_mcp_servers()

        mcp_config: dict[str, Any] = {}

        for server in servers:
            config = server.config

            if isinstance(config, MCPLocalServerConfig):
                mcp_config[config.name] = {
                    "type": config.type,
                    "command": config.command,
                    "args": config.args,
                    "env": config.env,
                    "cwd": config.cwd,
                }
            elif isinstance(config, MCPRemoteServerConfig):
                mcp_config[config.name] = {
                    "type": config.type,
                    "url": config.url,
                    "headers": config.headers,
                }

        logger.info(f"Built MCP config with {len(mcp_config)} servers")
        return mcp_config

    def _get_tool_definitions(self) -> list[dict[str, Any]]:
        """Get tool definitions for the SDK.

        Returns:
            List of tool definitions in SDK format
        """
        definitions = []
        for tool in ALL_TOOLS:
            definitions.append({
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            })
        return definitions

    async def send_message(self, message: str) -> AsyncGenerator[StreamEvent, None]:
        """Send a message and stream the response.

        Args:
            message: User message to send

        Yields:
            StreamEvent objects as the response is generated
        """
        # Reinitialize if MCP servers changed
        if self._mcp_servers_changed:
            self._is_initialized = False
            await self.initialize()

        if not self._is_initialized:
            await self.initialize()

        self._is_streaming = True
        logger.info(f"Sending message: {message[:100]}...")

        try:
            # TODO: Replace with actual SDK streaming
            # Example expected API:
            # async for event in self._session.send(prompt=message):
            #     yield self._convert_event(event)

            # Mock implementation for development
            async for event in self._mock_response(message):
                yield event

        except Exception as e:
            logger.error(f"Error during message send: {e}")
            yield StreamEvent(type=StreamEventType.ERROR, error=str(e))

        finally:
            self._is_streaming = False
            yield StreamEvent(type=StreamEventType.DONE)

    async def _mock_response(self, message: str) -> AsyncGenerator[StreamEvent, None]:
        """Mock response generator for development.

        This will be replaced by actual SDK streaming when available.
        """
        # Check if message seems to request a tool
        message_lower = message.lower()

        # Window operations
        if "list windows" in message_lower or "show windows" in message_lower:
            yield StreamEvent(
                type=StreamEventType.TOOL_CALL,
                tool_name="window_list",
                tool_args={},
            )

            # Execute the tool
            handler = self._tool_handlers.get("window_list")
            if handler:
                result = await handler({})
                yield StreamEvent(
                    type=StreamEventType.TOOL_RESULT,
                    tool_name="window_list",
                    result=result,
                )

            yield StreamEvent(
                type=StreamEventType.TEXT,
                content="Here are the currently open windows.",
            )

        # Volume operations
        elif "volume" in message_lower:
            if "set" in message_lower or any(c.isdigit() for c in message):
                # Extract number from message
                import re
                numbers = re.findall(r'\d+', message)
                level = int(numbers[0]) if numbers else 50

                yield StreamEvent(
                    type=StreamEventType.TOOL_CALL,
                    tool_name="system_volume",
                    tool_args={"action": "set", "level": level},
                )

                handler = self._tool_handlers.get("system_volume")
                if handler:
                    result = await handler({"action": "set", "level": level})
                    yield StreamEvent(
                        type=StreamEventType.TOOL_RESULT,
                        tool_name="system_volume",
                        result=result,
                    )
            else:
                yield StreamEvent(
                    type=StreamEventType.TOOL_CALL,
                    tool_name="system_volume",
                    tool_args={"action": "get"},
                )

                handler = self._tool_handlers.get("system_volume")
                if handler:
                    result = await handler({"action": "get"})
                    yield StreamEvent(
                        type=StreamEventType.TOOL_RESULT,
                        tool_name="system_volume",
                        result=result,
                    )

        # Process list
        elif "process" in message_lower or "top" in message_lower:
            yield StreamEvent(
                type=StreamEventType.TOOL_CALL,
                tool_name="process_list",
                tool_args={"sort_by": "cpu", "limit": 10},
            )

            handler = self._tool_handlers.get("process_list")
            if handler:
                result = await handler({"sort_by": "cpu", "limit": 10})
                yield StreamEvent(
                    type=StreamEventType.TOOL_RESULT,
                    tool_name="process_list",
                    result=result,
                )

        # Screenshot
        elif "screenshot" in message_lower:
            yield StreamEvent(
                type=StreamEventType.TOOL_CALL,
                tool_name="system_screenshot",
                tool_args={},
            )

            handler = self._tool_handlers.get("system_screenshot")
            if handler:
                result = await handler({})
                yield StreamEvent(
                    type=StreamEventType.TOOL_RESULT,
                    tool_name="system_screenshot",
                    result=result,
                )

        # Apps list
        elif "apps" in message_lower or "applications" in message_lower:
            yield StreamEvent(
                type=StreamEventType.TOOL_CALL,
                tool_name="apps_list",
                tool_args={"filter": "running"},
            )

            handler = self._tool_handlers.get("apps_list")
            if handler:
                result = await handler({"filter": "running"})
                yield StreamEvent(
                    type=StreamEventType.TOOL_RESULT,
                    tool_name="apps_list",
                    result=result,
                )

        # Default response
        else:
            yield StreamEvent(
                type=StreamEventType.TEXT,
                content=f"I understand you want to: {message}\n\n"
                "I can help you with window management, file operations, "
                "system control, and more. Try asking me to:\n"
                "- List windows\n"
                "- Set volume to 50%\n"
                "- Take a screenshot\n"
                "- List running apps\n"
                "- Show top processes",
            )

        await asyncio.sleep(0.1)  # Small delay for natural feel

    async def cancel(self) -> None:
        """Cancel the current streaming operation."""
        if self._is_streaming:
            self._is_streaming = False
            logger.info("Streaming cancelled")

    async def clear_history(self) -> None:
        """Clear the conversation history."""
        # TODO: Implement with actual SDK
        # await self._session.clear_history()
        logger.info("Conversation history cleared")

    async def destroy(self) -> None:
        """Clean up resources and destroy the session."""
        if self._is_initialized:
            # TODO: Implement with actual SDK
            # await self._session.destroy()
            # await self._client.close()
            self._is_initialized = False
            self._session_id = None
            logger.info("Copilot session destroyed")

    def notify_mcp_servers_changed(self) -> None:
        """Notify that MCP server configuration has changed.

        The session will be reinitialized on the next message.
        """
        self._mcp_servers_changed = True
        logger.info("MCP servers changed, will reinitialize on next message")

    @property
    def is_initialized(self) -> bool:
        """Check if the session is initialized."""
        return self._is_initialized

    @property
    def is_streaming(self) -> bool:
        """Check if currently streaming a response."""
        return self._is_streaming


def get_copilot_controller() -> CopilotController:
    """Get the singleton Copilot controller instance.

    Returns:
        CopilotController instance
    """
    global _controller_instance
    if _controller_instance is None:
        _controller_instance = CopilotController()
    return _controller_instance
