"""Entry point for running Desktop Commander as a module.

This allows running the application with:
    python -m desktop_commander
"""

from desktop_commander.app import main

if __name__ == "__main__":
    main()
