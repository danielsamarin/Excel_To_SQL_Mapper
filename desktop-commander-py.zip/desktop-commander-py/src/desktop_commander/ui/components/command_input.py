"""Command input component."""

from collections.abc import Callable

from nicegui import ui


class CommandInput:
    """Text input component for entering commands."""

    def __init__(
        self,
        on_submit: Callable[[str], None],
        placeholder: str = "Ask me to control your desktop...",
    ) -> None:
        """Initialize the command input.

        Args:
            on_submit: Callback when command is submitted
            placeholder: Input placeholder text
        """
        self.on_submit = on_submit
        self.placeholder = placeholder
        self.textarea: ui.textarea | None = None
        self._is_loading = False

    def build(self) -> "CommandInput":
        """Build the command input component."""
        with ui.row().classes("w-full gap-2"):
            self.textarea = (
                ui.textarea(placeholder=self.placeholder)
                .classes("flex-grow")
                .props("autogrow outlined")
                .on("keydown.enter.prevent", self._handle_enter)
            )
            ui.button(icon="send", on_click=self._handle_submit).props(
                "round color=primary"
            ).bind_enabled_from(self, "_is_loading", lambda x: not x)

        return self

    def _handle_enter(self) -> None:
        """Handle Enter key press."""
        self._handle_submit()

    def _handle_submit(self) -> None:
        """Handle command submission."""
        if not self.textarea or self._is_loading:
            return

        value = self.textarea.value.strip()
        if not value:
            return

        self.textarea.value = ""
        self.on_submit(value)

    def set_loading(self, loading: bool) -> None:
        """Set loading state.

        Args:
            loading: Whether the input is in loading state
        """
        self._is_loading = loading

    def set_value(self, value: str) -> None:
        """Set the input value.

        Args:
            value: Value to set
        """
        if self.textarea:
            self.textarea.value = value

    def focus(self) -> None:
        """Focus the input field."""
        if self.textarea:
            self.textarea.run_method("focus")
