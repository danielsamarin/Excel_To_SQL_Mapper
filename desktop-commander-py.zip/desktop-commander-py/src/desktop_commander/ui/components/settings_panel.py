"""Settings panel component."""

from collections.abc import Callable
from typing import Any

from nicegui import ui

from desktop_commander.models.settings import Settings
from desktop_commander.services.store import get_store


class SettingsPanel:
    """Settings configuration panel."""

    def __init__(self, on_change: Callable[[Settings], None] | None = None) -> None:
        """Initialize the settings panel.

        Args:
            on_change: Callback when settings change
        """
        self.store = get_store()
        self.on_change = on_change
        self.dialog: ui.dialog | None = None

    def show(self) -> None:
        """Show the settings dialog."""
        settings = self.store.get_settings()

        with ui.dialog() as self.dialog, ui.card().classes("w-[500px]"):
            # Header
            with ui.row().classes("w-full justify-between items-center mb-4"):
                ui.label("Settings").classes("text-xl font-bold")
                ui.button(icon="close", on_click=self.dialog.close).props("flat round")

            # Settings tabs
            with ui.tabs().classes("w-full") as tabs:
                general_tab = ui.tab("General")
                ui_tab = ui.tab("UI")
                safety_tab = ui.tab("Safety")

            with ui.tab_panels(tabs, value=general_tab).classes("w-full"):
                # General settings
                with ui.tab_panel(general_tab):
                    self._build_general_settings(settings)

                # UI settings
                with ui.tab_panel(ui_tab):
                    self._build_ui_settings(settings)

                # Safety settings
                with ui.tab_panel(safety_tab):
                    self._build_safety_settings(settings)

        self.dialog.open()

    def _build_general_settings(self, settings: Settings) -> None:
        """Build general settings section."""
        with ui.column().classes("w-full gap-4"):
            # Theme
            ui.select(
                ["light", "dark", "system"],
                value=settings.theme,
                label="Theme",
                on_change=lambda e: self._update("theme", e.value),
            ).classes("w-full")

            # Hotkey
            ui.input(
                label="Global Hotkey",
                value=settings.hotkey,
                on_change=lambda e: self._update("hotkey", e.value),
            ).classes("w-full")
            ui.label("Press the hotkey combination to show/hide the app").classes(
                "text-xs text-gray-500"
            )

    def _build_ui_settings(self, settings: Settings) -> None:
        """Build UI settings section."""
        with ui.column().classes("w-full gap-4"):
            ui.checkbox(
                "Show in system tray",
                value=settings.ui.show_in_tray,
                on_change=lambda e: self._update_nested("ui", "show_in_tray", e.value),
            )

            ui.checkbox(
                "Floating window mode",
                value=settings.ui.floating_window,
                on_change=lambda e: self._update_nested(
                    "ui", "floating_window", e.value
                ),
            )

            ui.checkbox(
                "Toast notifications",
                value=settings.ui.toast_notifications,
                on_change=lambda e: self._update_nested(
                    "ui", "toast_notifications", e.value
                ),
            )

    def _build_safety_settings(self, settings: Settings) -> None:
        """Build safety settings section."""
        with ui.column().classes("w-full gap-4"):
            ui.number(
                label="Max files per operation",
                value=settings.safety.max_files_per_operation,
                min=1,
                max=1000,
                on_change=lambda e: self._update_nested(
                    "safety", "max_files_per_operation", int(e.value)
                ),
            ).classes("w-full")

            ui.number(
                label="Confirm when operating on more than N files",
                value=settings.safety.require_confirm_above,
                min=1,
                max=100,
                on_change=lambda e: self._update_nested(
                    "safety", "require_confirm_above", int(e.value)
                ),
            ).classes("w-full")

            ui.label("Protected paths (one per line):").classes("font-medium")
            ui.textarea(
                value="\n".join(settings.safety.protected_paths),
                on_change=lambda e: self._update_nested(
                    "safety",
                    "protected_paths",
                    [p.strip() for p in e.value.split("\n") if p.strip()],
                ),
            ).classes("w-full").props("outlined rows=5")

    def _update(self, key: str, value: Any) -> None:
        """Update a top-level setting."""
        settings = self.store.get_settings()
        updated = settings.model_copy(update={key: value})
        self.store.set_settings(updated)
        ui.notify(f"Setting updated: {key}", type="positive")

        if self.on_change:
            self.on_change(updated)

    def _update_nested(self, section: str, key: str, value: Any) -> None:
        """Update a nested setting."""
        settings = self.store.get_settings()
        section_obj = getattr(settings, section)
        updated_section = section_obj.model_copy(update={key: value})
        updated = settings.model_copy(update={section: updated_section})
        self.store.set_settings(updated)
        ui.notify(f"Setting updated: {section}.{key}", type="positive")

        if self.on_change:
            self.on_change(updated)
