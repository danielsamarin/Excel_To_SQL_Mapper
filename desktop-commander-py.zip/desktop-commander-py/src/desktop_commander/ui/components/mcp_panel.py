"""MCP servers panel component."""

import time
import uuid
from collections.abc import Callable

from nicegui import ui

from desktop_commander.models.mcp import (
    MCPLocalServerConfig,
    MCPRemoteServerConfig,
    MCPServerConfig,
    StoredMCPServer,
)
from desktop_commander.services.store import get_store


class MCPPanel:
    """Panel for managing MCP server configurations."""

    def __init__(self, on_change: Callable[[], None] | None = None) -> None:
        """Initialize the MCP panel.

        Args:
            on_change: Callback when servers change
        """
        self.store = get_store()
        self.on_change = on_change
        self.dialog: ui.dialog | None = None
        self.servers_container: ui.column | None = None

    def show(self) -> None:
        """Show the MCP servers dialog."""
        with ui.dialog() as self.dialog, ui.card().classes("w-[600px] max-h-[80vh]"):
            # Header
            with ui.row().classes("w-full justify-between items-center mb-4"):
                ui.label("MCP Servers").classes("text-xl font-bold")
                with ui.row().classes("gap-2"):
                    ui.button("Add Server", icon="add", on_click=self._show_add_dialog)
                    ui.button(icon="close", on_click=self.dialog.close).props("flat round")

            # Servers list
            with ui.scroll_area().classes("max-h-[400px]"):
                self.servers_container = ui.column().classes("w-full gap-2")
                self._render_servers()

        self.dialog.open()

    def _render_servers(self) -> None:
        """Render the list of MCP servers."""
        if not self.servers_container:
            return

        self.servers_container.clear()
        servers = self.store.get_mcp_servers()

        with self.servers_container:
            if not servers:
                with ui.column().classes("w-full items-center py-8"):
                    ui.icon("dns", size="3rem").classes("text-gray-400")
                    ui.label("No MCP servers configured").classes("text-gray-400")
                return

            for server_id, server in servers.items():
                self._render_server_card(server)

    def _render_server_card(self, server: StoredMCPServer) -> None:
        """Render a single server card."""
        config = server.config
        is_local = isinstance(config, MCPLocalServerConfig)

        with ui.card().classes("w-full"):
            with ui.row().classes("w-full justify-between items-center"):
                with ui.column().classes("gap-0"):
                    with ui.row().classes("items-center gap-2"):
                        ui.label(config.name).classes("font-bold")
                        ui.badge(
                            config.type,
                            color="blue" if is_local else "green",
                        )
                        if not config.enabled:
                            ui.badge("disabled", color="grey")

                    if is_local:
                        ui.label(f"Command: {config.command}").classes(
                            "text-xs text-gray-500"
                        )
                    else:
                        ui.label(f"URL: {config.url}").classes("text-xs text-gray-500")

                with ui.row().classes("gap-1"):
                    ui.switch(
                        value=config.enabled,
                        on_change=lambda e, s=server: self._toggle_server(s, e.value),
                    ).props("dense")
                    ui.button(
                        icon="edit",
                        on_click=lambda s=server: self._show_edit_dialog(s),
                    ).props("flat round dense")
                    ui.button(
                        icon="delete",
                        on_click=lambda s=server: self._delete_server(s),
                    ).props("flat round dense color=negative")

    def _show_add_dialog(self) -> None:
        """Show dialog to add a new server."""
        self._show_server_dialog()

    def _show_edit_dialog(self, server: StoredMCPServer) -> None:
        """Show dialog to edit a server."""
        self._show_server_dialog(server)

    def _show_server_dialog(self, server: StoredMCPServer | None = None) -> None:
        """Show dialog to add or edit a server."""
        is_edit = server is not None
        title = "Edit Server" if is_edit else "Add Server"

        # Initialize values
        name = server.config.name if server else ""
        server_type = server.config.type if server else "local"
        enabled = server.config.enabled if server else True

        # Local server values
        command = ""
        args = ""
        cwd = ""

        # Remote server values
        url = ""

        if server:
            config = server.config
            if isinstance(config, MCPLocalServerConfig):
                command = config.command
                args = " ".join(config.args)
                cwd = config.cwd or ""
            elif isinstance(config, MCPRemoteServerConfig):
                url = config.url

        with ui.dialog() as add_dialog, ui.card().classes("w-[400px]"):
            ui.label(title).classes("text-xl font-bold mb-4")

            # Name
            name_input = ui.input(label="Name", value=name).classes("w-full")

            # Type selector
            type_select = ui.select(
                ["local", "stdio", "http", "sse"],
                value=server_type,
                label="Type",
            ).classes("w-full")

            # Local server fields
            with ui.column().classes("w-full gap-2").bind_visibility_from(
                type_select, "value", lambda v: v in ("local", "stdio")
            ):
                command_input = ui.input(label="Command", value=command).classes("w-full")
                args_input = ui.input(label="Arguments (space separated)", value=args).classes(
                    "w-full"
                )
                cwd_input = ui.input(label="Working Directory (optional)", value=cwd).classes(
                    "w-full"
                )

            # Remote server fields
            with ui.column().classes("w-full gap-2").bind_visibility_from(
                type_select, "value", lambda v: v in ("http", "sse")
            ):
                url_input = ui.input(label="URL", value=url).classes("w-full")

            # Enabled
            enabled_check = ui.checkbox("Enabled", value=enabled)

            # Actions
            with ui.row().classes("w-full justify-end mt-4 gap-2"):
                ui.button("Cancel", on_click=add_dialog.close).props("flat")
                ui.button(
                    "Save",
                    on_click=lambda: self._save_server(
                        add_dialog,
                        server.id if server else None,
                        name_input.value,
                        type_select.value,
                        enabled_check.value,
                        command_input.value,
                        args_input.value,
                        cwd_input.value,
                        url_input.value,
                    ),
                ).props("color=primary")

        add_dialog.open()

    def _save_server(
        self,
        dialog: ui.dialog,
        server_id: str | None,
        name: str,
        server_type: str,
        enabled: bool,
        command: str,
        args: str,
        cwd: str,
        url: str,
    ) -> None:
        """Save a server configuration."""
        if not name:
            ui.notify("Name is required", type="negative")
            return

        # Build config based on type
        config: MCPServerConfig
        if server_type in ("local", "stdio"):
            if not command:
                ui.notify("Command is required", type="negative")
                return
            config = MCPLocalServerConfig(
                name=name,
                type=server_type,  # type: ignore
                enabled=enabled,
                command=command,
                args=args.split() if args else [],
                cwd=cwd or None,
            )
        else:
            if not url:
                ui.notify("URL is required", type="negative")
                return
            config = MCPRemoteServerConfig(
                name=name,
                type=server_type,  # type: ignore
                enabled=enabled,
                url=url,
            )

        # Create or update server
        now = int(time.time() * 1000)
        stored_server = StoredMCPServer(
            id=server_id or str(uuid.uuid4()),
            config=config,
            created_at=now if not server_id else 0,  # Will be overwritten if updating
            updated_at=now,
        )

        self.store.add_mcp_server(stored_server)
        dialog.close()
        self._render_servers()
        ui.notify(f"Server {'updated' if server_id else 'added'}: {name}", type="positive")

        if self.on_change:
            self.on_change()

    def _toggle_server(self, server: StoredMCPServer, enabled: bool) -> None:
        """Toggle server enabled state."""
        config = server.config
        if isinstance(config, MCPLocalServerConfig):
            updated_config = MCPLocalServerConfig(
                name=config.name,
                type=config.type,
                enabled=enabled,
                command=config.command,
                args=config.args,
                env=config.env,
                cwd=config.cwd,
            )
        else:
            updated_config = MCPRemoteServerConfig(
                name=config.name,
                type=config.type,
                enabled=enabled,
                url=config.url,
                headers=config.headers,
            )

        updated_server = StoredMCPServer(
            id=server.id,
            config=updated_config,
            created_at=server.created_at,
            updated_at=int(time.time() * 1000),
        )

        self.store.add_mcp_server(updated_server)
        ui.notify(f"Server {'enabled' if enabled else 'disabled'}: {config.name}")

        if self.on_change:
            self.on_change()

    def _delete_server(self, server: StoredMCPServer) -> None:
        """Delete a server."""

        async def confirm_delete() -> None:
            confirm_dialog.close()
            self.store.remove_mcp_server(server.id)
            self._render_servers()
            ui.notify(f"Server removed: {server.config.name}", type="warning")

            if self.on_change:
                self.on_change()

        with ui.dialog() as confirm_dialog, ui.card():
            ui.label("Delete Server?").classes("text-lg font-bold")
            ui.label(f"Are you sure you want to delete '{server.config.name}'?")

            with ui.row().classes("w-full justify-end mt-4 gap-2"):
                ui.button("Cancel", on_click=confirm_dialog.close).props("flat")
                ui.button("Delete", on_click=confirm_delete).props("color=negative")

        confirm_dialog.open()
