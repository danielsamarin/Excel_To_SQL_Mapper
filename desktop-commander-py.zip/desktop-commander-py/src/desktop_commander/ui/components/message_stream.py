"""Message stream display component."""

from datetime import datetime
from typing import Any

from nicegui import ui

from desktop_commander.models.types import MessageRole


class MessageStream:
    """Component for displaying chat messages."""

    def __init__(self) -> None:
        """Initialize the message stream."""
        self.messages: list[dict[str, Any]] = []
        self.container: ui.column | None = None

    def build(self) -> "MessageStream":
        """Build the message stream component."""
        with ui.scroll_area().classes("flex-grow w-full"):
            self.container = ui.column().classes("w-full gap-4 p-2")
            self._render_empty_state()

        return self

    def add_message(
        self,
        role: MessageRole,
        content: str,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> None:
        """Add a message to the stream.

        Args:
            role: Message role (user/assistant)
            content: Message content
            tool_calls: Optional tool call information
        """
        self.messages.append({
            "role": role,
            "content": content,
            "tool_calls": tool_calls or [],
            "timestamp": datetime.now(),
        })
        self._render_messages()

    def update_last_message(
        self,
        content: str | None = None,
        append_content: str | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> None:
        """Update the last message in the stream.

        Args:
            content: New content (replaces existing)
            append_content: Content to append
            tool_calls: Tool calls to add
        """
        if not self.messages:
            return

        last = self.messages[-1]

        if content is not None:
            last["content"] = content
        if append_content is not None:
            last["content"] += append_content
        if tool_calls is not None:
            last["tool_calls"].extend(tool_calls)

        self._render_messages()

    def clear(self) -> None:
        """Clear all messages."""
        self.messages.clear()
        self._render_messages()

    def _render_messages(self) -> None:
        """Render all messages."""
        if not self.container:
            return

        self.container.clear()

        with self.container:
            if not self.messages:
                self._render_empty_state()
                return

            for msg in self.messages:
                self._render_message(msg)

    def _render_message(self, msg: dict[str, Any]) -> None:
        """Render a single message."""
        is_user = msg["role"] == MessageRole.USER
        alignment = "end" if is_user else "start"
        bg_color = "primary" if is_user else "grey-8"

        with ui.row().classes(f"w-full justify-{alignment}"):
            with ui.card().classes(f"max-w-[80%] bg-{bg_color}"):
                # Content
                if msg["content"]:
                    ui.markdown(msg["content"]).classes("text-white")

                # Tool calls
                if msg.get("tool_calls"):
                    with ui.expansion("Tool calls", icon="build").classes("mt-2"):
                        for tool in msg["tool_calls"]:
                            with ui.card().classes("bg-grey-9 mb-2"):
                                ui.label(f"🔧 {tool.get('name', 'Unknown')}").classes(
                                    "font-bold"
                                )
                                if tool.get("args"):
                                    ui.code(str(tool["args"])).classes("text-xs")
                                if tool.get("result"):
                                    ui.label("Result:").classes("text-xs mt-1")
                                    ui.code(str(tool["result"])).classes("text-xs")

                # Timestamp
                timestamp = msg.get("timestamp", datetime.now())
                ui.label(timestamp.strftime("%H:%M")).classes("text-xs text-gray-400 mt-1")

    def _render_empty_state(self) -> None:
        """Render empty state placeholder."""
        with ui.column().classes("w-full items-center justify-center py-8"):
            ui.icon("chat", size="4rem").classes("text-gray-400")
            ui.label("No messages yet").classes("text-gray-400 text-lg")
            ui.label("Try asking me to list windows or take a screenshot").classes(
                "text-gray-500 text-sm"
            )
