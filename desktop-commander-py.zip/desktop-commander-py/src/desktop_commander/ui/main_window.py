"""Main window UI for Desktop Commander using NiceGUI."""

import asyncio
from datetime import datetime
from typing import Any

from nicegui import app, ui

from desktop_commander.copilot import get_copilot_controller
from desktop_commander.models.types import MessageRole, StreamEventType
from desktop_commander.services.store import get_store
from desktop_commander.utils.logger import get_logger

logger = get_logger("ui")


class Message:
    """Represents a chat message."""

    def __init__(
        self,
        role: MessageRole,
        content: str,
        timestamp: datetime | None = None,
    ) -> None:
        self.role = role
        self.content = content
        self.timestamp = timestamp or datetime.now()
        self.tool_calls: list[dict[str, Any]] = []


class CommandPalette:
    """Main command palette UI component."""

    def __init__(self) -> None:
        self.messages: list[Message] = []
        self.is_loading = False
        self.input_text = ""
        self.chat_container: ui.column | None = None
        self.input_field: ui.textarea | None = None
        self.store = get_store()
        self.copilot = get_copilot_controller()

    def build(self) -> None:
        """Build the command palette UI."""
        # Set up dark theme
        ui.dark_mode().enable()

        with ui.column().classes("w-full max-w-2xl mx-auto h-screen p-4"):
            # Header
            with ui.row().classes("w-full items-center justify-between mb-4"):
                ui.label("Desktop Commander").classes("text-2xl font-bold")
                with ui.row().classes("gap-2"):
                    ui.button(icon="settings", on_click=self._show_settings).props(
                        "flat round"
                    )
                    ui.button(icon="delete", on_click=self._clear_chat).props(
                        "flat round"
                    ).tooltip("Clear conversation")

            # Chat container (scrollable)
            with ui.scroll_area().classes("flex-grow w-full"):
                self.chat_container = ui.column().classes("w-full gap-4")
                self._render_messages()

            # Input area
            with ui.column().classes("w-full mt-4"):
                with ui.row().classes("w-full gap-2"):
                    self.input_field = (
                        ui.textarea(placeholder="Ask me to control your desktop...")
                        .classes("flex-grow")
                        .props("autogrow outlined")
                        .on("keydown.enter.prevent", self._handle_submit)
                    )
                    ui.button(icon="send", on_click=self._handle_submit).props(
                        "round color=primary"
                    ).bind_enabled_from(self, "is_loading", lambda x: not x)

                # Quick actions
                with ui.row().classes("w-full gap-2 mt-2"):
                    ui.button(
                        "List Windows",
                        on_click=lambda: self._quick_action("list windows"),
                    ).props("flat dense")
                    ui.button(
                        "Screenshot",
                        on_click=lambda: self._quick_action("take a screenshot"),
                    ).props("flat dense")
                    ui.button(
                        "Volume",
                        on_click=lambda: self._quick_action("what's the current volume?"),
                    ).props("flat dense")
                    ui.button(
                        "Top Processes",
                        on_click=lambda: self._quick_action("show top processes"),
                    ).props("flat dense")

    def _render_messages(self) -> None:
        """Render all messages in the chat container."""
        if not self.chat_container:
            return

        self.chat_container.clear()

        with self.chat_container:
            if not self.messages:
                with ui.column().classes("w-full items-center justify-center py-8"):
                    ui.icon("chat", size="4rem").classes("text-gray-400")
                    ui.label("No messages yet").classes("text-gray-400 text-lg")
                    ui.label("Try asking me to list windows or take a screenshot").classes(
                        "text-gray-500 text-sm"
                    )
                return

            for msg in self.messages:
                self._render_message(msg)

    def _render_message(self, msg: Message) -> None:
        """Render a single message."""
        is_user = msg.role == MessageRole.USER
        alignment = "end" if is_user else "start"
        bg_color = "primary" if is_user else "grey-8"

        with ui.row().classes(f"w-full justify-{alignment}"):
            with ui.card().classes(f"max-w-[80%] bg-{bg_color}"):
                # Message content
                ui.markdown(msg.content).classes("text-white")

                # Tool calls if any
                if msg.tool_calls:
                    with ui.expansion("Tool calls", icon="build").classes("w-full mt-2"):
                        for tool in msg.tool_calls:
                            with ui.card().classes("w-full bg-grey-9 mb-2"):
                                ui.label(f"🔧 {tool.get('name', 'Unknown')}").classes(
                                    "font-bold"
                                )
                                if tool.get("result"):
                                    ui.code(str(tool["result"])).classes("w-full")

                # Timestamp
                ui.label(msg.timestamp.strftime("%H:%M")).classes(
                    "text-xs text-gray-400 mt-1"
                )

    async def _handle_submit(self) -> None:
        """Handle message submission."""
        if not self.input_field or self.is_loading:
            return

        message = self.input_field.value.strip()
        if not message:
            return

        # Clear input
        self.input_field.value = ""

        # Add user message
        user_msg = Message(role=MessageRole.USER, content=message)
        self.messages.append(user_msg)
        self._render_messages()

        # Add to history
        self.store.add_to_history(message)

        # Send to Copilot
        self.is_loading = True
        assistant_msg = Message(role=MessageRole.ASSISTANT, content="")
        self.messages.append(assistant_msg)

        try:
            async for event in self.copilot.send_message(message):
                if event.type == StreamEventType.TEXT:
                    assistant_msg.content += event.content or ""
                    self._render_messages()

                elif event.type == StreamEventType.TOOL_CALL:
                    assistant_msg.tool_calls.append({
                        "name": event.tool_name,
                        "args": event.tool_args,
                    })

                elif event.type == StreamEventType.TOOL_RESULT:
                    # Find and update the tool call
                    for tool in assistant_msg.tool_calls:
                        if tool.get("name") == event.tool_name:
                            tool["result"] = event.result
                            break

                    # Add result to message content
                    if isinstance(event.result, str):
                        assistant_msg.content += f"\n\n{event.result}"

                    self._render_messages()

                elif event.type == StreamEventType.ERROR:
                    assistant_msg.content += f"\n\n❌ Error: {event.error}"
                    self._render_messages()

                elif event.type == StreamEventType.DONE:
                    break

        except Exception as e:
            logger.error(f"Error sending message: {e}")
            assistant_msg.content += f"\n\n❌ Error: {e}"
            self._render_messages()

        finally:
            self.is_loading = False

    async def _quick_action(self, action: str) -> None:
        """Execute a quick action."""
        if self.input_field:
            self.input_field.value = action
        await self._handle_submit()

    def _clear_chat(self) -> None:
        """Clear the chat history."""
        self.messages.clear()
        self._render_messages()
        ui.notify("Chat cleared", type="info")

    def _show_settings(self) -> None:
        """Show settings dialog."""
        settings = self.store.get_settings()

        with ui.dialog() as dialog, ui.card().classes("w-96"):
            ui.label("Settings").classes("text-xl font-bold mb-4")

            # Theme selection
            ui.select(
                ["light", "dark", "system"],
                value=settings.theme,
                label="Theme",
                on_change=lambda e: self._update_setting("theme", e.value),
            ).classes("w-full")

            # Hotkey
            ui.input(
                label="Global Hotkey",
                value=settings.hotkey,
                on_change=lambda e: self._update_setting("hotkey", e.value),
            ).classes("w-full")

            # Show in tray
            ui.checkbox(
                "Show in system tray",
                value=settings.ui.show_in_tray,
                on_change=lambda e: self._update_nested_setting(
                    "ui", "show_in_tray", e.value
                ),
            )

            # Toast notifications
            ui.checkbox(
                "Toast notifications",
                value=settings.ui.toast_notifications,
                on_change=lambda e: self._update_nested_setting(
                    "ui", "toast_notifications", e.value
                ),
            )

            with ui.row().classes("w-full justify-end mt-4"):
                ui.button("Close", on_click=dialog.close)

        dialog.open()

    def _update_setting(self, key: str, value: Any) -> None:
        """Update a setting value."""
        self.store.update_settings(**{key: value})
        ui.notify(f"Setting updated: {key}", type="positive")

    def _update_nested_setting(self, section: str, key: str, value: Any) -> None:
        """Update a nested setting value."""
        settings = self.store.get_settings()
        section_obj = getattr(settings, section)
        setattr(section_obj, key, value)
        self.store.set_settings(settings)
        ui.notify(f"Setting updated: {section}.{key}", type="positive")


def create_ui() -> None:
    """Create the Desktop Commander UI."""
    palette = CommandPalette()
    palette.build()


def run_native(title: str = "Desktop Commander", width: int = 600, height: int = 700) -> None:
    """Run the UI in native mode using pywebview.

    Args:
        title: Window title
        width: Window width
        height: Window height
    """
    create_ui()
    ui.run(
        title=title,
        native=True,
        window_size=(width, height),
        reload=False,
    )


def run_browser(port: int = 8080) -> None:
    """Run the UI in browser mode.

    Args:
        port: Server port
    """
    create_ui()
    ui.run(port=port, reload=False)
