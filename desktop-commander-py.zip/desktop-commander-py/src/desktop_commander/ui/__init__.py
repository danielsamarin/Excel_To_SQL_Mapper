"""UI components for Desktop Commander using NiceGUI."""

from desktop_commander.ui.main_window import create_ui

__all__ = ["create_ui"]
