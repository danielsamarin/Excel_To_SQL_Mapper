"""Logging utilities for Desktop Commander."""

import logging
import sys
from pathlib import Path

from platformdirs import user_log_dir

APP_NAME = "desktop-commander"

_logger: logging.Logger | None = None


def setup_logging(debug: bool = False) -> logging.Logger:
    """Set up application logging.

    Args:
        debug: Enable debug-level logging

    Returns:
        Configured logger instance
    """
    global _logger

    if _logger is not None:
        return _logger

    # Create log directory
    log_dir = Path(user_log_dir(APP_NAME))
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "debug.log"

    # Create logger
    logger = logging.getLogger(APP_NAME)
    logger.setLevel(logging.DEBUG if debug else logging.INFO)

    # File handler
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s.%(funcName)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # Console handler (for errors)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.WARNING)
    console_formatter = logging.Formatter("[%(levelname)s] %(message)s")
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    _logger = logger
    logger.info(f"Logging initialized. Log file: {log_file}")

    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """Get a logger instance.

    Args:
        name: Optional child logger name (e.g., "copilot", "tools")

    Returns:
        Logger instance
    """
    global _logger

    if _logger is None:
        _logger = setup_logging()

    if name:
        return _logger.getChild(name)
    return _logger


class LogCategory:
    """Log category constants."""
    COPILOT = "copilot"
    TOOL = "tool"
    PLATFORM = "platform"
    UI = "ui"
    SERVICE = "service"
