"""Desktop Commander - AI-powered desktop automation using natural language.

This package provides a command palette interface for controlling your desktop
using natural language commands powered by the Copilot SDK.
"""

__version__ = "0.1.0"
__author__ = "Desktop Commander Team"

from desktop_commander.app import DesktopCommanderApp

__all__ = ["DesktopCommanderApp", "__version__"]
