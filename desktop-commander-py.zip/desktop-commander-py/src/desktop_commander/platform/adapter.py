"""Unified platform adapter that provides a consistent interface for all platform operations."""

import sys
from typing import TYPE_CHECKING

from desktop_commander.models.types import (
    AppInfo,
    ArrangeWindowsParams,
    BrightnessParams,
    BrightnessResult,
    ClipboardResult,
    CloseWindowParams,
    CopyFilesParams,
    CreateFolderParams,
    DeleteFilesParams,
    DndParams,
    DndResult,
    FileInfo,
    FocusWindowParams,
    GetFileInfoParams,
    GetProcessInfoParams,
    GetTopProcessesParams,
    KillProcessParams,
    LaunchAppParams,
    ListAppsParams,
    ListFilesParams,
    ListProcessesParams,
    MaximizeWindowParams,
    MinimizeWindowParams,
    MoveFilesParams,
    MoveWindowParams,
    OperationResult,
    PowerPointCreateParams,
    ProcessInfo,
    QuitAppParams,
    ReadClipboardParams,
    ReadFileParams,
    RenameFileParams,
    ScreenshotParams,
    ScreenshotResult,
    SearchFilesParams,
    SwitchAppParams,
    VolumeParams,
    VolumeResult,
    WindowInfo,
    WriteClipboardParams,
    WriteFileParams,
)
from desktop_commander.utils.logger import get_logger

if TYPE_CHECKING:
    from desktop_commander.platform.windows.apps import WindowsApps
    from desktop_commander.platform.windows.file_system import WindowsFileSystem
    from desktop_commander.platform.windows.process import WindowsProcess
    from desktop_commander.platform.windows.system import WindowsSystem
    from desktop_commander.platform.windows.window_manager import WindowsWindowManager

logger = get_logger("platform")

_adapter_instance: "UnifiedAdapter | None" = None


class UnifiedAdapter:
    """Unified adapter that wraps platform-specific implementations.

    All methods return OperationResult for consistent error handling.
    """

    def __init__(self) -> None:
        """Initialize the unified adapter with platform-specific implementations."""
        if sys.platform != "win32":
            raise RuntimeError("Desktop Commander currently only supports Windows")

        # Lazy imports to avoid circular dependencies
        from desktop_commander.platform.windows.apps import WindowsApps
        from desktop_commander.platform.windows.file_system import WindowsFileSystem
        from desktop_commander.platform.windows.process import WindowsProcess
        from desktop_commander.platform.windows.system import WindowsSystem
        from desktop_commander.platform.windows.window_manager import WindowsWindowManager

        self._window_manager: WindowsWindowManager = WindowsWindowManager()
        self._file_system: WindowsFileSystem = WindowsFileSystem()
        self._apps: WindowsApps = WindowsApps()
        self._system: WindowsSystem = WindowsSystem()
        self._process: WindowsProcess = WindowsProcess()

        logger.info("UnifiedAdapter initialized for Windows")

    # ========== Window Management ==========

    async def list_windows(self) -> OperationResult[list[WindowInfo]]:
        """List all open windows."""
        try:
            windows = await self._window_manager.list_windows()
            return OperationResult.ok(windows)
        except Exception as e:
            logger.error(f"Failed to list windows: {e}")
            return OperationResult.fail(str(e))

    async def focus_window(self, params: FocusWindowParams) -> OperationResult[None]:
        """Focus a window by ID, app name, or title."""
        try:
            await self._window_manager.focus_window(
                window_id=params.window_id,
                app_name=params.app_name,
                title_contains=params.title_contains,
            )
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to focus window: {e}")
            return OperationResult.fail(str(e))

    async def move_window(self, params: MoveWindowParams) -> OperationResult[None]:
        """Move and/or resize a window."""
        try:
            await self._window_manager.move_window(
                window_id=params.window_id,
                x=params.x,
                y=params.y,
                width=params.width,
                height=params.height,
            )
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to move window: {e}")
            return OperationResult.fail(str(e))

    async def close_window(self, params: CloseWindowParams) -> OperationResult[None]:
        """Close a window."""
        try:
            await self._window_manager.close_window(
                window_id=params.window_id,
                app_name=params.app_name,
            )
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to close window: {e}")
            return OperationResult.fail(str(e))

    async def minimize_window(self, params: MinimizeWindowParams) -> OperationResult[None]:
        """Minimize a window."""
        try:
            await self._window_manager.minimize_window(params.window_id)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to minimize window: {e}")
            return OperationResult.fail(str(e))

    async def maximize_window(self, params: MaximizeWindowParams) -> OperationResult[None]:
        """Maximize a window."""
        try:
            await self._window_manager.maximize_window(params.window_id)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to maximize window: {e}")
            return OperationResult.fail(str(e))

    async def arrange_windows(self, params: ArrangeWindowsParams) -> OperationResult[None]:
        """Arrange windows in a layout."""
        try:
            await self._window_manager.arrange_windows(params.layout, params.windows)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to arrange windows: {e}")
            return OperationResult.fail(str(e))

    # ========== File System ==========

    async def list_files(self, params: ListFilesParams) -> OperationResult[list[FileInfo]]:
        """List files in a directory."""
        try:
            files = await self._file_system.list_files(
                params.path, params.recursive, params.filter
            )
            return OperationResult.ok(files)
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return OperationResult.fail(str(e))

    async def search_files(self, params: SearchFilesParams) -> OperationResult[list[FileInfo]]:
        """Search for files matching a query."""
        try:
            files = await self._file_system.search_files(
                params.query, params.start_path, params.max_results
            )
            return OperationResult.ok(files)
        except Exception as e:
            logger.error(f"Failed to search files: {e}")
            return OperationResult.fail(str(e))

    async def move_files(self, params: MoveFilesParams) -> OperationResult[None]:
        """Move files to a new location."""
        try:
            await self._file_system.move_file(
                params.source, params.destination, params.overwrite
            )
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to move files: {e}")
            return OperationResult.fail(str(e))

    async def copy_files(self, params: CopyFilesParams) -> OperationResult[None]:
        """Copy files to a new location."""
        try:
            await self._file_system.copy_file(
                params.source, params.destination, params.overwrite
            )
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to copy files: {e}")
            return OperationResult.fail(str(e))

    async def delete_files(self, params: DeleteFilesParams) -> OperationResult[None]:
        """Delete files."""
        try:
            await self._file_system.delete_files(params.paths, params.move_to_trash)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to delete files: {e}")
            return OperationResult.fail(str(e))

    async def rename_file(self, params: RenameFileParams) -> OperationResult[None]:
        """Rename a file."""
        try:
            await self._file_system.rename_file(params.path, params.new_name)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to rename file: {e}")
            return OperationResult.fail(str(e))

    async def create_folder(self, params: CreateFolderParams) -> OperationResult[None]:
        """Create a folder."""
        try:
            await self._file_system.create_folder(params.path)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to create folder: {e}")
            return OperationResult.fail(str(e))

    async def read_file(self, params: ReadFileParams) -> OperationResult[str]:
        """Read file contents."""
        try:
            content = await self._file_system.read_file(
                params.path, params.encoding, params.max_size
            )
            return OperationResult.ok(content)
        except Exception as e:
            logger.error(f"Failed to read file: {e}")
            return OperationResult.fail(str(e))

    async def write_file(self, params: WriteFileParams) -> OperationResult[bool]:
        """Write content to a file."""
        try:
            await self._file_system.write_file(
                params.path, params.content, params.encoding, params.append
            )
            return OperationResult.ok(True)
        except Exception as e:
            logger.error(f"Failed to write file: {e}")
            return OperationResult.fail(str(e))

    async def get_file_info(self, params: GetFileInfoParams) -> OperationResult[FileInfo]:
        """Get information about a file."""
        try:
            info = await self._file_system.get_file_info(params.path)
            return OperationResult.ok(info)
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return OperationResult.fail(str(e))

    # ========== Applications ==========

    async def list_apps(self, params: ListAppsParams) -> OperationResult[list[AppInfo]]:
        """List applications."""
        try:
            apps = await self._apps.list_apps(params.filter)
            return OperationResult.ok(apps)
        except Exception as e:
            logger.error(f"Failed to list apps: {e}")
            return OperationResult.fail(str(e))

    async def launch_app(self, params: LaunchAppParams) -> OperationResult[None]:
        """Launch an application."""
        try:
            await self._apps.launch_app(params.name, params.path, params.args)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to launch app: {e}")
            return OperationResult.fail(str(e))

    async def quit_app(self, params: QuitAppParams) -> OperationResult[None]:
        """Quit an application."""
        try:
            await self._apps.quit_app(params.name, params.force)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to quit app: {e}")
            return OperationResult.fail(str(e))

    async def switch_app(self, params: SwitchAppParams) -> OperationResult[None]:
        """Switch to an application."""
        try:
            await self._apps.switch_app(params.name)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to switch app: {e}")
            return OperationResult.fail(str(e))

    # ========== System ==========

    async def control_volume(self, params: VolumeParams) -> OperationResult[VolumeResult]:
        """Control system volume."""
        try:
            result = await self._system.control_volume(params.action, params.level)
            return OperationResult.ok(result)
        except Exception as e:
            logger.error(f"Failed to control volume: {e}")
            return OperationResult.fail(str(e))

    async def control_brightness(
        self, params: BrightnessParams
    ) -> OperationResult[BrightnessResult]:
        """Control display brightness."""
        try:
            result = await self._system.control_brightness(params.action, params.level)
            return OperationResult.ok(result)
        except Exception as e:
            logger.error(f"Failed to control brightness: {e}")
            return OperationResult.fail(str(e))

    async def take_screenshot(
        self, params: ScreenshotParams
    ) -> OperationResult[ScreenshotResult]:
        """Take a screenshot."""
        try:
            result = await self._system.take_screenshot(
                params.region, params.save_path, params.filename
            )
            return OperationResult.ok(result)
        except Exception as e:
            logger.error(f"Failed to take screenshot: {e}")
            return OperationResult.fail(str(e))

    async def control_dnd(self, params: DndParams) -> OperationResult[DndResult]:
        """Control Do Not Disturb mode."""
        try:
            result = await self._system.control_dnd(params.action, params.duration)
            return OperationResult.ok(result)
        except Exception as e:
            logger.error(f"Failed to control DND: {e}")
            return OperationResult.fail(str(e))

    async def lock_screen(self) -> OperationResult[None]:
        """Lock the screen."""
        try:
            await self._system.lock_screen()
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to lock screen: {e}")
            return OperationResult.fail(str(e))

    async def sleep(self) -> OperationResult[None]:
        """Put the system to sleep."""
        try:
            await self._system.sleep()
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to sleep: {e}")
            return OperationResult.fail(str(e))

    # ========== Process ==========

    async def list_processes(
        self, params: ListProcessesParams
    ) -> OperationResult[list[ProcessInfo]]:
        """List running processes."""
        try:
            processes = await self._process.list_processes(params.sort_by, params.limit)
            return OperationResult.ok(processes)
        except Exception as e:
            logger.error(f"Failed to list processes: {e}")
            return OperationResult.fail(str(e))

    async def get_process_info(
        self, params: GetProcessInfoParams
    ) -> OperationResult[ProcessInfo | None]:
        """Get information about a process."""
        try:
            info = await self._process.get_process_info(params.pid, params.name)
            return OperationResult.ok(info)
        except Exception as e:
            logger.error(f"Failed to get process info: {e}")
            return OperationResult.fail(str(e))

    async def kill_process(self, params: KillProcessParams) -> OperationResult[None]:
        """Kill a process."""
        try:
            await self._process.kill_process(params.pid, params.name, params.force)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to kill process: {e}")
            return OperationResult.fail(str(e))

    async def get_top_processes(
        self, params: GetTopProcessesParams
    ) -> OperationResult[list[ProcessInfo]]:
        """Get top processes by resource usage."""
        try:
            processes = await self._process.get_top_processes(params.resource, params.limit)
            return OperationResult.ok(processes)
        except Exception as e:
            logger.error(f"Failed to get top processes: {e}")
            return OperationResult.fail(str(e))

    # ========== Clipboard ==========

    async def read_clipboard(
        self, params: ReadClipboardParams
    ) -> OperationResult[ClipboardResult]:
        """Read clipboard contents."""
        try:
            result = await self._system.read_clipboard(params.format)
            return OperationResult.ok(result)
        except Exception as e:
            logger.error(f"Failed to read clipboard: {e}")
            return OperationResult.fail(str(e))

    async def write_clipboard(self, params: WriteClipboardParams) -> OperationResult[None]:
        """Write to clipboard."""
        try:
            await self._system.write_clipboard(params.content, params.format)
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to write clipboard: {e}")
            return OperationResult.fail(str(e))

    async def clear_clipboard(self) -> OperationResult[None]:
        """Clear clipboard contents."""
        try:
            await self._system.clear_clipboard()
            return OperationResult.ok()
        except Exception as e:
            logger.error(f"Failed to clear clipboard: {e}")
            return OperationResult.fail(str(e))

    # ========== Office ==========

    async def create_powerpoint(
        self, params: PowerPointCreateParams
    ) -> OperationResult[bool]:
        """Create a PowerPoint presentation."""
        try:
            await self._apps.create_powerpoint(params.save_path, params.slides)
            return OperationResult.ok(True)
        except Exception as e:
            logger.error(f"Failed to create PowerPoint: {e}")
            return OperationResult.fail(str(e))


def get_adapter() -> UnifiedAdapter:
    """Get the singleton unified adapter instance.

    Returns:
        UnifiedAdapter instance
    """
    global _adapter_instance
    if _adapter_instance is None:
        _adapter_instance = UnifiedAdapter()
    return _adapter_instance
