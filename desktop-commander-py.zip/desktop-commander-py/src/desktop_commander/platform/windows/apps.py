"""Windows application management."""

import asyncio
import os
import subprocess
import winreg
from pathlib import Path
from typing import Literal

import psutil
import win32gui
import win32process

from desktop_commander.models.types import AppInfo, SlideContent
from desktop_commander.utils.logger import get_logger

logger = get_logger("platform.windows.apps")

# Common app name to executable mappings
APP_ALIASES: dict[str, list[str]] = {
    "chrome": ["chrome", "chrome.exe", "google chrome"],
    "firefox": ["firefox", "firefox.exe"],
    "edge": ["msedge", "msedge.exe", "microsoft edge"],
    "vscode": ["code", "code.exe", "visual studio code"],
    "notepad": ["notepad", "notepad.exe"],
    "explorer": ["explorer", "explorer.exe"],
    "cmd": ["cmd", "cmd.exe"],
    "powershell": ["powershell", "powershell.exe"],
    "terminal": ["wt", "wt.exe", "windows terminal"],
    "word": ["winword", "winword.exe", "microsoft word"],
    "excel": ["excel", "excel.exe", "microsoft excel"],
    "powerpoint": ["powerpnt", "powerpnt.exe", "microsoft powerpoint"],
    "outlook": ["outlook", "outlook.exe", "microsoft outlook"],
    "slack": ["slack", "slack.exe"],
    "discord": ["discord", "discord.exe"],
    "spotify": ["spotify", "spotify.exe"],
    "teams": ["teams", "teams.exe", "microsoft teams"],
}


class WindowsApps:
    """Windows application management."""

    def __init__(self) -> None:
        """Initialize the app manager."""
        self._installed_apps_cache: list[AppInfo] | None = None
        logger.info("WindowsApps initialized")

    async def list_apps(
        self, filter_type: Literal["running", "installed", "all"] = "all"
    ) -> list[AppInfo]:
        """List applications.

        Args:
            filter_type: Type of apps to list

        Returns:
            List of application information
        """
        apps: list[AppInfo] = []

        if filter_type in ("running", "all"):
            running = await self._get_running_apps()
            apps.extend(running)

        if filter_type in ("installed", "all"):
            installed = await self._get_installed_apps()
            # Merge with running apps
            running_names = {a.name.lower() for a in apps}
            for app in installed:
                if app.name.lower() not in running_names:
                    apps.append(app)
                else:
                    # Update running app with install path
                    for running_app in apps:
                        if running_app.name.lower() == app.name.lower():
                            if not running_app.path and app.path:
                                running_app.path = app.path
                            break

        return apps

    async def _get_running_apps(self) -> list[AppInfo]:
        """Get list of running applications."""

        def _get_running() -> list[AppInfo]:
            apps: dict[str, AppInfo] = {}

            for proc in psutil.process_iter(["pid", "name", "exe"]):
                try:
                    info = proc.info
                    name = info.get("name", "")
                    if not name:
                        continue

                    # Skip system processes
                    if name.lower() in (
                        "system",
                        "idle",
                        "registry",
                        "smss.exe",
                        "csrss.exe",
                        "wininit.exe",
                        "services.exe",
                        "lsass.exe",
                        "svchost.exe",
                    ):
                        continue

                    # Get friendly name (remove .exe)
                    friendly_name = name[:-4] if name.lower().endswith(".exe") else name

                    # Deduplicate by name
                    if friendly_name.lower() not in apps:
                        apps[friendly_name.lower()] = AppInfo(
                            name=friendly_name,
                            path=info.get("exe", ""),
                            is_running=True,
                            process_id=info.get("pid"),
                        )
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            return list(apps.values())

        return await asyncio.to_thread(_get_running)

    async def _get_installed_apps(self) -> list[AppInfo]:
        """Get list of installed applications from registry."""
        if self._installed_apps_cache is not None:
            return self._installed_apps_cache

        def _get_installed() -> list[AppInfo]:
            apps: dict[str, AppInfo] = {}

            # Registry paths for installed apps
            reg_paths = [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            ]

            for hkey, path in reg_paths:
                try:
                    with winreg.OpenKey(hkey, path) as key:
                        for i in range(winreg.QueryInfoKey(key)[0]):
                            try:
                                subkey_name = winreg.EnumKey(key, i)
                                with winreg.OpenKey(key, subkey_name) as subkey:
                                    try:
                                        name, _ = winreg.QueryValueEx(subkey, "DisplayName")
                                        if not name:
                                            continue

                                        # Get install location if available
                                        try:
                                            path_val, _ = winreg.QueryValueEx(
                                                subkey, "InstallLocation"
                                            )
                                        except FileNotFoundError:
                                            path_val = ""

                                        if name.lower() not in apps:
                                            apps[name.lower()] = AppInfo(
                                                name=name,
                                                path=path_val,
                                                is_running=False,
                                            )
                                    except FileNotFoundError:
                                        continue
                            except (OSError, WindowsError):
                                continue
                except (OSError, WindowsError):
                    continue

            return list(apps.values())

        self._installed_apps_cache = await asyncio.to_thread(_get_installed)
        return self._installed_apps_cache

    async def launch_app(
        self,
        name: str | None = None,
        path: str | None = None,
        args: list[str] | None = None,
    ) -> None:
        """Launch an application.

        Args:
            name: Application name or alias
            path: Full path to executable
            args: Command line arguments
        """
        args = args or []

        def _launch() -> None:
            executable: str | None = None

            # If path provided, use it directly
            if path:
                executable = path
            elif name:
                # Try to find executable by name
                name_lower = name.lower()

                # Check aliases
                for alias, variants in APP_ALIASES.items():
                    if name_lower in [v.lower() for v in variants] or name_lower == alias:
                        # Try to find the executable
                        for variant in variants:
                            if not variant.endswith(".exe"):
                                variant += ".exe"
                            # Check if it's in PATH
                            for path_dir in os.environ.get("PATH", "").split(os.pathsep):
                                full_path = Path(path_dir) / variant
                                if full_path.exists():
                                    executable = str(full_path)
                                    break
                            if executable:
                                break

                            # Try common locations
                            common_paths = [
                                Path(os.environ.get("ProgramFiles", "")) / variant,
                                Path(os.environ.get("ProgramFiles(x86)", "")) / variant,
                                Path(os.environ.get("LocalAppData", "")) / variant,
                            ]
                            for p in common_paths:
                                if p.exists():
                                    executable = str(p)
                                    break
                            if executable:
                                break
                        break

                # If not found in aliases, try direct name
                if not executable:
                    # Check if it's in PATH
                    name_exe = name if name.endswith(".exe") else name + ".exe"
                    for path_dir in os.environ.get("PATH", "").split(os.pathsep):
                        full_path = Path(path_dir) / name_exe
                        if full_path.exists():
                            executable = str(full_path)
                            break

                # Last resort: try running directly (system will search PATH)
                if not executable:
                    executable = name

            if not executable:
                raise ValueError(f"Could not find application: {name or path}")

            # Launch the application
            cmd = [executable] + args
            subprocess.Popen(
                cmd,
                shell=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.DETACHED_PROCESS
                | subprocess.CREATE_NEW_PROCESS_GROUP,
            )

        await asyncio.to_thread(_launch)
        logger.info(f"Launched app: {name or path}")

    async def quit_app(self, name: str, force: bool = False) -> None:
        """Quit an application.

        Args:
            name: Application name
            force: Force quit without prompting
        """

        def _quit() -> None:
            name_lower = name.lower()
            found = False

            for proc in psutil.process_iter(["pid", "name"]):
                try:
                    proc_name = proc.info.get("name", "").lower()
                    if name_lower in proc_name or proc_name.startswith(name_lower):
                        if force:
                            proc.kill()
                        else:
                            proc.terminate()
                        found = True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            if not found:
                raise ValueError(f"Application not running: {name}")

        await asyncio.to_thread(_quit)
        logger.info(f"Quit app: {name} (force={force})")

    async def switch_app(self, name: str) -> None:
        """Switch to an application (bring to foreground).

        Args:
            name: Application name
        """

        def _switch() -> None:
            name_lower = name.lower()
            target_hwnd = None

            # Find window by process name
            def callback(hwnd: int, _: None) -> bool:
                nonlocal target_hwnd
                if not win32gui.IsWindowVisible(hwnd):
                    return True

                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                try:
                    proc = psutil.Process(pid)
                    proc_name = proc.name().lower()
                    if name_lower in proc_name:
                        target_hwnd = hwnd
                        return False  # Stop enumeration
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

                return True

            win32gui.EnumWindows(callback, None)

            if target_hwnd is None:
                raise ValueError(f"Application window not found: {name}")

            # Restore if minimized
            if win32gui.IsIconic(target_hwnd):
                win32gui.ShowWindow(target_hwnd, 9)  # SW_RESTORE

            # Bring to foreground
            win32gui.SetForegroundWindow(target_hwnd)

        await asyncio.to_thread(_switch)
        logger.info(f"Switched to app: {name}")

    async def create_powerpoint(
        self,
        save_path: str,
        slides: list[SlideContent],
    ) -> None:
        """Create a PowerPoint presentation.

        Args:
            save_path: Path to save the presentation
            slides: List of slide content
        """
        try:
            # Try to use python-pptx if available
            from pptx import Presentation
            from pptx.util import Inches, Pt

            def _create() -> None:
                prs = Presentation()

                for slide_data in slides:
                    if slide_data.layout == "title":
                        layout = prs.slide_layouts[0]  # Title slide
                    elif slide_data.layout == "blank":
                        layout = prs.slide_layouts[6]  # Blank
                    elif slide_data.layout == "two_column":
                        layout = prs.slide_layouts[3]  # Two content
                    else:
                        layout = prs.slide_layouts[1]  # Title and content

                    slide = prs.slides.add_slide(layout)

                    # Set title if available
                    if slide_data.title and slide.shapes.title:
                        slide.shapes.title.text = slide_data.title

                    # Set content if available
                    if slide_data.content:
                        for shape in slide.placeholders:
                            if shape.placeholder_format.idx == 1:  # Content placeholder
                                shape.text = slide_data.content
                                break

                    # Add notes if available
                    if slide_data.notes:
                        notes_slide = slide.notes_slide
                        notes_slide.notes_text_frame.text = slide_data.notes

                # Ensure parent directory exists
                Path(save_path).parent.mkdir(parents=True, exist_ok=True)

                prs.save(save_path)

            await asyncio.to_thread(_create)
            logger.info(f"Created PowerPoint: {save_path}")

        except ImportError:
            # Fallback: Use COM automation
            await self._create_powerpoint_com(save_path, slides)

    async def _create_powerpoint_com(
        self,
        save_path: str,
        slides: list[SlideContent],
    ) -> None:
        """Create PowerPoint using COM automation."""

        def _create() -> None:
            import win32com.client

            ppt = win32com.client.Dispatch("PowerPoint.Application")
            ppt.Visible = True

            presentation = ppt.Presentations.Add()

            for slide_data in slides:
                # Layout constants
                if slide_data.layout == "title":
                    layout = 1  # ppLayoutTitle
                elif slide_data.layout == "blank":
                    layout = 7  # ppLayoutBlank
                else:
                    layout = 2  # ppLayoutText

                slide = presentation.Slides.Add(
                    presentation.Slides.Count + 1, layout
                )

                # Set title
                if slide_data.title and slide.Shapes.HasTitle:
                    slide.Shapes.Title.TextFrame.TextRange.Text = slide_data.title

                # Set content
                if slide_data.content:
                    for shape in slide.Shapes:
                        if shape.HasTextFrame:
                            if shape != slide.Shapes.Title:
                                shape.TextFrame.TextRange.Text = slide_data.content
                                break

            # Save and close
            Path(save_path).parent.mkdir(parents=True, exist_ok=True)
            presentation.SaveAs(str(Path(save_path).absolute()))

        await asyncio.to_thread(_create)
        logger.info(f"Created PowerPoint (COM): {save_path}")
