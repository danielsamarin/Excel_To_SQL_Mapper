"""Windows window manager using Win32 API via pywin32."""

import asyncio
import ctypes
from ctypes import wintypes
from typing import Literal

import win32con
import win32gui
import win32process

from desktop_commander.models.types import Bounds, WindowInfo
from desktop_commander.utils.logger import get_logger

logger = get_logger("platform.windows.window_manager")

# Win32 constants
SW_MINIMIZE = 6
SW_MAXIMIZE = 3
SW_RESTORE = 9
SW_SHOW = 5


class WindowsWindowManager:
    """Windows window manager using Win32 API."""

    def __init__(self) -> None:
        """Initialize the window manager."""
        self._user32 = ctypes.windll.user32
        logger.info("WindowsWindowManager initialized")

    async def list_windows(self) -> list[WindowInfo]:
        """List all visible windows.

        Returns:
            List of window information
        """

        def _enum_windows() -> list[WindowInfo]:
            windows: list[WindowInfo] = []

            def callback(hwnd: int, _: None) -> bool:
                # Skip invisible windows
                if not win32gui.IsWindowVisible(hwnd):
                    return True

                # Skip windows with no title
                title = win32gui.GetWindowText(hwnd)
                if not title:
                    return True

                # Get window rect
                try:
                    rect = win32gui.GetWindowRect(hwnd)
                except Exception:
                    return True

                # Skip very small windows (likely system windows)
                width = rect[2] - rect[0]
                height = rect[3] - rect[1]
                if width < 50 or height < 50:
                    return True

                # Get process info
                try:
                    _, process_id = win32process.GetWindowThreadProcessId(hwnd)
                except Exception:
                    process_id = 0

                # Get app name from window class or process
                try:
                    class_name = win32gui.GetClassName(hwnd)
                    app_name = class_name.split(".")[-1] if "." in class_name else class_name
                except Exception:
                    app_name = "Unknown"

                # Check window state
                placement = win32gui.GetWindowPlacement(hwnd)
                is_minimized = placement[1] == win32con.SW_SHOWMINIMIZED
                is_maximized = placement[1] == win32con.SW_SHOWMAXIMIZED

                # Check if focused
                is_focused = hwnd == win32gui.GetForegroundWindow()

                windows.append(
                    WindowInfo(
                        id=str(hwnd),
                        title=title,
                        app=app_name,
                        process_id=process_id,
                        bounds=Bounds(x=rect[0], y=rect[1], width=width, height=height),
                        is_minimized=is_minimized,
                        is_maximized=is_maximized,
                        is_focused=is_focused,
                    )
                )
                return True

            win32gui.EnumWindows(callback, None)
            return windows

        return await asyncio.to_thread(_enum_windows)

    async def focus_window(
        self,
        window_id: str | None = None,
        app_name: str | None = None,
        title_contains: str | None = None,
    ) -> None:
        """Focus a window.

        Args:
            window_id: Window handle as string
            app_name: Application name to match
            title_contains: Title substring to match
        """
        hwnd = await self._find_window(window_id, app_name, title_contains)
        if hwnd is None:
            raise ValueError("Window not found")

        def _focus() -> None:
            # Restore if minimized
            if win32gui.IsIconic(hwnd):
                win32gui.ShowWindow(hwnd, SW_RESTORE)

            # Bring to foreground
            win32gui.SetForegroundWindow(hwnd)

        await asyncio.to_thread(_focus)
        logger.info(f"Focused window: {hwnd}")

    async def move_window(
        self,
        window_id: str,
        x: int | None = None,
        y: int | None = None,
        width: int | None = None,
        height: int | None = None,
    ) -> None:
        """Move and/or resize a window.

        Args:
            window_id: Window handle as string
            x: New X position (or None to keep current)
            y: New Y position (or None to keep current)
            width: New width (or None to keep current)
            height: New height (or None to keep current)
        """
        hwnd = int(window_id)

        def _move() -> None:
            # Get current position
            rect = win32gui.GetWindowRect(hwnd)
            current_x, current_y = rect[0], rect[1]
            current_width = rect[2] - rect[0]
            current_height = rect[3] - rect[1]

            # Use current values for None parameters
            new_x = x if x is not None else current_x
            new_y = y if y is not None else current_y
            new_width = width if width is not None else current_width
            new_height = height if height is not None else current_height

            # Restore if maximized (can't move maximized window)
            placement = win32gui.GetWindowPlacement(hwnd)
            if placement[1] == win32con.SW_SHOWMAXIMIZED:
                win32gui.ShowWindow(hwnd, SW_RESTORE)

            # Move and resize
            win32gui.SetWindowPos(
                hwnd,
                None,
                new_x,
                new_y,
                new_width,
                new_height,
                win32con.SWP_NOZORDER | win32con.SWP_NOACTIVATE,
            )

        await asyncio.to_thread(_move)
        logger.info(f"Moved window {window_id} to ({x}, {y}) size ({width}, {height})")

    async def close_window(
        self,
        window_id: str | None = None,
        app_name: str | None = None,
    ) -> None:
        """Close a window.

        Args:
            window_id: Window handle as string
            app_name: Application name to match
        """
        hwnd = await self._find_window(window_id, app_name)
        if hwnd is None:
            raise ValueError("Window not found")

        def _close() -> None:
            win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)

        await asyncio.to_thread(_close)
        logger.info(f"Closed window: {hwnd}")

    async def minimize_window(self, window_id: str) -> None:
        """Minimize a window.

        Args:
            window_id: Window handle as string
        """
        hwnd = int(window_id)

        def _minimize() -> None:
            win32gui.ShowWindow(hwnd, SW_MINIMIZE)

        await asyncio.to_thread(_minimize)
        logger.info(f"Minimized window: {window_id}")

    async def maximize_window(self, window_id: str) -> None:
        """Maximize a window.

        Args:
            window_id: Window handle as string
        """
        hwnd = int(window_id)

        def _maximize() -> None:
            win32gui.ShowWindow(hwnd, SW_MAXIMIZE)

        await asyncio.to_thread(_maximize)
        logger.info(f"Maximized window: {window_id}")

    async def arrange_windows(
        self,
        layout: Literal[
            "left-half",
            "right-half",
            "top-half",
            "bottom-half",
            "grid",
            "side-by-side",
            "stacked",
            "cascade",
        ],
        window_ids: list[str] | None = None,
    ) -> None:
        """Arrange windows in a layout.

        Args:
            layout: Layout type
            window_ids: Optional list of window IDs to arrange
        """
        # Get screen dimensions
        screen_width = self._user32.GetSystemMetrics(0)
        screen_height = self._user32.GetSystemMetrics(1)

        # Get windows to arrange
        if window_ids:
            windows = [int(wid) for wid in window_ids]
        else:
            all_windows = await self.list_windows()
            windows = [int(w.id) for w in all_windows if not w.is_minimized]

        if not windows:
            logger.warning("No windows to arrange")
            return

        def _arrange() -> None:
            positions: list[tuple[int, int, int, int, int]] = []  # hwnd, x, y, w, h

            if layout == "left-half":
                for hwnd in windows:
                    positions.append((hwnd, 0, 0, screen_width // 2, screen_height))

            elif layout == "right-half":
                for hwnd in windows:
                    positions.append(
                        (hwnd, screen_width // 2, 0, screen_width // 2, screen_height)
                    )

            elif layout == "top-half":
                for hwnd in windows:
                    positions.append((hwnd, 0, 0, screen_width, screen_height // 2))

            elif layout == "bottom-half":
                for hwnd in windows:
                    positions.append(
                        (hwnd, 0, screen_height // 2, screen_width, screen_height // 2)
                    )

            elif layout == "side-by-side":
                count = len(windows)
                if count > 0:
                    width = screen_width // count
                    for i, hwnd in enumerate(windows):
                        positions.append((hwnd, i * width, 0, width, screen_height))

            elif layout == "stacked":
                count = len(windows)
                if count > 0:
                    height = screen_height // count
                    for i, hwnd in enumerate(windows):
                        positions.append((hwnd, 0, i * height, screen_width, height))

            elif layout == "grid":
                count = len(windows)
                if count > 0:
                    cols = int(count**0.5)
                    rows = (count + cols - 1) // cols
                    width = screen_width // cols
                    height = screen_height // rows
                    for i, hwnd in enumerate(windows):
                        row = i // cols
                        col = i % cols
                        positions.append(
                            (hwnd, col * width, row * height, width, height)
                        )

            elif layout == "cascade":
                offset = 30
                width = screen_width - (len(windows) * offset)
                height = screen_height - (len(windows) * offset)
                for i, hwnd in enumerate(windows):
                    positions.append((hwnd, i * offset, i * offset, width, height))

            # Apply positions
            for hwnd, x, y, w, h in positions:
                try:
                    # Restore if minimized or maximized
                    placement = win32gui.GetWindowPlacement(hwnd)
                    if placement[1] in (
                        win32con.SW_SHOWMINIMIZED,
                        win32con.SW_SHOWMAXIMIZED,
                    ):
                        win32gui.ShowWindow(hwnd, SW_RESTORE)

                    win32gui.SetWindowPos(
                        hwnd,
                        None,
                        x,
                        y,
                        w,
                        h,
                        win32con.SWP_NOZORDER | win32con.SWP_NOACTIVATE,
                    )
                except Exception as e:
                    logger.warning(f"Failed to position window {hwnd}: {e}")

        await asyncio.to_thread(_arrange)
        logger.info(f"Arranged {len(windows)} windows in {layout} layout")

    async def _find_window(
        self,
        window_id: str | None = None,
        app_name: str | None = None,
        title_contains: str | None = None,
    ) -> int | None:
        """Find a window by various criteria.

        Args:
            window_id: Window handle as string
            app_name: Application name to match
            title_contains: Title substring to match

        Returns:
            Window handle or None
        """
        if window_id:
            return int(window_id)

        windows = await self.list_windows()

        for window in windows:
            if app_name and app_name.lower() in window.app.lower():
                return int(window.id)
            if title_contains and title_contains.lower() in window.title.lower():
                return int(window.id)

        return None
