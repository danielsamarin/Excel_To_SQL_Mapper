"""Windows process management using psutil."""

import asyncio
from typing import Literal

import psutil

from desktop_commander.models.types import ProcessInfo
from desktop_commander.utils.logger import get_logger

logger = get_logger("platform.windows.process")


class WindowsProcess:
    """Windows process management."""

    def __init__(self) -> None:
        """Initialize process manager."""
        logger.info("WindowsProcess initialized")

    async def list_processes(
        self,
        sort_by: Literal["cpu", "memory", "name"] = "cpu",
        limit: int = 20,
    ) -> list[ProcessInfo]:
        """List running processes.

        Args:
            sort_by: Sort field
            limit: Maximum number of processes to return

        Returns:
            List of process information
        """

        def _list() -> list[ProcessInfo]:
            processes: list[ProcessInfo] = []

            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
                try:
                    info = proc.info
                    processes.append(
                        ProcessInfo(
                            pid=info["pid"],
                            name=info["name"] or "Unknown",
                            cpu=info["cpu_percent"] or 0.0,
                            memory=info["memory_percent"] or 0.0,
                            status=info["status"] or "unknown",
                        )
                    )
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue

            # Sort processes
            if sort_by == "cpu":
                processes.sort(key=lambda p: p.cpu, reverse=True)
            elif sort_by == "memory":
                processes.sort(key=lambda p: p.memory, reverse=True)
            elif sort_by == "name":
                processes.sort(key=lambda p: p.name.lower())

            return processes[:limit]

        # First call to establish baseline for CPU measurement
        await asyncio.to_thread(lambda: list(psutil.process_iter(["cpu_percent"])))
        await asyncio.sleep(0.1)  # Short delay for accurate CPU measurement

        return await asyncio.to_thread(_list)

    async def get_process_info(
        self,
        pid: int | None = None,
        name: str | None = None,
    ) -> ProcessInfo | None:
        """Get information about a specific process.

        Args:
            pid: Process ID
            name: Process name (will return first match)

        Returns:
            Process information or None if not found
        """

        def _get_info() -> ProcessInfo | None:
            if pid is not None:
                try:
                    proc = psutil.Process(pid)
                    return ProcessInfo(
                        pid=proc.pid,
                        name=proc.name(),
                        cpu=proc.cpu_percent(interval=0.1),
                        memory=proc.memory_percent(),
                        status=proc.status(),
                    )
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    return None

            elif name is not None:
                name_lower = name.lower()
                for proc in psutil.process_iter(["pid", "name"]):
                    try:
                        proc_name = proc.info.get("name", "").lower()
                        if name_lower in proc_name:
                            return ProcessInfo(
                                pid=proc.pid,
                                name=proc.name(),
                                cpu=proc.cpu_percent(interval=0.1),
                                memory=proc.memory_percent(),
                                status=proc.status(),
                            )
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue

            return None

        return await asyncio.to_thread(_get_info)

    async def kill_process(
        self,
        pid: int | None = None,
        name: str | None = None,
        force: bool = False,
    ) -> None:
        """Kill a process.

        Args:
            pid: Process ID to kill
            name: Process name to kill (will kill all matching)
            force: Force kill without allowing cleanup
        """

        def _kill() -> None:
            killed = False

            if pid is not None:
                try:
                    proc = psutil.Process(pid)
                    if force:
                        proc.kill()
                    else:
                        proc.terminate()
                    killed = True
                except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                    raise ValueError(f"Could not kill process {pid}: {e}")

            elif name is not None:
                name_lower = name.lower()
                for proc in psutil.process_iter(["pid", "name"]):
                    try:
                        proc_name = proc.info.get("name", "").lower()
                        if name_lower in proc_name:
                            if force:
                                proc.kill()
                            else:
                                proc.terminate()
                            killed = True
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue

            if not killed:
                raise ValueError(f"Process not found: pid={pid}, name={name}")

        await asyncio.to_thread(_kill)
        logger.info(f"Killed process: pid={pid}, name={name}, force={force}")

    async def get_top_processes(
        self,
        resource: Literal["cpu", "memory"] = "cpu",
        limit: int = 10,
    ) -> list[ProcessInfo]:
        """Get top processes by resource usage.

        Args:
            resource: Resource to sort by
            limit: Number of top processes to return

        Returns:
            List of top processes
        """
        sort_by: Literal["cpu", "memory"] = "cpu" if resource == "cpu" else "memory"
        return await self.list_processes(sort_by=sort_by, limit=limit)
