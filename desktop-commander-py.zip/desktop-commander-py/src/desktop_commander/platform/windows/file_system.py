"""Windows file system operations using pathlib and send2trash."""

import asyncio
import fnmatch
import os
import shutil
from datetime import datetime
from pathlib import Path

import aiofiles
from send2trash import send2trash

from desktop_commander.models.types import FileFilter, FileInfo
from desktop_commander.utils.logger import get_logger

logger = get_logger("platform.windows.file_system")


class WindowsFileSystem:
    """Windows file system operations."""

    def __init__(self) -> None:
        """Initialize the file system handler."""
        logger.info("WindowsFileSystem initialized")

    async def list_files(
        self,
        path: str,
        recursive: bool = False,
        file_filter: FileFilter | None = None,
    ) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list
            recursive: Whether to recurse into subdirectories
            file_filter: Optional filter criteria

        Returns:
            List of file information
        """

        def _list() -> list[FileInfo]:
            files: list[FileInfo] = []
            base_path = Path(path)

            if not base_path.exists():
                raise FileNotFoundError(f"Directory not found: {path}")

            if not base_path.is_dir():
                raise ValueError(f"Not a directory: {path}")

            iterator = base_path.rglob("*") if recursive else base_path.iterdir()

            for file_path in iterator:
                try:
                    stat = file_path.stat()
                    file_info = FileInfo(
                        name=file_path.name,
                        path=str(file_path),
                        is_directory=file_path.is_dir(),
                        size=stat.st_size if not file_path.is_dir() else 0,
                        created=datetime.fromtimestamp(stat.st_ctime),
                        modified=datetime.fromtimestamp(stat.st_mtime),
                        extension=file_path.suffix.lstrip(".") if file_path.suffix else None,
                    )

                    # Apply filter if provided
                    if file_filter and not self._matches_filter(file_info, file_filter):
                        continue

                    files.append(file_info)
                except (PermissionError, OSError) as e:
                    logger.warning(f"Could not access {file_path}: {e}")
                    continue

            return files

        return await asyncio.to_thread(_list)

    async def search_files(
        self,
        query: str,
        start_path: str,
        max_results: int = 100,
    ) -> list[FileInfo]:
        """Search for files matching a query.

        Args:
            query: Search pattern (supports glob patterns)
            start_path: Directory to start search from
            max_results: Maximum number of results

        Returns:
            List of matching files
        """

        def _search() -> list[FileInfo]:
            files: list[FileInfo] = []
            base_path = Path(start_path)

            if not base_path.exists():
                raise FileNotFoundError(f"Directory not found: {start_path}")

            # Use glob pattern or simple name matching
            pattern = query if "*" in query or "?" in query else f"*{query}*"

            for file_path in base_path.rglob(pattern):
                if len(files) >= max_results:
                    break

                try:
                    stat = file_path.stat()
                    files.append(
                        FileInfo(
                            name=file_path.name,
                            path=str(file_path),
                            is_directory=file_path.is_dir(),
                            size=stat.st_size if not file_path.is_dir() else 0,
                            created=datetime.fromtimestamp(stat.st_ctime),
                            modified=datetime.fromtimestamp(stat.st_mtime),
                            extension=file_path.suffix.lstrip(".")
                            if file_path.suffix
                            else None,
                        )
                    )
                except (PermissionError, OSError) as e:
                    logger.warning(f"Could not access {file_path}: {e}")
                    continue

            return files

        return await asyncio.to_thread(_search)

    async def move_file(
        self,
        source: str,
        destination: str,
        overwrite: bool = False,
    ) -> None:
        """Move a file or directory.

        Args:
            source: Source path
            destination: Destination path
            overwrite: Whether to overwrite existing files
        """

        def _move() -> None:
            src = Path(source)
            dst = Path(destination)

            if not src.exists():
                raise FileNotFoundError(f"Source not found: {source}")

            if dst.exists() and not overwrite:
                raise FileExistsError(f"Destination already exists: {destination}")

            # Create parent directories if needed
            dst.parent.mkdir(parents=True, exist_ok=True)

            shutil.move(str(src), str(dst))

        await asyncio.to_thread(_move)
        logger.info(f"Moved {source} to {destination}")

    async def copy_file(
        self,
        source: str,
        destination: str,
        overwrite: bool = False,
    ) -> None:
        """Copy a file or directory.

        Args:
            source: Source path
            destination: Destination path
            overwrite: Whether to overwrite existing files
        """

        def _copy() -> None:
            src = Path(source)
            dst = Path(destination)

            if not src.exists():
                raise FileNotFoundError(f"Source not found: {source}")

            if dst.exists() and not overwrite:
                raise FileExistsError(f"Destination already exists: {destination}")

            # Create parent directories if needed
            dst.parent.mkdir(parents=True, exist_ok=True)

            if src.is_dir():
                shutil.copytree(str(src), str(dst), dirs_exist_ok=overwrite)
            else:
                shutil.copy2(str(src), str(dst))

        await asyncio.to_thread(_copy)
        logger.info(f"Copied {source} to {destination}")

    async def delete_files(
        self,
        paths: list[str],
        move_to_trash: bool = True,
    ) -> None:
        """Delete files.

        Args:
            paths: List of paths to delete
            move_to_trash: Whether to move to trash instead of permanent delete
        """

        def _delete() -> None:
            for path in paths:
                p = Path(path)
                if not p.exists():
                    logger.warning(f"File not found, skipping: {path}")
                    continue

                if move_to_trash:
                    send2trash(str(p))
                else:
                    if p.is_dir():
                        shutil.rmtree(str(p))
                    else:
                        p.unlink()

        await asyncio.to_thread(_delete)
        logger.info(f"Deleted {len(paths)} items (trash={move_to_trash})")

    async def rename_file(self, path: str, new_name: str) -> None:
        """Rename a file.

        Args:
            path: Current file path
            new_name: New file name (not full path)
        """

        def _rename() -> None:
            p = Path(path)
            if not p.exists():
                raise FileNotFoundError(f"File not found: {path}")

            new_path = p.parent / new_name
            if new_path.exists():
                raise FileExistsError(f"File already exists: {new_path}")

            p.rename(new_path)

        await asyncio.to_thread(_rename)
        logger.info(f"Renamed {path} to {new_name}")

    async def create_folder(self, path: str) -> None:
        """Create a folder.

        Args:
            path: Folder path to create
        """

        def _create() -> None:
            p = Path(path)
            p.mkdir(parents=True, exist_ok=True)

        await asyncio.to_thread(_create)
        logger.info(f"Created folder: {path}")

    async def read_file(
        self,
        path: str,
        encoding: str = "utf-8",
        max_size: int = 1024 * 1024,
    ) -> str:
        """Read file contents.

        Args:
            path: File path to read
            encoding: File encoding
            max_size: Maximum file size to read (bytes)

        Returns:
            File contents as string
        """
        p = Path(path)

        if not p.exists():
            raise FileNotFoundError(f"File not found: {path}")

        if p.is_dir():
            raise ValueError(f"Cannot read directory: {path}")

        # Check file size
        size = p.stat().st_size
        if size > max_size:
            raise ValueError(
                f"File too large ({size} bytes). Max size: {max_size} bytes"
            )

        async with aiofiles.open(path, "r", encoding=encoding) as f:
            content = await f.read()

        logger.info(f"Read file: {path} ({len(content)} chars)")
        return content

    async def write_file(
        self,
        path: str,
        content: str,
        encoding: str = "utf-8",
        append: bool = False,
    ) -> None:
        """Write content to a file.

        Args:
            path: File path to write
            content: Content to write
            encoding: File encoding
            append: Whether to append to existing file
        """
        p = Path(path)

        # Create parent directories if needed
        p.parent.mkdir(parents=True, exist_ok=True)

        mode = "a" if append else "w"
        async with aiofiles.open(path, mode, encoding=encoding) as f:
            await f.write(content)

        logger.info(f"Wrote file: {path} ({len(content)} chars, append={append})")

    async def get_file_info(self, path: str) -> FileInfo:
        """Get information about a file.

        Args:
            path: File path

        Returns:
            File information
        """

        def _get_info() -> FileInfo:
            p = Path(path)

            if not p.exists():
                raise FileNotFoundError(f"File not found: {path}")

            stat = p.stat()
            return FileInfo(
                name=p.name,
                path=str(p),
                is_directory=p.is_dir(),
                size=stat.st_size if not p.is_dir() else 0,
                created=datetime.fromtimestamp(stat.st_ctime),
                modified=datetime.fromtimestamp(stat.st_mtime),
                extension=p.suffix.lstrip(".") if p.suffix else None,
            )

        return await asyncio.to_thread(_get_info)

    def _matches_filter(self, file_info: FileInfo, file_filter: FileFilter) -> bool:
        """Check if a file matches the filter criteria.

        Args:
            file_info: File to check
            file_filter: Filter criteria

        Returns:
            True if file matches filter
        """
        # Extension filter
        if file_filter.extension:
            if file_info.extension is None:
                return False
            if file_info.extension.lower() not in [
                e.lower() for e in file_filter.extension
            ]:
                return False

        # Name contains filter
        if file_filter.name_contains:
            if file_filter.name_contains.lower() not in file_info.name.lower():
                return False

        # Modified after filter
        if file_filter.modified_after:
            if file_info.modified < file_filter.modified_after:
                return False

        # Modified before filter
        if file_filter.modified_before:
            if file_info.modified > file_filter.modified_before:
                return False

        # Size filters
        if file_filter.size_greater_than is not None:
            if file_info.size <= file_filter.size_greater_than:
                return False

        if file_filter.size_less_than is not None:
            if file_info.size >= file_filter.size_less_than:
                return False

        return True
