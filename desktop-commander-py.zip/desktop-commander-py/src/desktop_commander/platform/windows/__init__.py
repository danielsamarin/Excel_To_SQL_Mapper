"""Windows-specific platform implementations."""

from desktop_commander.platform.windows.window_manager import WindowsWindowManager
from desktop_commander.platform.windows.file_system import WindowsFileSystem
from desktop_commander.platform.windows.apps import WindowsApps
from desktop_commander.platform.windows.system import WindowsSystem
from desktop_commander.platform.windows.process import WindowsProcess

__all__ = [
    "WindowsWindowManager",
    "WindowsFileSystem",
    "WindowsApps",
    "WindowsSystem",
    "WindowsProcess",
]
