"""Windows system control operations."""

import asyncio
import ctypes
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Literal

import pyperclip
from PIL import ImageGrab
from platformdirs import user_pictures_dir

from desktop_commander.models.types import (
    Bounds,
    BrightnessResult,
    ClipboardResult,
    DndResult,
    ScreenshotResult,
    VolumeResult,
)
from desktop_commander.utils.logger import get_logger

logger = get_logger("platform.windows.system")


class WindowsSystem:
    """Windows system control operations."""

    def __init__(self) -> None:
        """Initialize system control."""
        self._volume_interface = None
        logger.info("WindowsSystem initialized")

    def _get_volume_interface(self):
        """Get the Windows audio endpoint volume interface."""
        if self._volume_interface is None:
            try:
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(
                    IAudioEndpointVolume._iid_, CLSCTX_ALL, None
                )
                self._volume_interface = interface.QueryInterface(IAudioEndpointVolume)
            except Exception as e:
                logger.error(f"Failed to get volume interface: {e}")
                raise RuntimeError(f"Could not access audio controls: {e}")

        return self._volume_interface

    async def control_volume(
        self,
        action: Literal["get", "set", "mute", "unmute"],
        level: int | None = None,
    ) -> VolumeResult:
        """Control system volume.

        Args:
            action: Volume action to perform
            level: Volume level (0-100) for set action

        Returns:
            Current volume state
        """

        def _control() -> VolumeResult:
            volume = self._get_volume_interface()

            if action == "get":
                current_level = int(volume.GetMasterVolumeLevelScalar() * 100)
                is_muted = bool(volume.GetMute())
                return VolumeResult(level=current_level, is_muted=is_muted)

            elif action == "set":
                if level is None:
                    raise ValueError("Level required for set action")
                volume.SetMasterVolumeLevelScalar(level / 100, None)
                return VolumeResult(level=level, is_muted=bool(volume.GetMute()))

            elif action == "mute":
                volume.SetMute(1, None)
                current_level = int(volume.GetMasterVolumeLevelScalar() * 100)
                return VolumeResult(level=current_level, is_muted=True)

            elif action == "unmute":
                volume.SetMute(0, None)
                current_level = int(volume.GetMasterVolumeLevelScalar() * 100)
                return VolumeResult(level=current_level, is_muted=False)

            raise ValueError(f"Invalid action: {action}")

        result = await asyncio.to_thread(_control)
        logger.info(f"Volume {action}: level={result.level}, muted={result.is_muted}")
        return result

    async def control_brightness(
        self,
        action: Literal["get", "set"],
        level: int | None = None,
    ) -> BrightnessResult:
        """Control display brightness.

        Args:
            action: Brightness action to perform
            level: Brightness level (0-100) for set action

        Returns:
            Current brightness level
        """

        def _control() -> BrightnessResult:
            try:
                import wmi

                wmi_obj = wmi.WMI(namespace="wmi")
                monitors = wmi_obj.WmiMonitorBrightness()

                if not monitors:
                    raise RuntimeError("No monitors with brightness control found")

                if action == "get":
                    current = monitors[0].CurrentBrightness
                    return BrightnessResult(level=current)

                elif action == "set":
                    if level is None:
                        raise ValueError("Level required for set action")

                    methods = wmi_obj.WmiMonitorBrightnessMethods()
                    if methods:
                        methods[0].WmiSetBrightness(level, 0)

                    return BrightnessResult(level=level)

            except ImportError:
                # Fallback: use PowerShell
                if action == "get":
                    result = subprocess.run(
                        [
                            "powershell",
                            "-Command",
                            "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness).CurrentBrightness",
                        ],
                        capture_output=True,
                        text=True,
                    )
                    current = int(result.stdout.strip()) if result.stdout.strip() else 50
                    return BrightnessResult(level=current)

                elif action == "set":
                    if level is None:
                        raise ValueError("Level required for set action")
                    subprocess.run(
                        [
                            "powershell",
                            "-Command",
                            f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, {level})",
                        ],
                        capture_output=True,
                    )
                    return BrightnessResult(level=level)

            raise ValueError(f"Invalid action: {action}")

        result = await asyncio.to_thread(_control)
        logger.info(f"Brightness {action}: level={result.level}")
        return result

    async def take_screenshot(
        self,
        region: Bounds | None = None,
        save_path: str | None = None,
        filename: str | None = None,
    ) -> ScreenshotResult:
        """Take a screenshot.

        Args:
            region: Optional region to capture
            save_path: Directory to save screenshot
            filename: Custom filename (without extension)

        Returns:
            Screenshot information
        """

        def _screenshot() -> ScreenshotResult:
            # Capture screen
            if region:
                bbox = (region.x, region.y, region.x + region.width, region.y + region.height)
                image = ImageGrab.grab(bbox=bbox)
            else:
                image = ImageGrab.grab()

            # Determine save path
            if save_path:
                save_dir = Path(save_path)
            else:
                save_dir = Path(user_pictures_dir()) / "Screenshots"

            save_dir.mkdir(parents=True, exist_ok=True)

            # Generate filename
            if filename:
                file_name = f"{filename}.png"
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                file_name = f"screenshot_{timestamp}.png"

            full_path = save_dir / file_name

            # Save image
            image.save(str(full_path), "PNG")

            return ScreenshotResult(
                path=str(full_path),
                width=image.width,
                height=image.height,
            )

        result = await asyncio.to_thread(_screenshot)
        logger.info(f"Screenshot saved: {result.path}")
        return result

    async def control_dnd(
        self,
        action: Literal["status", "on", "off"],
        duration: int | None = None,
    ) -> DndResult:
        """Control Do Not Disturb mode.

        Args:
            action: DND action to perform
            duration: Duration in minutes (for 'on' action)

        Returns:
            DND status
        """

        def _control() -> DndResult:
            import winreg

            # Focus Assist registry key
            key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\CloudStore\Store\DefaultAccount\Current\default$windows.data.notifications.quiethours\windows.data.notifications.quiethours"

            try:
                if action == "status":
                    try:
                        with winreg.OpenKey(
                            winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ
                        ) as key:
                            data, _ = winreg.QueryValueEx(key, "Data")
                            # If data exists and has content, DND is likely enabled
                            enabled = len(data) > 0
                            return DndResult(enabled=enabled)
                    except FileNotFoundError:
                        return DndResult(enabled=False)

                elif action == "on":
                    # Use PowerShell to enable Focus Assist
                    subprocess.run(
                        [
                            "powershell",
                            "-Command",
                            "New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings' -Name 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' -Value 0 -PropertyType DWORD -Force",
                        ],
                        capture_output=True,
                    )
                    return DndResult(enabled=True)

                elif action == "off":
                    subprocess.run(
                        [
                            "powershell",
                            "-Command",
                            "Set-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings' -Name 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' -Value 1",
                        ],
                        capture_output=True,
                    )
                    return DndResult(enabled=False)

            except Exception as e:
                logger.error(f"DND control error: {e}")
                raise

            raise ValueError(f"Invalid action: {action}")

        result = await asyncio.to_thread(_control)
        logger.info(f"DND {action}: enabled={result.enabled}")
        return result

    async def lock_screen(self) -> None:
        """Lock the screen."""

        def _lock() -> None:
            ctypes.windll.user32.LockWorkStation()

        await asyncio.to_thread(_lock)
        logger.info("Screen locked")

    async def sleep(self) -> None:
        """Put the system to sleep."""

        def _sleep() -> None:
            # Use rundll32 to call SetSuspendState
            subprocess.run(
                [
                    "rundll32.exe",
                    "powrprof.dll,SetSuspendState",
                    "0",
                    "1",
                    "0",
                ],
                capture_output=True,
            )

        await asyncio.to_thread(_sleep)
        logger.info("System going to sleep")

    async def read_clipboard(
        self, format: Literal["text", "html"] = "text"
    ) -> ClipboardResult:
        """Read clipboard contents.

        Args:
            format: Content format to read

        Returns:
            Clipboard contents
        """

        def _read() -> ClipboardResult:
            if format == "text":
                content = pyperclip.paste()
                return ClipboardResult(content=content, format="text")
            elif format == "html":
                # HTML clipboard requires win32clipboard
                import win32clipboard

                win32clipboard.OpenClipboard()
                try:
                    # Try to get HTML format
                    cf_html = win32clipboard.RegisterClipboardFormat("HTML Format")
                    try:
                        data = win32clipboard.GetClipboardData(cf_html)
                        content = data.decode("utf-8") if isinstance(data, bytes) else data
                        return ClipboardResult(content=content, format="html")
                    except Exception:
                        # Fall back to text
                        content = pyperclip.paste()
                        return ClipboardResult(content=content, format="text")
                finally:
                    win32clipboard.CloseClipboard()

            raise ValueError(f"Unsupported format: {format}")

        result = await asyncio.to_thread(_read)
        logger.info(f"Read clipboard: {len(result.content)} chars ({result.format})")
        return result

    async def write_clipboard(
        self, content: str, format: Literal["text", "html"] = "text"
    ) -> None:
        """Write to clipboard.

        Args:
            content: Content to write
            format: Content format
        """

        def _write() -> None:
            if format == "text":
                pyperclip.copy(content)
            elif format == "html":
                import win32clipboard

                win32clipboard.OpenClipboard()
                try:
                    win32clipboard.EmptyClipboard()
                    # Set both HTML and text formats
                    cf_html = win32clipboard.RegisterClipboardFormat("HTML Format")
                    # Wrap content in HTML format
                    html_data = (
                        "Version:0.9\r\n"
                        "StartHTML:00000097\r\n"
                        "EndHTML:ENDHTML\r\n"
                        "StartFragment:00000133\r\n"
                        "EndFragment:ENDFRAGMENT\r\n"
                        "<html><body><!--StartFragment-->"
                        f"{content}"
                        "<!--EndFragment--></body></html>"
                    )
                    # Calculate positions
                    end_fragment = html_data.find("<!--EndFragment-->")
                    end_html = len(html_data)
                    html_data = html_data.replace(
                        "ENDFRAGMENT", str(end_fragment).zfill(8)
                    ).replace("ENDHTML", str(end_html).zfill(8))

                    win32clipboard.SetClipboardData(cf_html, html_data.encode("utf-8"))
                    win32clipboard.SetClipboardData(
                        win32clipboard.CF_UNICODETEXT, content
                    )
                finally:
                    win32clipboard.CloseClipboard()
            else:
                raise ValueError(f"Unsupported format: {format}")

        await asyncio.to_thread(_write)
        logger.info(f"Wrote to clipboard: {len(content)} chars ({format})")

    async def clear_clipboard(self) -> None:
        """Clear clipboard contents."""

        def _clear() -> None:
            import win32clipboard

            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard()
            finally:
                win32clipboard.CloseClipboard()

        await asyncio.to_thread(_clear)
        logger.info("Clipboard cleared")
