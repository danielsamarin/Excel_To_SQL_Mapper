"""Platform abstraction layer for Desktop Commander."""

from desktop_commander.platform.adapter import UnifiedAdapter, get_adapter

__all__ = ["UnifiedAdapter", "get_adapter"]
