"""Service modules for Desktop Commander."""

from desktop_commander.services.store import Store, get_store
from desktop_commander.services.tray import SystemTray, create_tray, get_tray
from desktop_commander.services.hotkeys import HotkeyManager, get_hotkey_manager, setup_default_hotkey

__all__ = [
    "Store",
    "get_store",
    "SystemTray",
    "create_tray",
    "get_tray",
    "HotkeyManager",
    "get_hotkey_manager",
    "setup_default_hotkey",
]
