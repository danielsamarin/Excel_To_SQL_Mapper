"""System tray integration using pystray."""

import threading
from collections.abc import Callable
from io import BytesIO
from typing import Any

from PIL import Image, ImageDraw

from desktop_commander.utils.logger import get_logger

logger = get_logger("service.tray")

# Global tray instance
_tray_instance: "SystemTray | None" = None


class SystemTray:
    """System tray integration for Desktop Commander."""

    def __init__(
        self,
        on_show: Callable[[], None] | None = None,
        on_settings: Callable[[], None] | None = None,
        on_quit: Callable[[], None] | None = None,
    ) -> None:
        """Initialize the system tray.

        Args:
            on_show: Callback when Show is clicked
            on_settings: Callback when Settings is clicked
            on_quit: Callback when Quit is clicked
        """
        self.on_show = on_show
        self.on_settings = on_settings
        self.on_quit = on_quit
        self._icon: Any = None
        self._thread: threading.Thread | None = None
        self._running = False

        logger.info("SystemTray initialized")

    def start(self) -> None:
        """Start the system tray icon."""
        if self._running:
            return

        try:
            import pystray

            # Create icon image
            image = self._create_icon_image()

            # Create menu
            menu = pystray.Menu(
                pystray.MenuItem("Show", self._handle_show, default=True),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Settings", self._handle_settings),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Quit", self._handle_quit),
            )

            # Create icon
            self._icon = pystray.Icon(
                name="desktop-commander",
                icon=image,
                title="Desktop Commander",
                menu=menu,
            )

            # Run in background thread
            self._running = True
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

            logger.info("System tray started")

        except Exception as e:
            logger.error(f"Failed to start system tray: {e}")

    def stop(self) -> None:
        """Stop the system tray icon."""
        if self._icon:
            self._icon.stop()
            self._running = False
            logger.info("System tray stopped")

    def _run(self) -> None:
        """Run the system tray (called in background thread)."""
        if self._icon:
            self._icon.run()

    def _create_icon_image(self, size: int = 64) -> Image.Image:
        """Create the tray icon image.

        Args:
            size: Icon size in pixels

        Returns:
            PIL Image object
        """
        # Create a simple icon
        image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)

        # Draw a rounded rectangle (command palette icon)
        margin = size // 8
        draw.rounded_rectangle(
            [margin, margin, size - margin, size - margin],
            radius=size // 8,
            fill=(100, 149, 237),  # Cornflower blue
            outline=(255, 255, 255),
            width=2,
        )

        # Draw command prompt symbol (>_)
        text_y = size // 3
        draw.text(
            (size // 4, text_y),
            ">_",
            fill=(255, 255, 255),
        )

        return image

    def _handle_show(self, icon: Any = None, item: Any = None) -> None:
        """Handle Show menu item click."""
        if self.on_show:
            self.on_show()

    def _handle_settings(self, icon: Any = None, item: Any = None) -> None:
        """Handle Settings menu item click."""
        if self.on_settings:
            self.on_settings()

    def _handle_quit(self, icon: Any = None, item: Any = None) -> None:
        """Handle Quit menu item click."""
        self.stop()
        if self.on_quit:
            self.on_quit()

    def show_notification(self, title: str, message: str) -> None:
        """Show a notification from the system tray.

        Args:
            title: Notification title
            message: Notification message
        """
        if self._icon:
            self._icon.notify(message, title)


def get_tray() -> SystemTray:
    """Get the singleton system tray instance.

    Returns:
        SystemTray instance
    """
    global _tray_instance
    if _tray_instance is None:
        _tray_instance = SystemTray()
    return _tray_instance


def create_tray(
    on_show: Callable[[], None] | None = None,
    on_settings: Callable[[], None] | None = None,
    on_quit: Callable[[], None] | None = None,
) -> SystemTray:
    """Create and configure the system tray.

    Args:
        on_show: Callback when Show is clicked
        on_settings: Callback when Settings is clicked
        on_quit: Callback when Quit is clicked

    Returns:
        Configured SystemTray instance
    """
    global _tray_instance
    _tray_instance = SystemTray(
        on_show=on_show,
        on_settings=on_settings,
        on_quit=on_quit,
    )
    return _tray_instance
