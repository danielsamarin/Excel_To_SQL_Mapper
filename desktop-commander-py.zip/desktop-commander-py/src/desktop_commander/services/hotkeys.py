"""Global hotkey registration using the keyboard library."""

import threading
from collections.abc import Callable

from desktop_commander.services.store import get_store
from desktop_commander.utils.logger import get_logger

logger = get_logger("service.hotkeys")

# Global hotkey manager instance
_hotkey_manager: "HotkeyManager | None" = None


class HotkeyManager:
    """Manager for global hotkey registration."""

    def __init__(self) -> None:
        """Initialize the hotkey manager."""
        self._callbacks: dict[str, Callable[[], None]] = {}
        self._registered_hotkeys: list[str] = []
        self._running = False
        self._lock = threading.Lock()

        logger.info("HotkeyManager initialized")

    def register(self, hotkey: str, callback: Callable[[], None]) -> bool:
        """Register a global hotkey.

        Args:
            hotkey: Hotkey string (e.g., "ctrl+shift+space")
            callback: Function to call when hotkey is pressed

        Returns:
            True if registration was successful
        """
        try:
            import keyboard

            with self._lock:
                # Unregister existing hotkey if any
                if hotkey in self._registered_hotkeys:
                    keyboard.remove_hotkey(hotkey)
                    self._registered_hotkeys.remove(hotkey)

                # Register new hotkey
                keyboard.add_hotkey(hotkey, callback, suppress=True)
                self._registered_hotkeys.append(hotkey)
                self._callbacks[hotkey] = callback

                logger.info(f"Registered hotkey: {hotkey}")
                return True

        except Exception as e:
            logger.error(f"Failed to register hotkey {hotkey}: {e}")
            return False

    def unregister(self, hotkey: str) -> bool:
        """Unregister a global hotkey.

        Args:
            hotkey: Hotkey string to unregister

        Returns:
            True if unregistration was successful
        """
        try:
            import keyboard

            with self._lock:
                if hotkey in self._registered_hotkeys:
                    keyboard.remove_hotkey(hotkey)
                    self._registered_hotkeys.remove(hotkey)
                    if hotkey in self._callbacks:
                        del self._callbacks[hotkey]

                    logger.info(f"Unregistered hotkey: {hotkey}")
                    return True

                return False

        except Exception as e:
            logger.error(f"Failed to unregister hotkey {hotkey}: {e}")
            return False

    def unregister_all(self) -> None:
        """Unregister all hotkeys."""
        try:
            import keyboard

            with self._lock:
                for hotkey in self._registered_hotkeys.copy():
                    try:
                        keyboard.remove_hotkey(hotkey)
                    except Exception:
                        pass

                self._registered_hotkeys.clear()
                self._callbacks.clear()

                logger.info("Unregistered all hotkeys")

        except Exception as e:
            logger.error(f"Failed to unregister all hotkeys: {e}")

    def update_hotkey(
        self,
        old_hotkey: str,
        new_hotkey: str,
        callback: Callable[[], None] | None = None,
    ) -> bool:
        """Update a hotkey registration.

        Args:
            old_hotkey: Current hotkey string
            new_hotkey: New hotkey string
            callback: Optional new callback (uses existing if not provided)

        Returns:
            True if update was successful
        """
        with self._lock:
            # Get existing callback if not provided
            if callback is None:
                callback = self._callbacks.get(old_hotkey)
                if callback is None:
                    logger.warning(f"No callback found for hotkey {old_hotkey}")
                    return False

            # Unregister old and register new
            self.unregister(old_hotkey)
            return self.register(new_hotkey, callback)

    @property
    def registered_hotkeys(self) -> list[str]:
        """Get list of registered hotkeys."""
        return self._registered_hotkeys.copy()


def get_hotkey_manager() -> HotkeyManager:
    """Get the singleton hotkey manager instance.

    Returns:
        HotkeyManager instance
    """
    global _hotkey_manager
    if _hotkey_manager is None:
        _hotkey_manager = HotkeyManager()
    return _hotkey_manager


def setup_default_hotkey(
    toggle_callback: Callable[[], None],
) -> bool:
    """Set up the default hotkey from settings.

    Args:
        toggle_callback: Function to call when hotkey is pressed

    Returns:
        True if setup was successful
    """
    store = get_store()
    settings = store.get_settings()

    manager = get_hotkey_manager()
    return manager.register(settings.hotkey, toggle_callback)
