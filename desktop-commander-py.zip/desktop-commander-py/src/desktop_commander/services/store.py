"""Persistent settings store for Desktop Commander."""

import json
from pathlib import Path
from threading import Lock
from typing import Any

from platformdirs import user_data_dir

from desktop_commander.models.mcp import StoredMCPServer
from desktop_commander.models.settings import Settings
from desktop_commander.utils.logger import get_logger

APP_NAME = "desktop-commander"

logger = get_logger("store")

_store_instance: "Store | None" = None
_store_lock = Lock()


class Store:
    """JSON-based persistent store for settings and data."""

    def __init__(self, data_dir: Path | None = None):
        """Initialize the store.

        Args:
            data_dir: Optional custom data directory path
        """
        self._data_dir = data_dir or Path(user_data_dir(APP_NAME))
        self._data_dir.mkdir(parents=True, exist_ok=True)

        self._settings_file = self._data_dir / "settings.json"
        self._mcp_servers_file = self._data_dir / "mcp-servers.json"
        self._history_file = self._data_dir / "history.json"

        self._lock = Lock()
        self._settings: Settings | None = None
        self._mcp_servers: dict[str, StoredMCPServer] | None = None
        self._history: list[str] | None = None

        logger.info(f"Store initialized at {self._data_dir}")

    def _read_json(self, file_path: Path) -> dict[str, Any] | list[Any] | None:
        """Read JSON from a file.

        Args:
            file_path: Path to the JSON file

        Returns:
            Parsed JSON data or None if file doesn't exist
        """
        try:
            if file_path.exists():
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error reading {file_path}: {e}")
        return None

    def _write_json(self, file_path: Path, data: dict[str, Any] | list[Any]) -> bool:
        """Write JSON to a file.

        Args:
            file_path: Path to the JSON file
            data: Data to write

        Returns:
            True if successful, False otherwise
        """
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str)
            return True
        except IOError as e:
            logger.error(f"Error writing {file_path}: {e}")
            return False

    # Settings methods
    def get_settings(self) -> Settings:
        """Get application settings.

        Returns:
            Settings object (loads from disk if not cached)
        """
        with self._lock:
            if self._settings is None:
                data = self._read_json(self._settings_file)
                if data and isinstance(data, dict):
                    try:
                        self._settings = Settings.model_validate(data)
                    except Exception as e:
                        logger.warning(f"Invalid settings, using defaults: {e}")
                        self._settings = Settings.default()
                else:
                    self._settings = Settings.default()
            return self._settings

    def set_settings(self, settings: Settings) -> bool:
        """Save application settings.

        Args:
            settings: Settings to save

        Returns:
            True if successful
        """
        with self._lock:
            if self._write_json(self._settings_file, settings.model_dump()):
                self._settings = settings
                logger.info("Settings saved")
                return True
            return False

    def update_settings(self, **kwargs: Any) -> Settings:
        """Update specific settings fields.

        Args:
            **kwargs: Settings fields to update

        Returns:
            Updated settings
        """
        settings = self.get_settings()
        updated = settings.model_copy(update=kwargs)
        self.set_settings(updated)
        return updated

    # MCP Servers methods
    def get_mcp_servers(self) -> dict[str, StoredMCPServer]:
        """Get MCP server configurations.

        Returns:
            Dictionary of server ID to StoredMCPServer
        """
        with self._lock:
            if self._mcp_servers is None:
                data = self._read_json(self._mcp_servers_file)
                if data and isinstance(data, dict):
                    self._mcp_servers = {}
                    for server_id, server_data in data.items():
                        try:
                            self._mcp_servers[server_id] = StoredMCPServer.model_validate(
                                server_data
                            )
                        except Exception as e:
                            logger.warning(f"Invalid MCP server {server_id}: {e}")
                else:
                    self._mcp_servers = {}
            return self._mcp_servers

    def add_mcp_server(self, server: StoredMCPServer) -> bool:
        """Add or update an MCP server.

        Args:
            server: Server to add

        Returns:
            True if successful
        """
        with self._lock:
            servers = self.get_mcp_servers()
            servers[server.id] = server
            if self._write_json(
                self._mcp_servers_file,
                {sid: s.model_dump() for sid, s in servers.items()}
            ):
                self._mcp_servers = servers
                logger.info(f"MCP server added: {server.config.name}")
                return True
            return False

    def remove_mcp_server(self, server_id: str) -> bool:
        """Remove an MCP server.

        Args:
            server_id: ID of server to remove

        Returns:
            True if successful
        """
        with self._lock:
            servers = self.get_mcp_servers()
            if server_id in servers:
                del servers[server_id]
                if self._write_json(
                    self._mcp_servers_file,
                    {sid: s.model_dump() for sid, s in servers.items()}
                ):
                    self._mcp_servers = servers
                    logger.info(f"MCP server removed: {server_id}")
                    return True
            return False

    def get_enabled_mcp_servers(self) -> list[StoredMCPServer]:
        """Get all enabled MCP servers.

        Returns:
            List of enabled servers
        """
        servers = self.get_mcp_servers()
        return [s for s in servers.values() if s.config.enabled]

    # History methods
    def get_history(self, limit: int = 50) -> list[str]:
        """Get command history.

        Args:
            limit: Maximum number of history entries to return

        Returns:
            List of previous commands (most recent first)
        """
        with self._lock:
            if self._history is None:
                data = self._read_json(self._history_file)
                self._history = data if isinstance(data, list) else []
            return self._history[:limit]

    def add_to_history(self, command: str) -> None:
        """Add a command to history.

        Args:
            command: Command to add
        """
        with self._lock:
            history = self.get_history(limit=1000)
            # Remove duplicates and add to front
            if command in history:
                history.remove(command)
            history.insert(0, command)
            # Keep only last 100 entries
            history = history[:100]
            if self._write_json(self._history_file, history):
                self._history = history

    def clear_history(self) -> None:
        """Clear command history."""
        with self._lock:
            self._history = []
            self._write_json(self._history_file, [])
            logger.info("History cleared")


def get_store() -> Store:
    """Get the singleton store instance.

    Returns:
        Store instance
    """
    global _store_instance
    with _store_lock:
        if _store_instance is None:
            _store_instance = Store()
        return _store_instance
