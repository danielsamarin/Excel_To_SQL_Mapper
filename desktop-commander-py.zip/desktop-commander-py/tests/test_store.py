"""Tests for the settings store."""

import tempfile
from pathlib import Path

import pytest

from desktop_commander.services.store import Store
from desktop_commander.models.settings import Settings


class TestStore:
    """Tests for Store class."""

    @pytest.fixture
    def temp_store(self, tmp_path: Path):
        """Create a store with temporary directory."""
        return Store(data_dir=tmp_path)

    def test_default_settings(self, temp_store: Store):
        """Test that default settings are returned when no file exists."""
        settings = temp_store.get_settings()
        assert settings.hotkey == "ctrl+shift+space"
        assert settings.theme == "system"

    def test_save_and_load_settings(self, temp_store: Store):
        """Test saving and loading settings."""
        settings = Settings(hotkey="ctrl+alt+x", theme="dark")
        temp_store.set_settings(settings)

        loaded = temp_store.get_settings()
        assert loaded.hotkey == "ctrl+alt+x"
        assert loaded.theme == "dark"

    def test_update_settings(self, temp_store: Store):
        """Test updating specific settings."""
        temp_store.update_settings(theme="light")
        settings = temp_store.get_settings()
        assert settings.theme == "light"

    def test_history(self, temp_store: Store):
        """Test command history."""
        temp_store.add_to_history("list windows")
        temp_store.add_to_history("take screenshot")

        history = temp_store.get_history()
        assert len(history) == 2
        assert history[0] == "take screenshot"  # Most recent first
        assert history[1] == "list windows"

    def test_history_deduplication(self, temp_store: Store):
        """Test that duplicate commands are moved to front."""
        temp_store.add_to_history("list windows")
        temp_store.add_to_history("take screenshot")
        temp_store.add_to_history("list windows")

        history = temp_store.get_history()
        assert len(history) == 2
        assert history[0] == "list windows"

    def test_clear_history(self, temp_store: Store):
        """Test clearing history."""
        temp_store.add_to_history("command 1")
        temp_store.add_to_history("command 2")
        temp_store.clear_history()

        history = temp_store.get_history()
        assert len(history) == 0
