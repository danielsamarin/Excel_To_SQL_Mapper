"""Tests for Pydantic models."""

import pytest
from datetime import datetime

from desktop_commander.models.types import (
    Bounds,
    WindowInfo,
    FileInfo,
    OperationResult,
    StreamEvent,
    StreamEventType,
)
from desktop_commander.models.settings import Settings


class TestBounds:
    """Tests for Bounds model."""

    def test_create_bounds(self):
        bounds = Bounds(x=0, y=0, width=100, height=100)
        assert bounds.x == 0
        assert bounds.y == 0
        assert bounds.width == 100
        assert bounds.height == 100


class TestWindowInfo:
    """Tests for WindowInfo model."""

    def test_create_window_info(self):
        window = WindowInfo(
            id="12345",
            title="Test Window",
            app="TestApp",
            process_id=1234,
            bounds=Bounds(x=0, y=0, width=800, height=600),
        )
        assert window.id == "12345"
        assert window.title == "Test Window"
        assert window.is_focused is False
        assert window.is_minimized is False


class TestFileInfo:
    """Tests for FileInfo model."""

    def test_create_file_info(self):
        now = datetime.now()
        file = FileInfo(
            name="test.txt",
            path="/path/to/test.txt",
            is_directory=False,
            size=1024,
            created=now,
            modified=now,
            extension="txt",
        )
        assert file.name == "test.txt"
        assert file.size == 1024
        assert file.is_directory is False


class TestOperationResult:
    """Tests for OperationResult model."""

    def test_success_result(self):
        result = OperationResult.ok(data="test data")
        assert result.success is True
        assert result.data == "test data"
        assert result.error is None

    def test_failure_result(self):
        result = OperationResult.fail(error="Something went wrong")
        assert result.success is False
        assert result.data is None
        assert result.error == "Something went wrong"


class TestStreamEvent:
    """Tests for StreamEvent model."""

    def test_text_event(self):
        event = StreamEvent(type=StreamEventType.TEXT, content="Hello")
        assert event.type == StreamEventType.TEXT
        assert event.content == "Hello"

    def test_tool_call_event(self):
        event = StreamEvent(
            type=StreamEventType.TOOL_CALL,
            tool_name="window_list",
            tool_args={"filter": "all"},
        )
        assert event.type == StreamEventType.TOOL_CALL
        assert event.tool_name == "window_list"
        assert event.tool_args == {"filter": "all"}


class TestSettings:
    """Tests for Settings model."""

    def test_default_settings(self):
        settings = Settings.default()
        assert settings.hotkey == "ctrl+shift+space"
        assert settings.theme == "system"
        assert settings.ui.show_in_tray is True

    def test_settings_validation(self):
        settings = Settings(
            hotkey="ctrl+alt+c",
            theme="dark",
        )
        assert settings.hotkey == "ctrl+alt+c"
        assert settings.theme == "dark"
