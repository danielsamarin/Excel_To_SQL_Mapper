"""Tests for Desktop Commander."""
