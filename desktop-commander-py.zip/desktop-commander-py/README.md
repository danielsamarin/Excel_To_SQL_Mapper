# Desktop Commander

AI-powered desktop automation using natural language commands.

## Overview

Desktop Commander is a Python application that lets you control your Windows desktop using natural language. It provides a command palette interface where you can type commands like "list windows", "set volume to 50%", or "take a screenshot", and the AI will execute the appropriate actions.

## Features

- **Window Management**: List, focus, resize, move, minimize, maximize, close, and arrange windows
- **File Operations**: List, search, move, copy, delete, rename files and folders
- **Application Control**: List, launch, quit, and switch applications
- **System Control**: Volume, brightness, screenshots, Do Not Disturb, lock, sleep
- **Process Management**: List, inspect, and kill processes
- **Clipboard Operations**: Read, write, and clear clipboard
- **Office Integration**: Create Word, Excel, PowerPoint documents

## Requirements

- Windows 10/11
- Python 3.11 or higher

## Installation

```bash
# Clone the repository
git clone https://github.com/your-repo/desktop-commander-py.git
cd desktop-commander-py

# Create virtual environment
python -m venv venv
venv\Scripts\activate

# Install in development mode
pip install -e ".[dev]"
```

## Usage

### Run in Native Mode (Recommended)

```bash
desktop-commander
```

Or:

```bash
python -m desktop_commander
```

### Run in Browser Mode

```bash
desktop-commander --browser --port 8080
```

### Command Line Options

- `--debug`: Enable debug logging
- `--browser`: Run in browser mode instead of native window
- `--port PORT`: Port for browser mode (default: 8080)

## Global Hotkey

Press `Ctrl+Shift+Space` to show/hide the command palette (configurable in settings).

## Architecture

```
desktop-commander-py/
├── src/desktop_commander/
│   ├── copilot/          # Copilot SDK integration
│   ├── tools/            # Tool definitions (37 tools)
│   ├── platform/         # Platform-specific implementations
│   │   └── windows/      # Windows implementations
│   ├── ui/               # NiceGUI user interface
│   ├── services/         # Tray, hotkeys, storage
│   └── models/           # Pydantic models
└── tests/
```

## Development

### Run Tests

```bash
pytest
```

### Code Quality

```bash
# Linting
ruff check src/

# Type checking
mypy src/
```

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
