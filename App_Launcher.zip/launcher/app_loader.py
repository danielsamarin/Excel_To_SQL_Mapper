"""Dynamic app loader for discovering and loading app modules."""

import importlib.util
import logging
import sys
from collections import defaultdict
from pathlib import Path

from nicegui import ui

from .models import AppInfo

logger = logging.getLogger(__name__)


class AppLoader:
    """Discovers and loads app modules from the apps directory."""

    def __init__(self, apps_dir: Path | str = "apps"):
        self.apps_dir = Path(apps_dir).resolve()
        self.apps: list[AppInfo] = []
        self._apps_by_category: dict[str, list[AppInfo]] = defaultdict(list)

    def discover_apps(self) -> list[AppInfo]:
        """Scan the apps directory and load all valid app modules."""
        self.apps.clear()
        self._apps_by_category.clear()

        if not self.apps_dir.exists():
            logger.warning(f"Apps directory not found: {self.apps_dir}")
            return self.apps

        for file_path in sorted(self.apps_dir.glob("*.py")):
            if file_path.name.startswith("_") or file_path.name == "__init__.py":
                continue

            app_info = self._load_app(file_path)
            if app_info:
                self.apps.append(app_info)
                self._apps_by_category[app_info.category].append(app_info)
                logger.info(f"Loaded app: {app_info.name} from {file_path.name}")

        return self.apps

    def _load_app(self, file_path: Path) -> AppInfo | None:
        """Load a single app module and extract its metadata."""
        module_name = f"apps.{file_path.stem}"

        try:
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            if spec is None or spec.loader is None:
                logger.error(f"Could not load spec for {file_path}")
                return None

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            if not hasattr(module, "APP_INFO"):
                logger.warning(f"Module {file_path.name} missing APP_INFO")
                return None

            if not hasattr(module, "build_ui"):
                logger.warning(f"Module {file_path.name} missing build_ui function")
                return None

            return AppInfo.from_module(module, file_path)

        except Exception as e:
            logger.error(f"Error loading {file_path.name}: {e}")
            return None

    def get_apps_by_category(self) -> dict[str, list[AppInfo]]:
        """Get apps grouped by category."""
        return dict(self._apps_by_category)

    def register_routes(self, frame_context) -> None:
        """Register NiceGUI routes for all loaded apps."""
        for app_info in self.apps:
            self._register_app_route(app_info, frame_context)

    def _register_app_route(self, app_info: AppInfo, frame_context) -> None:
        """Register a single app's route."""

        @ui.page(app_info.route)
        def app_page(info: AppInfo = app_info, frame=frame_context):
            with frame(info.name):
                if info.build_ui:
                    info.build_ui()
