"""Data models for the app launcher."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
import re


@dataclass
class AppInfo:
    """Holds metadata and reference to a loaded app module."""

    name: str
    icon: str
    description: str
    category: str
    author: str
    version: str = "1.0.0"
    enabled: bool = True
    file_path: Path = field(default_factory=Path)
    build_ui: Callable[[], None] | None = None

    @property
    def slug(self) -> str:
        """Generate URL-safe slug from app name."""
        return re.sub(r"[^a-z0-9]+", "-", self.name.lower()).strip("-")

    @property
    def route(self) -> str:
        """Get the route path for this app."""
        return f"/app/{self.slug}"

    @classmethod
    def from_module(cls, module: Any, file_path: Path) -> "AppInfo":
        """Create AppInfo from a loaded module."""
        info = module.APP_INFO
        return cls(
            name=info["name"],
            icon=info.get("icon", "apps"),
            description=info.get("description", ""),
            category=info.get("category", "Uncategorized"),
            author=info.get("author", "Unknown"),
            version=info.get("version", "1.0.0"),
            file_path=file_path,
            build_ui=module.build_ui,
        )
