"""Reusable SQLite database module for all apps."""

import sqlite3
from pathlib import Path


class Database:
    """Shared database connection for all apps.

    Usage:
        from launcher.db import Database

        # Create app-specific table
        Database.execute('''
            CREATE TABLE IF NOT EXISTS myapp_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            )
        ''')

        # Insert data
        Database.execute("INSERT INTO myapp_items (name) VALUES (?)", ("item1",))

        # Query data
        cursor = Database.execute("SELECT * FROM myapp_items")
        rows = cursor.fetchall()
    """

    _instance: sqlite3.Connection | None = None

    @classmethod
    def get_connection(cls) -> sqlite3.Connection:
        """Get or create the shared database connection."""
        if cls._instance is None:
            data_dir = Path(__file__).parent.parent / "data"
            data_dir.mkdir(exist_ok=True)
            cls._instance = sqlite3.connect(
                data_dir / "launcher.db",
                check_same_thread=False,
            )
            cls._instance.row_factory = sqlite3.Row
        return cls._instance

    @classmethod
    def execute(cls, query: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a query and return cursor."""
        conn = cls.get_connection()
        cursor = conn.execute(query, params)
        conn.commit()
        return cursor

    @classmethod
    def executemany(cls, query: str, params_list: list[tuple]) -> sqlite3.Cursor:
        """Execute a query with multiple parameter sets."""
        conn = cls.get_connection()
        cursor = conn.executemany(query, params_list)
        conn.commit()
        return cursor

    @classmethod
    def fetchone(cls, query: str, params: tuple = ()) -> sqlite3.Row | None:
        """Execute query and fetch one result."""
        cursor = cls.execute(query, params)
        return cursor.fetchone()

    @classmethod
    def fetchall(cls, query: str, params: tuple = ()) -> list[sqlite3.Row]:
        """Execute query and fetch all results."""
        cursor = cls.execute(query, params)
        return cursor.fetchall()
