"""Shared frame layout for all pages."""

from contextlib import contextmanager
from typing import Generator

from nicegui import app, ui

from ..models import AppInfo
from .sidebar import Sidebar

# Global reference to loaded apps (set by main.py)
_apps_by_category: dict[str, list[AppInfo]] = {}


def set_apps(apps_by_category: dict[str, list[AppInfo]]) -> None:
    """Set the apps for the sidebar (called from main.py)."""
    global _apps_by_category
    _apps_by_category = apps_by_category


@contextmanager
def frame(title: str = "App Launcher") -> Generator[None, None, None]:
    """Shared frame with header and sidebar for all pages.

    Usage:
        with frame("My Page Title"):
            ui.label("Page content here")
    """
    ui.colors(
        primary="#3b82f6",
        secondary="#64748b",
        accent="#8b5cf6",
        positive="#22c55e",
        negative="#ef4444",
    )

    # Dark mode with persistence
    dark = ui.dark_mode(app.storage.user.get("dark_mode", False))

    def toggle_dark_mode():
        dark.toggle()
        app.storage.user["dark_mode"] = dark.value

    # Header
    with ui.header().classes("bg-primary text-white items-center px-4"):
        ui.button(
            icon="menu", on_click=lambda: sidebar_drawer.toggle()
        ).props("flat color=white")
        ui.label("App Launcher").classes("font-bold text-lg")
        ui.space()
        ui.label(title).classes("text-sm opacity-80 mr-4")
        ui.button(
            icon="dark_mode", on_click=toggle_dark_mode
        ).props("flat color=white")

    # Sidebar
    sidebar = Sidebar(_apps_by_category)
    sidebar_drawer = sidebar.render()

    # Main content area
    with ui.column().classes("p-6 w-full"):
        yield
