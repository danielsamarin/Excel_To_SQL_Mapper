"""Sidebar navigation component."""

from nicegui import ui

from ..models import AppInfo


class Sidebar:
    """Sidebar component that displays apps grouped by category."""

    def __init__(self, apps_by_category: dict[str, list[AppInfo]]):
        self.apps_by_category = apps_by_category

    def render(self) -> ui.left_drawer:
        """Render the sidebar with app navigation."""
        with ui.left_drawer(
            value=True, top_corner=True, bottom_corner=True, elevated=True
        ).props("width=250").classes("bg-slate-50 dark:bg-slate-800") as drawer:

            with ui.column().classes("w-full"):
                # Home link
                with ui.row().classes(
                    "w-full items-center px-4 py-2 cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700"
                ).on("click", lambda: ui.navigate.to("/")):
                    ui.icon("home").classes("text-slate-600 dark:text-slate-300")
                    ui.label("Home").classes("text-slate-700 dark:text-slate-200")

                ui.separator().classes("my-2")

                # Apps grouped by category
                for category in sorted(self.apps_by_category.keys()):
                    apps = self.apps_by_category[category]
                    self._render_category(category, apps)

        return drawer

    def _render_category(self, category: str, apps: list[AppInfo]) -> None:
        """Render a category section with its apps."""
        ui.label(category).classes(
            "font-bold text-slate-500 dark:text-slate-400 px-4 pt-4 pb-1 text-xs uppercase tracking-wide"
        )

        for app in apps:
            self._render_app_link(app)

    def _render_app_link(self, app: AppInfo) -> None:
        """Render a single app link."""
        with ui.row().classes(
            "w-full items-center px-4 py-2 cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 gap-3"
        ).on("click", lambda a=app: ui.navigate.to(a.route)):
            ui.icon(app.icon).classes("text-slate-600 dark:text-slate-300")
            with ui.column().classes("gap-0"):
                ui.label(app.name).classes("text-slate-700 dark:text-slate-200 font-medium")
                if app.description:
                    ui.label(app.description).classes(
                        "text-xs text-slate-400 dark:text-slate-500 truncate max-w-[180px]"
                    )
