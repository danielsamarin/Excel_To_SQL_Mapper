"""NiceGUI App Launcher - Main entry point."""

import logging
from pathlib import Path

from nicegui import ui

from launcher import AppLoader
from launcher.ui.frame import frame, set_apps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def main() -> None:
    """Initialize and run the app launcher."""
    # Discover and load apps
    apps_dir = Path(__file__).parent / "apps"
    loader = AppLoader(apps_dir)
    apps = loader.discover_apps()

    logger.info(f"Discovered {len(apps)} apps")

    # Set apps for the sidebar
    set_apps(loader.get_apps_by_category())

    # Register routes for all apps
    loader.register_routes(frame)

    # Create home page
    @ui.page("/")
    def home():
        with frame("Home"):
            ui.label("App Launcher").classes("text-3xl font-bold")
            ui.label("Select an app from the sidebar to get started.").classes(
                "text-slate-600 mb-6"
            )

            # Display app cards
            apps_by_category = loader.get_apps_by_category()

            for category in sorted(apps_by_category.keys()):
                category_apps = apps_by_category[category]

                ui.label(category).classes("text-xl font-semibold mt-6 mb-3")

                with ui.row().classes("flex-wrap gap-4"):
                    for app in category_apps:
                        with ui.card().classes(
                            "w-64 cursor-pointer hover:shadow-lg transition-shadow"
                        ).on("click", lambda a=app: ui.navigate.to(a.route)):
                            with ui.row().classes("items-center gap-3"):
                                ui.icon(app.icon).classes("text-2xl text-primary")
                                ui.label(app.name).classes("font-semibold")
                            ui.label(app.description).classes(
                                "text-sm text-slate-500 mt-2"
                            )
                            with ui.row().classes("items-center gap-2 mt-3"):
                                ui.label(f"by {app.author}").classes(
                                    "text-xs text-slate-400"
                                )
                                ui.label(f"v{app.version}").classes(
                                    "text-xs text-slate-400"
                                )

    # Run the app (storage_secret enables app.storage.user for persistence)
    ui.run(title="App Launcher", favicon="🚀", storage_secret="app-launcher-secret")


if __name__ in {"__main__", "__mp_main__"}:
    main()
