"""Database Viewer - View data from SQLite tables."""

import sqlite3
from pathlib import Path

from nicegui import ui

APP_INFO = {
    "name": "Database Viewer",
    "icon": "table_chart",
    "description": "View data from SQLite tables",
    "category": "Tools",
    "author": "App Launcher",
    "version": "1.0.0",
}

# Sample data for the dummy database
SAMPLE_EMPLOYEES = [
    ("Alice Johnson", "Engineering", 95000, "2021-03-15"),
    ("Bob Smith", "Marketing", 72000, "2020-07-22"),
    ("Carol Williams", "Engineering", 105000, "2019-01-10"),
    ("David Brown", "Sales", 68000, "2022-05-03"),
    ("Eva Martinez", "HR", 62000, "2021-11-28"),
    ("Frank Lee", "Engineering", 88000, "2020-09-14"),
    ("Grace Kim", "Marketing", 78000, "2019-06-30"),
    ("Henry Chen", "Sales", 71000, "2022-02-18"),
    ("Ivy Patel", "Engineering", 92000, "2021-08-05"),
    ("Jack Wilson", "HR", 58000, "2023-01-09"),
    ("Karen Davis", "Sales", 75000, "2020-04-12"),
    ("Leo Garcia", "Engineering", 110000, "2018-11-20"),
]


def get_db_path() -> Path:
    """Get path to the sample database."""
    data_dir = Path(__file__).parent.parent / "data"
    data_dir.mkdir(exist_ok=True)
    return data_dir / "sample.db"


def init_sample_db() -> None:
    """Initialize the sample database with dummy data."""
    db_path = get_db_path()

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            department TEXT NOT NULL,
            salary REAL NOT NULL,
            hire_date TEXT NOT NULL
        )
    """)

    # Check if data already exists
    cursor.execute("SELECT COUNT(*) FROM employees")
    if cursor.fetchone()[0] == 0:
        # Insert sample data
        cursor.executemany(
            "INSERT INTO employees (name, department, salary, hire_date) VALUES (?, ?, ?, ?)",
            SAMPLE_EMPLOYEES,
        )

    conn.commit()
    conn.close()


def get_employees() -> list[dict]:
    """Fetch all employees from the database."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT id, name, department, salary, hire_date FROM employees ORDER BY id")
    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]


def build_ui() -> None:
    """Build the Database Viewer UI."""
    # Initialize sample database
    init_sample_db()

    ui.label("Database Viewer").classes("text-2xl font-bold mb-4")

    with ui.card().classes("w-full"):
        ui.label("Employees Table").classes("text-lg font-semibold mb-2")
        ui.label("Sample data from data/sample.db").classes(
            "text-sm text-slate-500 dark:text-slate-400 mb-4"
        )

        # Define table columns
        columns = [
            {"name": "id", "label": "ID", "field": "id", "sortable": True, "align": "left"},
            {"name": "name", "label": "Name", "field": "name", "sortable": True, "align": "left"},
            {
                "name": "department",
                "label": "Department",
                "field": "department",
                "sortable": True,
                "align": "left",
            },
            {
                "name": "salary",
                "label": "Salary",
                "field": "salary",
                "sortable": True,
                "align": "right",
                ":format": "value => '$' + value.toLocaleString()",
            },
            {
                "name": "hire_date",
                "label": "Hire Date",
                "field": "hire_date",
                "sortable": True,
                "align": "left",
            },
        ]

        # Get data from database
        rows = get_employees()

        # Create table
        table = ui.table(
            columns=columns,
            rows=rows,
            row_key="id",
            pagination={"rowsPerPage": 10},
        ).classes("w-full")

        # Add search/filter
        with ui.row().classes("w-full items-center gap-4 mt-4"):
            search = ui.input(placeholder="Search...").classes("w-64")
            search.bind_value(table, "filter")

            ui.label(f"Total: {len(rows)} employees").classes(
                "text-sm text-slate-500 dark:text-slate-400"
            )
