"""Calculator - A basic calculator app."""

from nicegui import ui

APP_INFO = {
    "name": "Calculator",
    "icon": "calculate",
    "description": "A simple calculator",
    "category": "Tools",
    "author": "App Launcher",
    "version": "1.0.0",
}


class Calculator:
    """Simple calculator state and logic."""

    def __init__(self):
        self.display = "0"
        self.current = 0.0
        self.operation = None
        self.new_input = True

    def digit(self, d: str) -> None:
        if self.new_input:
            self.display = d
            self.new_input = False
        else:
            self.display = self.display + d if self.display != "0" else d

    def decimal(self) -> None:
        if self.new_input:
            self.display = "0."
            self.new_input = False
        elif "." not in self.display:
            self.display += "."

    def clear(self) -> None:
        self.display = "0"
        self.current = 0.0
        self.operation = None
        self.new_input = True

    def operate(self, op: str) -> None:
        self._calculate()
        self.current = float(self.display)
        self.operation = op
        self.new_input = True

    def equals(self) -> None:
        self._calculate()
        self.operation = None
        self.new_input = True

    def _calculate(self) -> None:
        if self.operation is None:
            return
        value = float(self.display)
        if self.operation == "+":
            self.display = str(self.current + value)
        elif self.operation == "-":
            self.display = str(self.current - value)
        elif self.operation == "*":
            self.display = str(self.current * value)
        elif self.operation == "/":
            self.display = str(self.current / value) if value != 0 else "Error"
        self.current = float(self.display) if self.display != "Error" else 0.0


def build_ui() -> None:
    """Build the calculator UI."""
    calc = Calculator()

    ui.label("Calculator").classes("text-2xl font-bold mb-4")

    with ui.card().classes("w-72"):
        # Display
        display = ui.label(calc.display).classes(
            "text-3xl font-mono text-right w-full p-4 bg-slate-100 rounded"
        )

        def update_display():
            display.text = calc.display

        def make_digit_handler(d: str):
            def handler():
                calc.digit(d)
                update_display()
            return handler

        def make_op_handler(op: str):
            def handler():
                calc.operate(op)
                update_display()
            return handler

        # Button grid
        button_class = "w-14 h-14 text-xl"

        with ui.grid(columns=4).classes("gap-1 mt-4"):
            ui.button("C", on_click=lambda: (calc.clear(), update_display())).classes(
                button_class + " bg-red-500"
            )
            ui.button("(", on_click=lambda: ui.notify("Not implemented")).classes(button_class)
            ui.button(")", on_click=lambda: ui.notify("Not implemented")).classes(button_class)
            ui.button("/", on_click=make_op_handler("/")).classes(button_class + " bg-orange-500")

            for d in "789":
                ui.button(d, on_click=make_digit_handler(d)).classes(button_class)
            ui.button("*", on_click=make_op_handler("*")).classes(button_class + " bg-orange-500")

            for d in "456":
                ui.button(d, on_click=make_digit_handler(d)).classes(button_class)
            ui.button("-", on_click=make_op_handler("-")).classes(button_class + " bg-orange-500")

            for d in "123":
                ui.button(d, on_click=make_digit_handler(d)).classes(button_class)
            ui.button("+", on_click=make_op_handler("+")).classes(button_class + " bg-orange-500")

            ui.button("0", on_click=make_digit_handler("0")).classes(button_class + " col-span-2")
            ui.button(".", on_click=lambda: (calc.decimal(), update_display())).classes(button_class)
            ui.button("=", on_click=lambda: (calc.equals(), update_display())).classes(
                button_class + " bg-green-500"
            )
