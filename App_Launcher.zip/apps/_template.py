"""
App Template - Copy this file to create a new app.

Instructions:
1. Copy this file and rename it (e.g., my_app.py)
2. Update the APP_INFO dictionary with your app's metadata
3. Implement your UI in the build_ui() function
4. Restart the launcher to see your app in the sidebar

Note: Files starting with underscore (_) are ignored by the loader.
"""

from nicegui import ui

# Required: App metadata dictionary
APP_INFO = {
    "name": "My App Name",           # Display name in sidebar
    "icon": "apps",                  # Material icon name (see https://fonts.google.com/icons)
    "description": "Short description of what this app does",
    "category": "Utilities",         # Category for grouping in sidebar
    "author": "Your Name",           # Author name
    "version": "1.0.0",              # Version string (optional)
}


def build_ui() -> None:
    """Required: Build your app's UI here.

    This function is called when the user navigates to your app.
    Use NiceGUI components to create your interface.
    """
    ui.label("Hello from My App!").classes("text-2xl font-bold")

    with ui.card().classes("w-full max-w-md"):
        ui.label("This is a template app. Replace this with your own content.")

        ui.button("Click Me", on_click=lambda: ui.notify("Button clicked!"))
