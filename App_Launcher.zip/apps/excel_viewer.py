"""Excel Viewer - Convert Excel files to Markdown and display them."""

import tempfile
from pathlib import Path

from markitdown import MarkItDown
from nicegui import ui

APP_INFO = {
    "name": "Excel Viewer",
    "icon": "table_view",
    "description": "Convert Excel files to Markdown",
    "category": "Tools",
    "author": "App Launcher",
    "version": "1.0.0",
}


def build_ui() -> None:
    """Build the Excel Viewer UI."""
    ui.label("Excel Viewer").classes("text-2xl font-bold mb-4")

    # State
    markdown_content = {"value": ""}

    with ui.card().classes("w-full max-w-4xl"):
        ui.label("Upload an Excel file to convert it to Markdown").classes(
            "text-slate-600 dark:text-slate-400 mb-4"
        )

        # Markdown display area (refreshable)
        @ui.refreshable
        def show_markdown():
            if markdown_content["value"]:
                with ui.card().classes("w-full bg-slate-50 dark:bg-slate-800 mt-4"):
                    ui.markdown(f"```md\n{markdown_content['value']}\n```").classes("w-full")
            else:
                ui.label("No file uploaded yet").classes(
                    "text-slate-400 dark:text-slate-500 text-center py-8"
                )

        async def handle_upload(e):
            """Handle file upload and convert to markdown."""
            try:
                ui.notify("Processing file...", type="info")

                # e.file is the uploaded file object (Starlette UploadFile)
                uploaded_file = e.file

                # Get filename
                name = uploaded_file.filename if hasattr(uploaded_file, 'filename') else "uploaded.xlsx"
                suffix = Path(name).suffix

                # Read content (async)
                content = await uploaded_file.read()

                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(content)
                    tmp_path = tmp.name

                # Convert to markdown
                md = MarkItDown()
                result = md.convert(tmp_path)
                markdown_content["value"] = result.text_content

                # Clean up temp file
                Path(tmp_path).unlink(missing_ok=True)

                # Refresh display
                show_markdown.refresh()
                ui.notify("File converted successfully!", type="positive")

            except Exception as ex:
                import traceback
                traceback.print_exc()
                ui.notify(f"Error processing file: {ex}", type="negative")

        def clear_content():
            """Clear the current content."""
            markdown_content["value"] = ""
            show_markdown.refresh()

        # Upload area
        with ui.row().classes("w-full gap-4 items-center"):
            ui.upload(
                on_upload=handle_upload,
                auto_upload=True,
                label="Upload Excel File",
            ).props('accept=".xlsx,.xls,.csv"').classes("max-w-md")

            ui.button("Clear", icon="clear", on_click=clear_content).props(
                "flat color=negative"
            )

        ui.separator().classes("my-4")

        # Display area
        show_markdown()
