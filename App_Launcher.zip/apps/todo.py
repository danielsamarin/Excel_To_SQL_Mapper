"""Todo List - A simple task management app with persistence."""

from dataclasses import dataclass
from datetime import datetime

from nicegui import ui

from launcher.db import Database

APP_INFO = {
    "name": "Todo List",
    "icon": "checklist",
    "description": "A simple task management app",
    "category": "Tools",
    "author": "App Launcher",
    "version": "2.0.0",
}

# Category definitions with colors
CATEGORIES = {
    "Personal": "blue",
    "Work": "purple",
    "Shopping": "green",
    "Health": "red",
    "Other": "grey",
}


@dataclass
class TodoItem:
    """Represents a single todo item."""

    id: int
    text: str
    completed: bool = False
    category: str = "Personal"
    created_at: str = ""


class TodoManager:
    """Manages the todo list with SQLite persistence."""

    def __init__(self):
        self._init_db()

    def _init_db(self) -> None:
        """Initialize the database table."""
        Database.execute("""
            CREATE TABLE IF NOT EXISTS todo_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                completed BOOLEAN DEFAULT 0,
                category TEXT DEFAULT 'Personal',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def get_all(self) -> list[TodoItem]:
        """Get all todos from the database."""
        rows = Database.fetchall(
            "SELECT id, text, completed, category, created_at FROM todo_items ORDER BY id DESC"
        )
        return [
            TodoItem(
                id=row["id"],
                text=row["text"],
                completed=bool(row["completed"]),
                category=row["category"],
                created_at=row["created_at"],
            )
            for row in rows
        ]

    def add(self, text: str, category: str = "Personal") -> TodoItem | None:
        """Add a new todo item."""
        if not text.strip():
            return None
        cursor = Database.execute(
            "INSERT INTO todo_items (text, category) VALUES (?, ?)",
            (text.strip(), category),
        )
        return TodoItem(
            id=cursor.lastrowid,
            text=text.strip(),
            completed=False,
            category=category,
        )

    def toggle(self, todo_id: int) -> None:
        """Toggle the completed status of a todo."""
        Database.execute(
            "UPDATE todo_items SET completed = NOT completed WHERE id = ?",
            (todo_id,),
        )

    def update_text(self, todo_id: int, new_text: str) -> None:
        """Update the text of a todo."""
        Database.execute(
            "UPDATE todo_items SET text = ? WHERE id = ?",
            (new_text.strip(), todo_id),
        )

    def update_category(self, todo_id: int, category: str) -> None:
        """Update the category of a todo."""
        Database.execute(
            "UPDATE todo_items SET category = ? WHERE id = ?",
            (category, todo_id),
        )

    def delete(self, todo_id: int) -> None:
        """Delete a todo item."""
        Database.execute("DELETE FROM todo_items WHERE id = ?", (todo_id,))

    @property
    def pending_count(self) -> int:
        """Count of incomplete todos."""
        row = Database.fetchone("SELECT COUNT(*) as count FROM todo_items WHERE completed = 0")
        return row["count"] if row else 0

    @property
    def completed_count(self) -> int:
        """Count of completed todos."""
        row = Database.fetchone("SELECT COUNT(*) as count FROM todo_items WHERE completed = 1")
        return row["count"] if row else 0


def build_ui() -> None:
    """Build the Todo List UI."""
    manager = TodoManager()

    ui.label("Todo List").classes("text-2xl font-bold mb-4")

    with ui.card().classes("w-full max-w-lg"):
        # Input section
        with ui.row().classes("w-full gap-2 items-end"):
            input_field = ui.input(placeholder="Add a new task...").classes("flex-grow")
            category_select = ui.select(
                list(CATEGORIES.keys()),
                value="Personal",
                label="Category",
            ).classes("w-32")

            def add_todo():
                text = input_field.value
                if manager.add(text, category_select.value):
                    input_field.value = ""
                    render_todos.refresh()
                    update_counts()
                else:
                    ui.notify("Please enter a task", type="warning")

            input_field.on("keydown.enter", add_todo)
            ui.button("Add", icon="add", on_click=add_todo).props("color=primary")

        ui.separator().classes("my-3")

        # Status counts
        counts_label = ui.label().classes("text-sm text-slate-500 dark:text-slate-400 mb-2")

        def update_counts():
            pending = manager.pending_count
            completed = manager.completed_count
            if pending == 0 and completed == 0:
                counts_label.text = ""
            else:
                counts_label.text = f"{pending} pending, {completed} completed"

        update_counts()

        # Todo list container
        with ui.column().classes("w-full gap-1"):

            @ui.refreshable
            def render_todos():
                todos = manager.get_all()
                if not todos:
                    ui.label("No tasks yet. Add one above!").classes(
                        "text-slate-400 dark:text-slate-500 text-center py-4"
                    )
                    return

                for todo in todos:
                    render_todo_item(todo)

            def render_todo_item(todo: TodoItem):
                """Render a single todo item."""
                with ui.row().classes(
                    "w-full items-center gap-2 py-2 px-2 rounded hover:bg-slate-100 dark:hover:bg-slate-700"
                ):
                    # Checkbox
                    def on_toggle(e, t=todo):
                        manager.toggle(t.id)
                        render_todos.refresh()
                        update_counts()

                    ui.checkbox(value=todo.completed, on_change=on_toggle)

                    # Text (click to edit)
                    text_classes = "flex-grow cursor-pointer"
                    if todo.completed:
                        text_classes += " line-through text-slate-400 dark:text-slate-500"
                    else:
                        text_classes += " text-slate-700 dark:text-slate-200"

                    text_label = ui.label(todo.text).classes(text_classes)

                    # Category chip
                    color = CATEGORIES.get(todo.category, "grey")
                    ui.badge(todo.category, color=color).classes("text-xs")

                    # Edit button
                    def on_edit(t=todo):
                        show_edit_dialog(t)

                    ui.button(icon="edit", on_click=on_edit).props(
                        "flat color=primary dense size=sm"
                    )

                    # Delete button
                    def on_delete(t=todo):
                        manager.delete(t.id)
                        render_todos.refresh()
                        update_counts()

                    ui.button(icon="delete", on_click=on_delete).props(
                        "flat color=negative dense size=sm"
                    )

            def show_edit_dialog(todo: TodoItem):
                """Show dialog to edit a todo item."""
                with ui.dialog() as dialog, ui.card().classes("w-80"):
                    ui.label("Edit Task").classes("text-lg font-bold mb-2")

                    edit_input = ui.input(value=todo.text, label="Task").classes("w-full")
                    edit_category = ui.select(
                        list(CATEGORIES.keys()),
                        value=todo.category,
                        label="Category",
                    ).classes("w-full")

                    with ui.row().classes("w-full justify-end gap-2 mt-4"):
                        ui.button("Cancel", on_click=dialog.close).props("flat")

                        def save_changes():
                            if edit_input.value.strip():
                                manager.update_text(todo.id, edit_input.value)
                                manager.update_category(todo.id, edit_category.value)
                                dialog.close()
                                render_todos.refresh()
                            else:
                                ui.notify("Task text cannot be empty", type="warning")

                        ui.button("Save", on_click=save_changes).props("color=primary")

                dialog.open()

            render_todos()
