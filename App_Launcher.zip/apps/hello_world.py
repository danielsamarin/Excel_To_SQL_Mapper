"""Hello World - A simple example app."""

from nicegui import ui

APP_INFO = {
    "name": "Hello World",
    "icon": "waving_hand",
    "description": "A simple greeting app",
    "category": "Examples",
    "author": "App Launcher",
    "version": "1.0.0",
}


def build_ui() -> None:
    """Build the Hello World UI."""
    ui.label("Hello, World!").classes("text-4xl font-bold text-primary")

    ui.separator().classes("my-4")

    with ui.card().classes("w-full max-w-md"):
        ui.label("Welcome to the App Launcher!").classes("text-lg")
        ui.label(
            "This is a simple example app. You can create your own apps "
            "by adding Python files to the 'apps' folder."
        ).classes("text-slate-600")

    with ui.row().classes("mt-4 gap-2"):
        ui.button("Say Hello", icon="celebration", on_click=lambda: ui.notify("Hello! 👋"))
        ui.button(
            "Learn More",
            icon="school",
            on_click=lambda: ui.notify("Check out the _template.py file to get started!"),
        ).props("outline")
