"""
Locked-Template-App - Main NiceGUI Application
A desktop application for exporting SQL data to Excel templates.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

from nicegui import ui, app, events

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.database import init_database, preview_data, get_total_rows_for_report
from src.validation import validate_report_id, validate_template_path, validate_output_path, validate_all_inputs
from src.excel_export import export_to_excel

# Directory for uploaded templates
UPLOAD_DIR = Path(__file__).parent.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# Initialize database on startup
init_database()


class LockedTemplateApp:
    """Main application class for Locked-Template-App."""

    def __init__(self):
        self.report_id = ""
        self.template_path = ""
        self.output_path = ""
        self.is_exporting = False

        # UI Elements (will be set during build)
        self.report_id_input = None
        self.template_path_input = None
        self.output_path_input = None
        self.generate_button = None
        self.progress_bar = None
        self.row_counter = None
        self.message_area = None
        self.preview_table = None
        self.template_upload = None
        self.template_dialog = None
        self.output_dialog = None

    def build_ui(self):
        """Build the main application UI."""
        with ui.column().classes("w-full max-w-3xl mx-auto p-6"):
            # Header
            ui.label("Locked-Template-App").classes("text-3xl font-bold text-blue-600 mb-2")
            ui.label("Export SQL data to Excel templates").classes("text-gray-600 mb-6")

            # Input Form Section
            with ui.card().classes("w-full mb-4"):
                ui.label("Export Configuration").classes("text-xl font-semibold mb-4")

                # Report ID Input
                ui.label("Report ID").classes("font-medium")
                self.report_id_input = ui.input(
                    placeholder="Enter Report ID (e.g., REPORT001)"
                ).classes("w-full mb-4").on("blur", self.on_report_id_change)

                # Template Path Input
                ui.label("Template Path").classes("font-medium")
                ui.label("Enter path or upload an Excel file (.xlsx, .xlsm)").classes("text-xs text-gray-500 mb-1")
                with ui.row().classes("w-full items-center gap-2 mb-4"):
                    self.template_path_input = ui.input(
                        placeholder="Enter template path or upload file..."
                    ).classes("flex-grow")
                    ui.button("Browse...", on_click=self.show_template_dialog).classes("bg-blue-500")

                # Create template file dialog
                with ui.dialog() as self.template_dialog:
                    with ui.card().classes("w-96"):
                        ui.label("Select Template File").classes("text-lg font-semibold mb-4")
                        ui.label("Upload an Excel template file:").classes("text-sm text-gray-600 mb-2")
                        self.template_upload = ui.upload(
                            label="Drop Excel file here or click to upload",
                            on_upload=self.handle_template_upload,
                            auto_upload=True,
                            max_files=1
                        ).props('accept=".xlsx,.xlsm,.xltx,.xltm"').classes("w-full mb-4")
                        ui.label("Or enter a file path directly in the input field.").classes("text-xs text-gray-500 mb-4")
                        ui.button("Close", on_click=self.template_dialog.close).classes("w-full")

                # Output Path Input
                ui.label("Output Folder").classes("font-medium")
                ui.label("Enter the folder path where exported file will be saved").classes("text-xs text-gray-500 mb-1")
                with ui.row().classes("w-full items-center gap-2"):
                    self.output_path_input = ui.input(
                        placeholder="Enter output folder path..."
                    ).classes("flex-grow")
                    ui.button("Browse...", on_click=self.show_output_dialog).classes("bg-blue-500")

                # Create output folder dialog
                with ui.dialog() as self.output_dialog:
                    with ui.card().classes("w-96"):
                        ui.label("Select Output Folder").classes("text-lg font-semibold mb-4")
                        ui.label("Enter the full path to your output folder:").classes("text-sm text-gray-600 mb-2")
                        self.output_dialog_input = ui.input(
                            placeholder="e.g., C:\\Users\\YourName\\Documents\\Output"
                        ).classes("w-full mb-4")
                        with ui.row().classes("w-full gap-2"):
                            ui.button("Cancel", on_click=self.output_dialog.close).classes("flex-grow")
                            ui.button("Select", on_click=self.confirm_output_path).classes("flex-grow bg-blue-500")

            # Preview Section
            with ui.card().classes("w-full mb-4"):
                ui.label("Data Preview").classes("text-xl font-semibold mb-4")
                self.preview_table = ui.table(
                    columns=[
                        {"name": "sheet_name", "label": "Sheet", "field": "sheet_name"},
                        {"name": "row", "label": "Row", "field": "row_number"},
                        {"name": "col", "label": "Col", "field": "column_number"},
                        {"name": "value", "label": "Value", "field": "cell_value"},
                    ],
                    rows=[],
                    row_key="id"
                ).classes("w-full")
                self.preview_message = ui.label("Enter a Report ID to preview data").classes("text-gray-500 italic")

            # Action Section
            with ui.card().classes("w-full mb-4"):
                self.generate_button = ui.button(
                    "Generate Export",
                    on_click=self.on_generate_click
                ).classes("w-full bg-green-600 text-white text-lg py-3")

            # Progress Section
            with ui.card().classes("w-full mb-4"):
                ui.label("Progress").classes("text-xl font-semibold mb-4")
                self.progress_bar = ui.linear_progress(value=0, show_value=False).classes("w-full mb-2")
                self.row_counter = ui.label("Rows inserted: 0").classes("text-gray-600")

            # Message Section
            with ui.card().classes("w-full"):
                ui.label("Status").classes("text-xl font-semibold mb-4")
                self.message_area = ui.label("Ready to export").classes("text-gray-600")

    def show_template_dialog(self):
        """Show the template file selection dialog."""
        self.template_dialog.open()

    def show_output_dialog(self):
        """Show the output folder selection dialog."""
        # Pre-fill with current value if exists
        if self.output_path_input.value:
            self.output_dialog_input.value = self.output_path_input.value
        self.output_dialog.open()

    def confirm_output_path(self):
        """Confirm the output path selection."""
        path = self.output_dialog_input.value.strip()
        if path:
            self.output_path_input.value = path
            self.output_path = path
        self.output_dialog.close()

    def handle_template_upload(self, e: events.UploadEventArguments):
        """Handle template file upload."""
        try:
            # Save uploaded file to uploads directory
            file_path = UPLOAD_DIR / e.name
            with open(file_path, 'wb') as f:
                f.write(e.content.read())

            # Update the input field with the uploaded file path
            self.template_path_input.value = str(file_path)
            self.template_path = str(file_path)

            # Show success message
            ui.notify(f"Template uploaded: {e.name}", type="positive")

            # Close dialog
            self.template_dialog.close()
        except Exception as ex:
            ui.notify(f"Upload failed: {str(ex)}", type="negative")

    def on_report_id_change(self):
        """Handle Report ID input change - update preview."""
        self.report_id = self.report_id_input.value.strip()

        if not self.report_id:
            self.preview_table.rows = []
            self.preview_message.text = "Enter a Report ID to preview data"
            self.preview_message.classes(remove="text-red-500", add="text-gray-500")
            return

        # Check if report ID exists and get preview
        is_valid, error = validate_report_id(self.report_id)
        if not is_valid:
            self.preview_table.rows = []
            self.preview_message.text = error
            self.preview_message.classes(remove="text-gray-500", add="text-red-500")
            return

        # Get preview data
        preview_rows = preview_data(self.report_id, limit=5)
        if preview_rows:
            self.preview_table.rows = [
                {
                    "id": row.id,
                    "sheet_name": row.sheet_name,
                    "row_number": row.row_number,
                    "column_number": row.column_number,
                    "cell_value": row.cell_value
                }
                for row in preview_rows
            ]
            total = get_total_rows_for_report(self.report_id)
            self.preview_message.text = f"Showing 5 of {total} rows"
            self.preview_message.classes(remove="text-red-500", add="text-gray-500")
        else:
            self.preview_table.rows = []
            self.preview_message.text = "No data found for this Report ID"
            self.preview_message.classes(remove="text-gray-500", add="text-red-500")

    async def on_generate_click(self):
        """Handle Generate button click."""
        if self.is_exporting:
            return

        # Get current values from inputs
        self.report_id = self.report_id_input.value.strip()
        self.template_path = self.template_path_input.value.strip()
        self.output_path = self.output_path_input.value.strip()

        # Validate all inputs
        is_valid, error = validate_all_inputs(
            self.report_id,
            self.template_path,
            self.output_path
        )

        if not is_valid:
            self.show_error(error)
            return

        # Start export
        self.is_exporting = True
        self.generate_button.disable()
        self.progress_bar.value = 0
        self.row_counter.text = "Rows inserted: 0"
        self.show_message("Exporting...", "text-blue-600")

        try:
            # Run export
            result = export_to_excel(
                self.report_id,
                self.template_path,
                self.output_path,
                progress_callback=self.update_progress
            )

            if result.success:
                self.progress_bar.value = 1.0
                self.row_counter.text = f"Rows inserted: {result.rows_written}"
                self.show_success(result.message)

                # Auto-open output folder
                if result.output_file:
                    self.open_folder(result.output_file.parent)
            else:
                self.show_error(result.message)

        except Exception as e:
            self.show_error(f"Export failed: {str(e)}")

        finally:
            self.is_exporting = False
            self.generate_button.enable()

    def update_progress(self, current: int, total: int):
        """Update progress bar and row counter during export."""
        if total > 0:
            self.progress_bar.value = current / total
        self.row_counter.text = f"Rows inserted: {current}"

    def show_message(self, message: str, color_class: str = "text-gray-600"):
        """Display a message in the message area."""
        self.message_area.text = message
        self.message_area.classes(remove="text-gray-600 text-green-600 text-red-500 text-blue-600")
        self.message_area.classes(add=color_class)

    def show_success(self, message: str):
        """Display a success message."""
        self.show_message(message, "text-green-600")

    def show_error(self, message: str):
        """Display an error message."""
        self.show_message(message, "text-red-500")

    def open_folder(self, folder_path: Path):
        """Open folder in system file explorer."""
        try:
            if sys.platform == "win32":
                os.startfile(str(folder_path))
            elif sys.platform == "darwin":
                subprocess.run(["open", str(folder_path)])
            else:
                subprocess.run(["xdg-open", str(folder_path)])
        except Exception as e:
            print(f"Could not open folder: {e}")


# Create and run the application
app_instance = LockedTemplateApp()


@ui.page("/")
def main_page():
    """Main page route."""
    app_instance.build_ui()


if __name__ in {"__main__", "__mp_main__"}:
    ui.run(
        title="Locked-Template-App",
        port=8080,
        reload=False,
        show=True
    )
