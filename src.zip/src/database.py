"""
Database operations for Locked-Template-App.
Handles connections to SQLite and queries for Data and Worksheet_Config tables.
"""

import sqlite3
from typing import List, Optional
from dataclasses import dataclass
from pathlib import Path

# Default database path
DB_PATH = Path(__file__).parent.parent / "app_data.db"


@dataclass
class DataRow:
    """Represents a row from the Data table."""
    id: int
    report_id: str
    sheet_name: str
    row_number: int
    column_number: int
    cell_value: str


@dataclass
class WorksheetConfig:
    """Represents a row from the Worksheet_Config table."""
    id: int
    report_id: str
    sheet_name: str
    description: str


def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    """Create and return a database connection."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def init_database(db_path: Path = DB_PATH) -> None:
    """Initialize the database with required tables and sample data."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    # Create Data table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id VARCHAR(100) NOT NULL,
            sheet_name VARCHAR(100) NOT NULL,
            row_number INTEGER NOT NULL,
            column_number INTEGER NOT NULL,
            cell_value VARCHAR(500)
        )
    """)

    # Create Worksheet_Config table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Worksheet_Config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id VARCHAR(100) NOT NULL,
            sheet_name VARCHAR(100) NOT NULL,
            description VARCHAR(500)
        )
    """)

    # Check if sample data exists
    cursor.execute("SELECT COUNT(*) FROM Data")
    if cursor.fetchone()[0] == 0:
        # Insert sample data for testing
        sample_data = [
            ("REPORT001", "Sheet1", 2, 1, "Product A"),
            ("REPORT001", "Sheet1", 2, 2, "100"),
            ("REPORT001", "Sheet1", 2, 3, "$50.00"),
            ("REPORT001", "Sheet1", 3, 1, "Product B"),
            ("REPORT001", "Sheet1", 3, 2, "200"),
            ("REPORT001", "Sheet1", 3, 3, "$75.00"),
            ("REPORT001", "Sheet1", 4, 1, "Product C"),
            ("REPORT001", "Sheet1", 4, 2, "150"),
            ("REPORT001", "Sheet1", 4, 3, "$45.00"),
            ("REPORT001", "Summary", 2, 1, "Total Units"),
            ("REPORT001", "Summary", 2, 2, "450"),
            ("REPORT002", "Data", 2, 1, "January"),
            ("REPORT002", "Data", 2, 2, "5000"),
            ("REPORT002", "Data", 3, 1, "February"),
            ("REPORT002", "Data", 3, 2, "6500"),
        ]
        cursor.executemany(
            "INSERT INTO Data (report_id, sheet_name, row_number, column_number, cell_value) VALUES (?, ?, ?, ?, ?)",
            sample_data
        )

        # Insert sample config
        sample_config = [
            ("REPORT001", "Sheet1", "Main product data"),
            ("REPORT001", "Summary", "Summary totals"),
            ("REPORT002", "Data", "Monthly sales data"),
        ]
        cursor.executemany(
            "INSERT INTO Worksheet_Config (report_id, sheet_name, description) VALUES (?, ?, ?)",
            sample_config
        )

    conn.commit()
    conn.close()


def get_data_by_report_id(report_id: str, db_path: Path = DB_PATH) -> List[DataRow]:
    """Query Data table by Report ID and return list of DataRow objects."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, report_id, sheet_name, row_number, column_number, cell_value FROM Data WHERE report_id = ?",
        (report_id,)
    )

    rows = [
        DataRow(
            id=row["id"],
            report_id=row["report_id"],
            sheet_name=row["sheet_name"],
            row_number=row["row_number"],
            column_number=row["column_number"],
            cell_value=row["cell_value"]
        )
        for row in cursor.fetchall()
    ]

    conn.close()
    return rows


def get_config_by_report_id(report_id: str, db_path: Path = DB_PATH) -> List[WorksheetConfig]:
    """Query Worksheet_Config table by Report ID and return list of WorksheetConfig objects."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, report_id, sheet_name, description FROM Worksheet_Config WHERE report_id = ?",
        (report_id,)
    )

    configs = [
        WorksheetConfig(
            id=row["id"],
            report_id=row["report_id"],
            sheet_name=row["sheet_name"],
            description=row["description"]
        )
        for row in cursor.fetchall()
    ]

    conn.close()
    return configs


def preview_data(report_id: str, limit: int = 5, db_path: Path = DB_PATH) -> List[DataRow]:
    """Fetch top N rows for preview when Report ID is entered."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, report_id, sheet_name, row_number, column_number, cell_value FROM Data WHERE report_id = ? LIMIT ?",
        (report_id, limit)
    )

    rows = [
        DataRow(
            id=row["id"],
            report_id=row["report_id"],
            sheet_name=row["sheet_name"],
            row_number=row["row_number"],
            column_number=row["column_number"],
            cell_value=row["cell_value"]
        )
        for row in cursor.fetchall()
    ]

    conn.close()
    return rows


def validate_report_id(report_id: str, db_path: Path = DB_PATH) -> bool:
    """Check if a Report ID exists in the database."""
    if not report_id or not report_id.strip():
        return False

    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT COUNT(*) FROM Data WHERE report_id = ?",
        (report_id,)
    )

    count = cursor.fetchone()[0]
    conn.close()

    return count > 0


def get_total_rows_for_report(report_id: str, db_path: Path = DB_PATH) -> int:
    """Get the total number of rows for a given Report ID."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT COUNT(*) FROM Data WHERE report_id = ?",
        (report_id,)
    )

    count = cursor.fetchone()[0]
    conn.close()

    return count
