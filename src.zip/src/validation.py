"""
Input validation functions for Locked-Template-App.
"""

from pathlib import Path
from typing import Tuple

from .database import validate_report_id as db_validate_report_id


def validate_report_id(report_id: str) -> Tuple[bool, str]:
    """
    Validate that Report ID is not empty and exists in database.

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not report_id:
        return False, "Report ID cannot be empty"

    if not report_id.strip():
        return False, "Report ID cannot be only whitespace"

    if not db_validate_report_id(report_id.strip()):
        return False, f"Report ID '{report_id}' not found in database"

    return True, ""


def validate_template_path(path: str) -> Tuple[bool, str]:
    """
    Validate that Template Path points to an existing Excel file.

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not path:
        return False, "Template path cannot be empty"

    if not path.strip():
        return False, "Template path cannot be only whitespace"

    template_path = Path(path.strip())

    if not template_path.exists():
        return False, f"Template file not found: {path}"

    if not template_path.is_file():
        return False, f"Template path is not a file: {path}"

    # Check for Excel file extensions
    valid_extensions = {'.xlsx', '.xlsm', '.xltx', '.xltm'}
    if template_path.suffix.lower() not in valid_extensions:
        return False, f"Template must be an Excel file (.xlsx, .xlsm, .xltx, .xltm)"

    return True, ""


def validate_output_path(path: str) -> Tuple[bool, str]:
    """
    Validate that Output Path points to an existing folder.

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not path:
        return False, "Output path cannot be empty"

    if not path.strip():
        return False, "Output path cannot be only whitespace"

    output_path = Path(path.strip())

    if not output_path.exists():
        return False, f"Output folder not found: {path}"

    if not output_path.is_dir():
        return False, f"Output path is not a folder: {path}"

    return True, ""


def validate_all_inputs(report_id: str, template_path: str, output_path: str) -> Tuple[bool, str]:
    """
    Validate all inputs at once.

    Returns:
        Tuple of (all_valid, first_error_message)
    """
    # Validate Report ID
    is_valid, error = validate_report_id(report_id)
    if not is_valid:
        return False, error

    # Validate Template Path
    is_valid, error = validate_template_path(template_path)
    if not is_valid:
        return False, error

    # Validate Output Path
    is_valid, error = validate_output_path(output_path)
    if not is_valid:
        return False, error

    return True, ""
