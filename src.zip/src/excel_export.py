"""
Excel export functionality for Locked-Template-App.
Handles copying templates and writing data to cells.
"""

import shutil
from pathlib import Path
from typing import List, Callable, Optional
from dataclasses import dataclass
from datetime import datetime

from openpyxl import load_workbook
from openpyxl.workbook import Workbook

from .database import DataRow, get_data_by_report_id


@dataclass
class ExportResult:
    """Result of an export operation."""
    success: bool
    message: str
    output_file: Optional[Path] = None
    rows_written: int = 0


def generate_output_filename(template_path: Path, report_id: str) -> str:
    """Generate output filename based on template name and report ID."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = template_path.stem
    suffix = template_path.suffix
    return f"{stem}_{report_id}_{timestamp}{suffix}"


def copy_template_to_output(template_path: Path, output_folder: Path, report_id: str) -> Path:
    """Copy template file to output location with new name."""
    output_filename = generate_output_filename(template_path, report_id)
    output_file = output_folder / output_filename
    shutil.copy2(template_path, output_file)
    return output_file


def write_data_to_workbook(
    workbook: Workbook,
    data_rows: List[DataRow],
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> int:
    """
    Write data rows to the workbook based on sheet_name, row_number, column_number.

    Args:
        workbook: The openpyxl Workbook object
        data_rows: List of DataRow objects containing the data to write
        progress_callback: Optional callback function(current, total) for progress updates

    Returns:
        Number of rows successfully written
    """
    rows_written = 0
    total_rows = len(data_rows)

    for i, data_row in enumerate(data_rows):
        try:
            # Get or create the worksheet
            if data_row.sheet_name in workbook.sheetnames:
                worksheet = workbook[data_row.sheet_name]
            else:
                # Create worksheet if it doesn't exist
                worksheet = workbook.create_sheet(data_row.sheet_name)

            # Write the cell value
            worksheet.cell(
                row=data_row.row_number,
                column=data_row.column_number,
                value=data_row.cell_value
            )
            rows_written += 1

            # Call progress callback if provided
            if progress_callback:
                progress_callback(i + 1, total_rows)

        except Exception as e:
            # Log error but continue with other rows
            print(f"Error writing row {data_row.id}: {e}")

    return rows_written


def export_to_excel(
    report_id: str,
    template_path: str,
    output_path: str,
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> ExportResult:
    """
    Main export function that copies template and writes data.

    Args:
        report_id: The report ID to export data for
        template_path: Path to the Excel template file
        output_path: Path to the output folder
        progress_callback: Optional callback function(current, total) for progress updates

    Returns:
        ExportResult with success status, message, and details
    """
    template = Path(template_path)
    output_folder = Path(output_path)

    # Get data from database
    data_rows = get_data_by_report_id(report_id)

    if not data_rows:
        return ExportResult(
            success=False,
            message=f"No data found for Report ID: {report_id}",
            rows_written=0
        )

    output_file = None
    workbook = None

    try:
        # Copy template to output location
        output_file = copy_template_to_output(template, output_folder, report_id)

        # Open the workbook
        workbook = load_workbook(str(output_file))

        # Write data to workbook
        rows_written = write_data_to_workbook(workbook, data_rows, progress_callback)

        # Save the workbook
        workbook.save(str(output_file))

        return ExportResult(
            success=True,
            message=f"Successfully exported {rows_written} rows to {output_file.name}",
            output_file=output_file,
            rows_written=rows_written
        )

    except PermissionError:
        return ExportResult(
            success=False,
            message="Permission denied. The template file may be locked or in use by another application.",
            rows_written=0
        )

    except FileNotFoundError as e:
        return ExportResult(
            success=False,
            message=f"File not found: {e}",
            rows_written=0
        )

    except Exception as e:
        return ExportResult(
            success=False,
            message=f"Export failed: {str(e)}",
            rows_written=0
        )

    finally:
        # Ensure workbook is closed
        if workbook:
            try:
                workbook.close()
            except Exception:
                pass
