from pathlib import Path
import yaml
from launcher.core import AppInfo


def test_app_info_creation():
    app = AppInfo(
        id="test-app",
        name="Test App",
        path=Path("/fake/path"),
        icon="apps",
        description="A test app",
    )
    assert app.id == "test-app"
    assert app.name == "Test App"
    assert app.icon == "apps"
    assert app.path == Path("/fake/path")
    assert app.description == "A test app"


def test_discover_apps_finds_app_with_manifest(tmp_path):
    # Create a test app with manifest
    app_dir = tmp_path / "my-app"
    app_dir.mkdir()

    manifest = {
        "id": "my-app",
        "name": "My App",
        "description": "Test application",
        "icon": "home",
        "version": "1.0.0",
    }
    (app_dir / "manifest.yaml").write_text(yaml.dump(manifest))
    (app_dir / "app.py").write_text("def render(container): pass")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 1
    assert apps[0].id == "my-app"
    assert apps[0].name == "My App"


def test_discover_apps_ignores_folders_without_manifest(tmp_path):
    # Create folder without manifest
    (tmp_path / "not-an-app").mkdir()

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 0


def test_discover_apps_returns_sorted_by_name(tmp_path):
    for app_id, name in [("z-app", "Zebra"), ("a-app", "Apple")]:
        app_dir = tmp_path / app_id
        app_dir.mkdir()
        manifest = {"id": app_id, "name": name, "description": "", "icon": "apps", "version": "1.0.0"}
        (app_dir / "manifest.yaml").write_text(yaml.dump(manifest))
        (app_dir / "app.py").write_text("def render(container): pass")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert apps[0].name == "Apple"
    assert apps[1].name == "Zebra"


def test_discover_apps_handles_malformed_yaml(tmp_path):
    app_dir = tmp_path / "bad-app"
    app_dir.mkdir()
    (app_dir / "manifest.yaml").write_text("invalid: yaml: content: [")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 0


def test_discover_apps_handles_missing_required_fields(tmp_path):
    app_dir = tmp_path / "incomplete-app"
    app_dir.mkdir()
    # Missing 'id' field
    (app_dir / "manifest.yaml").write_text("name: Incomplete App\n")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 0


def test_discover_apps_handles_nonexistent_directory(tmp_path):
    nonexistent = tmp_path / "does-not-exist"

    from launcher.core import discover_apps

    apps = discover_apps(nonexistent)

    assert len(apps) == 0


def test_load_app_module_returns_module_with_render(tmp_path):
    app_dir = tmp_path / "test-app"
    app_dir.mkdir()

    app_code = '''
def render(container):
    container.test_value = "rendered"
'''
    (app_dir / "app.py").write_text(app_code)

    from launcher.core import load_app_module, AppInfo

    app_info = AppInfo(
        id="test-app",
        name="Test",
        path=app_dir,
        icon="apps",
        description="",
    )

    module = load_app_module(app_info)

    assert hasattr(module, "render")
    assert callable(module.render)


def test_load_app_module_raises_on_missing_file(tmp_path):
    from launcher.core import load_app_module, AppInfo, AppLoadError

    app_info = AppInfo(
        id="missing",
        name="Missing",
        path=tmp_path / "nonexistent",
        icon="apps",
        description="",
    )

    import pytest
    with pytest.raises(AppLoadError):
        load_app_module(app_info)


def test_load_app_module_raises_on_syntax_error(tmp_path):
    app_dir = tmp_path / "bad-syntax"
    app_dir.mkdir()
    (app_dir / "app.py").write_text("def render(container:\n")  # Invalid syntax

    from launcher.core import load_app_module, AppInfo, AppLoadError

    app_info = AppInfo(
        id="bad-syntax",
        name="Bad Syntax",
        path=app_dir,
        icon="apps",
        description="",
    )

    import pytest
    with pytest.raises(AppLoadError):
        load_app_module(app_info)


def test_load_app_module_reloads_fresh_module(tmp_path):
    app_dir = tmp_path / "reload-test"
    app_dir.mkdir()
    (app_dir / "app.py").write_text("VALUE = 1\ndef render(c): pass")

    from launcher.core import load_app_module, AppInfo

    app_info = AppInfo(
        id="reload-test",
        name="Reload Test",
        path=app_dir,
        icon="apps",
        description="",
    )

    module1 = load_app_module(app_info)
    assert module1.VALUE == 1

    # Modify the file
    (app_dir / "app.py").write_text("VALUE = 2\ndef render(c): pass")

    module2 = load_app_module(app_info)
    assert module2.VALUE == 2  # Should have reloaded with new value
