def test_theme_has_colors():
    from launcher.theme import COLORS

    assert "primary" in COLORS
    assert "secondary" in COLORS
    assert "background" in COLORS
    assert "surface" in COLORS
    assert "text" in COLORS


def test_theme_has_sidebar_width():
    from launcher.theme import SIDEBAR_WIDTH

    assert isinstance(SIDEBAR_WIDTH, int)
    assert SIDEBAR_WIDTH > 0
