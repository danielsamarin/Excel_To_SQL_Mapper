from dataclasses import dataclass
from pathlib import Path
import importlib.util
import linecache
import sys

import yaml


class AppLoadError(Exception):
    """Raised when an app fails to load."""
    pass


@dataclass
class AppInfo:
    id: str
    name: str
    path: Path
    icon: str
    description: str


def discover_apps(apps_dir: Path) -> list[AppInfo]:
    """Scan directory for apps with manifest.yaml files."""
    apps = []

    if not apps_dir.exists():
        return apps

    for folder in apps_dir.iterdir():
        if not folder.is_dir():
            continue

        manifest_path = folder / "manifest.yaml"
        if not manifest_path.exists():
            continue

        try:
            manifest = yaml.safe_load(manifest_path.read_text())
            apps.append(AppInfo(
                id=manifest["id"],
                name=manifest["name"],
                path=folder,
                icon=manifest.get("icon", "apps"),
                description=manifest.get("description", ""),
            ))
        except (yaml.YAMLError, KeyError):
            continue

    return sorted(apps, key=lambda a: a.name)


def load_app_module(app_info: AppInfo):
    """Dynamically import an app's module."""
    app_file = app_info.path / "app.py"

    if not app_file.exists():
        raise AppLoadError(f"App file not found: {app_file}")

    module_name = f"apps.{app_info.id}"

    # Remove from cache if previously loaded
    if module_name in sys.modules:
        del sys.modules[module_name]

    # Clear linecache to ensure fresh source is read on reload
    linecache.checkcache(str(app_file))

    # Remove cached bytecode to ensure fresh module on reload
    cached_file = importlib.util.cache_from_source(str(app_file))
    if Path(cached_file).exists():
        Path(cached_file).unlink()

    try:
        spec = importlib.util.spec_from_file_location(module_name, app_file)
        if spec is None or spec.loader is None:
            raise AppLoadError(f"Could not load spec for: {app_file}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return module
    except AppLoadError:
        # Clean up on failure
        if module_name in sys.modules:
            del sys.modules[module_name]
        raise
    except Exception as e:
        # Clean up on failure
        if module_name in sys.modules:
            del sys.modules[module_name]
        raise AppLoadError(f"Failed to load app {app_info.id}: {e}") from e
