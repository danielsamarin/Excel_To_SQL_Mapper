"""Main launcher UI with sidebar navigation."""

from pathlib import Path
from nicegui import ui

from launcher.core import AppInfo, discover_apps, load_app_module, AppLoadError
from launcher.theme import COLORS, SIDEBAR_WIDTH


class LauncherUI:
    def __init__(self, apps_dir: Path):
        self.apps_dir = apps_dir
        self.apps: list[AppInfo] = []
        self.current_app: AppInfo | None = None
        self.content_container = None

    def setup(self):
        """Initialize the UI layout."""
        self.apps = discover_apps(self.apps_dir)

        # Apply dark theme
        ui.dark_mode().enable()

        # Main layout
        with ui.row().classes("w-full h-screen no-wrap"):
            self._build_sidebar()
            self._build_content_area()

    def _build_sidebar(self):
        """Build the sidebar with app list."""
        with ui.column().classes("h-full").style(
            f"width: {SIDEBAR_WIDTH}px; "
            f"background-color: {COLORS['surface']}; "
            "padding: 16px; "
            "border-right: 1px solid #333;"
        ):
            # Header
            ui.label("App Launcher").classes("text-xl font-bold mb-4").style(
                f"color: {COLORS['text']}"
            )

            # App list
            for app in self.apps:
                self._build_app_button(app)

            # Empty state
            if not self.apps:
                ui.label("No apps found").classes("text-gray-500 italic")
                ui.label("Add apps to the 'apps' folder").classes("text-gray-600 text-sm")

    def _build_app_button(self, app: AppInfo):
        """Build a sidebar button for an app."""
        with ui.button(on_click=lambda a=app: self._select_app(a)).props(
            "flat align=left"
        ).classes("w-full justify-start").style(
            f"color: {COLORS['text']};"
        ):
            ui.icon(app.icon).classes("mr-2")
            ui.label(app.name)

    def _build_content_area(self):
        """Build the main content area."""
        with ui.column().classes("flex-grow h-full").style(
            f"background-color: {COLORS['background']}; "
            "padding: 24px; "
            "overflow: auto;"
        ):
            self.content_container = ui.column().classes("w-full")
            self._show_welcome()

    def _show_welcome(self):
        """Show welcome message when no app is selected."""
        self.content_container.clear()
        with self.content_container:
            ui.label("Welcome to App Launcher").classes("text-2xl font-bold mb-4").style(
                f"color: {COLORS['text']}"
            )
            ui.label("Select an app from the sidebar to get started.").style(
                f"color: {COLORS['text_secondary']}"
            )

    def _select_app(self, app: AppInfo):
        """Load and display the selected app."""
        self.current_app = app
        self.content_container.clear()

        with self.content_container:
            try:
                module = load_app_module(app)
                module.render(self.content_container)
            except AppLoadError as e:
                self._show_error(str(e))
            except Exception as e:
                self._show_error(f"Unexpected error: {e}")

    def _show_error(self, message: str):
        """Display an error message in the content area."""
        ui.label("Error loading app").classes("text-xl font-bold mb-2").style(
            f"color: {COLORS['error']}"
        )
        ui.label(message).style(f"color: {COLORS['text_secondary']}")
