"""Shared theme configuration for the launcher and apps."""

COLORS = {
    "primary": "#1976D2",
    "secondary": "#424242",
    "background": "#121212",
    "surface": "#1E1E1E",
    "text": "#FFFFFF",
    "text_secondary": "#B0B0B0",
    "accent": "#82B1FF",
    "error": "#CF6679",
    "success": "#4CAF50",
}

SIDEBAR_WIDTH = 250

FONTS = {
    "family": "Roboto, sans-serif",
    "size_normal": "14px",
    "size_small": "12px",
    "size_large": "18px",
}
