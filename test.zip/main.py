"""App Launcher entry point."""

import sys
from pathlib import Path

from nicegui import ui

from launcher.ui import LauncherUI


def get_apps_dir() -> Path:
    """Get the apps directory, handling both dev and bundled modes."""
    if getattr(sys, "frozen", False):
        # Running as PyInstaller bundle
        base = Path(sys._MEIPASS)
    else:
        # Running as script
        base = Path(__file__).parent

    return base / "apps"


def main():
    # Ensure apps directory exists
    apps_dir = get_apps_dir()
    apps_dir.mkdir(exist_ok=True)

    # Create and setup UI
    launcher = LauncherUI(apps_dir)
    launcher.setup()

    # Run the app
    ui.run(
        title="App Launcher",
        native=True,
        window_size=(1200, 800),
        reload=False,
    )


if __name__ == "__main__":
    main()
