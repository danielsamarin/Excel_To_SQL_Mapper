# App Launcher Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a NiceGUI-based app launcher with sidebar navigation, lazy-loaded Python apps, and a Textual TUI scaffolder.

**Architecture:** Single-process Python application using NiceGUI for UI. Apps are discovered from an `apps/` folder via YAML manifests and dynamically imported when selected. Bundled with PyInstaller for distribution.

**Tech Stack:** Python, NiceGUI, pywebview, Textual, PyYAML, uv, PyInstaller

---

## Task 1: Project Setup

**Files:**
- Create: `pyproject.toml`
- Create: `.python-version`

**Step 1: Initialize uv project**

Run:
```bash
cd .worktrees/app-launcher
uv init --name app-launcher --python 3.12
```

**Step 2: Add dependencies**

Run:
```bash
uv add nicegui pywebview pyyaml
uv add --dev pyinstaller textual pytest
```

**Step 3: Verify setup**

Run:
```bash
uv run python --version
```
Expected: Python 3.12.x

**Step 4: Commit**

```bash
git add pyproject.toml uv.lock .python-version
git commit -m "chore: initialize project with uv and dependencies"
```

---

## Task 2: Create Directory Structure

**Files:**
- Create: `launcher/__init__.py`
- Create: `launcher/core.py`
- Create: `launcher/ui.py`
- Create: `launcher/theme.py`
- Create: `apps/.gitkeep`
- Create: `tests/__init__.py`

**Step 1: Create directories and empty files**

Run:
```bash
mkdir -p launcher apps tests
touch launcher/__init__.py
touch launcher/core.py
touch launcher/ui.py
touch launcher/theme.py
touch apps/.gitkeep
touch tests/__init__.py
```

**Step 2: Commit**

```bash
git add launcher/ apps/ tests/
git commit -m "chore: create directory structure"
```

---

## Task 3: App Discovery - Tests

**Files:**
- Create: `tests/test_core.py`
- Create: `launcher/core.py`

**Step 1: Write failing test for AppInfo dataclass**

Create `tests/test_core.py`:
```python
from pathlib import Path
from launcher.core import AppInfo


def test_app_info_creation():
    app = AppInfo(
        id="test-app",
        name="Test App",
        path=Path("/fake/path"),
        icon="apps",
        description="A test app",
    )
    assert app.id == "test-app"
    assert app.name == "Test App"
    assert app.icon == "apps"
```

**Step 2: Run test to verify it fails**

Run:
```bash
uv run pytest tests/test_core.py::test_app_info_creation -v
```
Expected: FAIL with "cannot import name 'AppInfo'"

**Step 3: Implement AppInfo dataclass**

Edit `launcher/core.py`:
```python
from dataclasses import dataclass
from pathlib import Path


@dataclass
class AppInfo:
    id: str
    name: str
    path: Path
    icon: str
    description: str
```

**Step 4: Run test to verify it passes**

Run:
```bash
uv run pytest tests/test_core.py::test_app_info_creation -v
```
Expected: PASS

**Step 5: Commit**

```bash
git add tests/test_core.py launcher/core.py
git commit -m "feat: add AppInfo dataclass"
```

---

## Task 4: App Discovery - discover_apps Function

**Files:**
- Modify: `tests/test_core.py`
- Modify: `launcher/core.py`

**Step 1: Write failing test for discover_apps**

Add to `tests/test_core.py`:
```python
import tempfile
import yaml


def test_discover_apps_finds_app_with_manifest(tmp_path):
    # Create a test app with manifest
    app_dir = tmp_path / "my-app"
    app_dir.mkdir()

    manifest = {
        "id": "my-app",
        "name": "My App",
        "description": "Test application",
        "icon": "home",
        "version": "1.0.0",
    }
    (app_dir / "manifest.yaml").write_text(yaml.dump(manifest))
    (app_dir / "app.py").write_text("def render(container): pass")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 1
    assert apps[0].id == "my-app"
    assert apps[0].name == "My App"


def test_discover_apps_ignores_folders_without_manifest(tmp_path):
    # Create folder without manifest
    (tmp_path / "not-an-app").mkdir()

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert len(apps) == 0


def test_discover_apps_returns_sorted_by_name(tmp_path):
    for app_id, name in [("z-app", "Zebra"), ("a-app", "Apple")]:
        app_dir = tmp_path / app_id
        app_dir.mkdir()
        manifest = {"id": app_id, "name": name, "description": "", "icon": "apps", "version": "1.0.0"}
        (app_dir / "manifest.yaml").write_text(yaml.dump(manifest))
        (app_dir / "app.py").write_text("def render(container): pass")

    from launcher.core import discover_apps

    apps = discover_apps(tmp_path)

    assert apps[0].name == "Apple"
    assert apps[1].name == "Zebra"
```

**Step 2: Run tests to verify they fail**

Run:
```bash
uv run pytest tests/test_core.py -v
```
Expected: FAIL with "cannot import name 'discover_apps'"

**Step 3: Implement discover_apps**

Add to `launcher/core.py`:
```python
import yaml


def discover_apps(apps_dir: Path) -> list[AppInfo]:
    """Scan directory for apps with manifest.yaml files."""
    apps = []

    if not apps_dir.exists():
        return apps

    for folder in apps_dir.iterdir():
        if not folder.is_dir():
            continue

        manifest_path = folder / "manifest.yaml"
        if not manifest_path.exists():
            continue

        try:
            manifest = yaml.safe_load(manifest_path.read_text())
            apps.append(AppInfo(
                id=manifest["id"],
                name=manifest["name"],
                path=folder,
                icon=manifest.get("icon", "apps"),
                description=manifest.get("description", ""),
            ))
        except (yaml.YAMLError, KeyError):
            continue

    return sorted(apps, key=lambda a: a.name)
```

**Step 4: Run tests to verify they pass**

Run:
```bash
uv run pytest tests/test_core.py -v
```
Expected: All PASS

**Step 5: Commit**

```bash
git add tests/test_core.py launcher/core.py
git commit -m "feat: add discover_apps function"
```

---

## Task 5: App Loading

**Files:**
- Modify: `tests/test_core.py`
- Modify: `launcher/core.py`

**Step 1: Write failing test for load_app_module**

Add to `tests/test_core.py`:
```python
def test_load_app_module_returns_module_with_render(tmp_path):
    app_dir = tmp_path / "test-app"
    app_dir.mkdir()

    app_code = '''
def render(container):
    container.test_value = "rendered"
'''
    (app_dir / "app.py").write_text(app_code)

    from launcher.core import load_app_module, AppInfo

    app_info = AppInfo(
        id="test-app",
        name="Test",
        path=app_dir,
        icon="apps",
        description="",
    )

    module = load_app_module(app_info)

    assert hasattr(module, "render")
    assert callable(module.render)


def test_load_app_module_raises_on_missing_file(tmp_path):
    from launcher.core import load_app_module, AppInfo, AppLoadError

    app_info = AppInfo(
        id="missing",
        name="Missing",
        path=tmp_path / "nonexistent",
        icon="apps",
        description="",
    )

    import pytest
    with pytest.raises(AppLoadError):
        load_app_module(app_info)
```

**Step 2: Run tests to verify they fail**

Run:
```bash
uv run pytest tests/test_core.py::test_load_app_module_returns_module_with_render -v
```
Expected: FAIL with "cannot import name 'load_app_module'"

**Step 3: Implement load_app_module**

Add to `launcher/core.py`:
```python
import importlib.util
import sys


class AppLoadError(Exception):
    """Raised when an app fails to load."""
    pass


def load_app_module(app_info: AppInfo):
    """Dynamically import an app's module."""
    app_file = app_info.path / "app.py"

    if not app_file.exists():
        raise AppLoadError(f"App file not found: {app_file}")

    try:
        # Remove from cache if previously loaded (for reload support)
        module_name = f"apps.{app_info.id}"
        if module_name in sys.modules:
            del sys.modules[module_name]

        spec = importlib.util.spec_from_file_location(module_name, app_file)
        if spec is None or spec.loader is None:
            raise AppLoadError(f"Could not load spec for: {app_file}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return module
    except Exception as e:
        raise AppLoadError(f"Failed to load app {app_info.id}: {e}") from e
```

**Step 4: Run tests to verify they pass**

Run:
```bash
uv run pytest tests/test_core.py -v
```
Expected: All PASS

**Step 5: Commit**

```bash
git add tests/test_core.py launcher/core.py
git commit -m "feat: add load_app_module function"
```

---

## Task 6: Theme Module

**Files:**
- Create: `tests/test_theme.py`
- Modify: `launcher/theme.py`

**Step 1: Write failing test for theme constants**

Create `tests/test_theme.py`:
```python
def test_theme_has_colors():
    from launcher.theme import COLORS

    assert "primary" in COLORS
    assert "secondary" in COLORS
    assert "background" in COLORS
    assert "surface" in COLORS
    assert "text" in COLORS


def test_theme_has_sidebar_width():
    from launcher.theme import SIDEBAR_WIDTH

    assert isinstance(SIDEBAR_WIDTH, int)
    assert SIDEBAR_WIDTH > 0
```

**Step 2: Run tests to verify they fail**

Run:
```bash
uv run pytest tests/test_theme.py -v
```
Expected: FAIL with "cannot import name 'COLORS'"

**Step 3: Implement theme constants**

Edit `launcher/theme.py`:
```python
"""Shared theme configuration for the launcher and apps."""

COLORS = {
    "primary": "#1976D2",
    "secondary": "#424242",
    "background": "#121212",
    "surface": "#1E1E1E",
    "text": "#FFFFFF",
    "text_secondary": "#B0B0B0",
    "accent": "#82B1FF",
    "error": "#CF6679",
    "success": "#4CAF50",
}

SIDEBAR_WIDTH = 250

FONTS = {
    "family": "Roboto, sans-serif",
    "size_normal": "14px",
    "size_small": "12px",
    "size_large": "18px",
}
```

**Step 4: Run tests to verify they pass**

Run:
```bash
uv run pytest tests/test_theme.py -v
```
Expected: All PASS

**Step 5: Commit**

```bash
git add tests/test_theme.py launcher/theme.py
git commit -m "feat: add theme configuration"
```

---

## Task 7: Launcher UI - Basic Structure

**Files:**
- Modify: `launcher/ui.py`
- Create: `main.py`

**Step 1: Implement basic UI structure**

Edit `launcher/ui.py`:
```python
"""Main launcher UI with sidebar navigation."""

from pathlib import Path
from nicegui import ui

from launcher.core import AppInfo, discover_apps, load_app_module, AppLoadError
from launcher.theme import COLORS, SIDEBAR_WIDTH


class LauncherUI:
    def __init__(self, apps_dir: Path):
        self.apps_dir = apps_dir
        self.apps: list[AppInfo] = []
        self.current_app: AppInfo | None = None
        self.content_container = None

    def setup(self):
        """Initialize the UI layout."""
        self.apps = discover_apps(self.apps_dir)

        # Apply dark theme
        ui.dark_mode().enable()

        # Main layout
        with ui.row().classes("w-full h-screen no-wrap"):
            self._build_sidebar()
            self._build_content_area()

    def _build_sidebar(self):
        """Build the sidebar with app list."""
        with ui.column().classes("h-full").style(
            f"width: {SIDEBAR_WIDTH}px; "
            f"background-color: {COLORS['surface']}; "
            "padding: 16px; "
            "border-right: 1px solid #333;"
        ):
            # Header
            ui.label("App Launcher").classes("text-xl font-bold mb-4").style(
                f"color: {COLORS['text']}"
            )

            # App list
            for app in self.apps:
                self._build_app_button(app)

            # Empty state
            if not self.apps:
                ui.label("No apps found").classes("text-gray-500 italic")
                ui.label("Add apps to the 'apps' folder").classes("text-gray-600 text-sm")

    def _build_app_button(self, app: AppInfo):
        """Build a sidebar button for an app."""
        with ui.button(on_click=lambda a=app: self._select_app(a)).props(
            "flat align=left"
        ).classes("w-full justify-start").style(
            f"color: {COLORS['text']};"
        ):
            ui.icon(app.icon).classes("mr-2")
            ui.label(app.name)

    def _build_content_area(self):
        """Build the main content area."""
        with ui.column().classes("flex-grow h-full").style(
            f"background-color: {COLORS['background']}; "
            "padding: 24px; "
            "overflow: auto;"
        ):
            self.content_container = ui.column().classes("w-full")
            self._show_welcome()

    def _show_welcome(self):
        """Show welcome message when no app is selected."""
        self.content_container.clear()
        with self.content_container:
            ui.label("Welcome to App Launcher").classes("text-2xl font-bold mb-4").style(
                f"color: {COLORS['text']}"
            )
            ui.label("Select an app from the sidebar to get started.").style(
                f"color: {COLORS['text_secondary']}"
            )

    def _select_app(self, app: AppInfo):
        """Load and display the selected app."""
        self.current_app = app
        self.content_container.clear()

        with self.content_container:
            try:
                module = load_app_module(app)
                module.render(self.content_container)
            except AppLoadError as e:
                self._show_error(str(e))
            except Exception as e:
                self._show_error(f"Unexpected error: {e}")

    def _show_error(self, message: str):
        """Display an error message in the content area."""
        ui.label("Error loading app").classes("text-xl font-bold mb-2").style(
            f"color: {COLORS['error']}"
        )
        ui.label(message).style(f"color: {COLORS['text_secondary']}")
```

**Step 2: Create main entry point**

Create `main.py`:
```python
"""App Launcher entry point."""

import sys
from pathlib import Path

from nicegui import ui

from launcher.ui import LauncherUI


def get_apps_dir() -> Path:
    """Get the apps directory, handling both dev and bundled modes."""
    if getattr(sys, "frozen", False):
        # Running as PyInstaller bundle
        base = Path(sys._MEIPASS)
    else:
        # Running as script
        base = Path(__file__).parent

    return base / "apps"


def main():
    # Ensure apps directory exists
    apps_dir = get_apps_dir()
    apps_dir.mkdir(exist_ok=True)

    # Create and setup UI
    launcher = LauncherUI(apps_dir)
    launcher.setup()

    # Run the app
    ui.run(
        title="App Launcher",
        native=True,
        window_size=(1200, 800),
        reload=False,
    )


if __name__ == "__main__":
    main()
```

**Step 3: Test manually**

Run:
```bash
uv run python main.py
```
Expected: Window opens with sidebar and welcome message

**Step 4: Commit**

```bash
git add launcher/ui.py main.py
git commit -m "feat: add launcher UI with sidebar navigation"
```

---

## Task 8: Create Example App

**Files:**
- Create: `apps/hello-world/manifest.yaml`
- Create: `apps/hello-world/app.py`

**Step 1: Create example app manifest**

Create `apps/hello-world/manifest.yaml`:
```yaml
name: Hello World
id: hello-world
description: A simple example app
icon: waving_hand
version: 1.0.0
```

**Step 2: Create example app code**

Create `apps/hello-world/app.py`:
```python
"""Hello World example app."""

from nicegui import ui


def render(container):
    """Render the Hello World app UI."""
    with container:
        ui.label("Hello World!").classes("text-2xl font-bold mb-4")

        name = ui.input("Your name", placeholder="Enter your name")
        output = ui.label("")

        def greet():
            if name.value:
                output.text = f"Hello, {name.value}!"
            else:
                output.text = "Please enter your name."

        ui.button("Greet", on_click=greet).classes("mt-4")
```

**Step 3: Test the app**

Run:
```bash
uv run python main.py
```
Expected: "Hello World" appears in sidebar, clicking it shows the greeting app

**Step 4: Commit**

```bash
git add apps/hello-world/
git commit -m "feat: add hello-world example app"
```

---

## Task 9: Scaffolder - Project Structure

**Files:**
- Create: `launcher/scaffold/__init__.py`
- Create: `launcher/scaffold/__main__.py`
- Create: `launcher/scaffold/templates/blank/manifest.yaml`
- Create: `launcher/scaffold/templates/blank/app.py`

**Step 1: Create scaffolder package**

Create `launcher/scaffold/__init__.py`:
```python
"""App scaffolder TUI."""
```

Create `launcher/scaffold/__main__.py`:
```python
"""Entry point for scaffolder TUI."""

from launcher.scaffold.app import ScaffolderApp


def main():
    app = ScaffolderApp()
    app.run()


if __name__ == "__main__":
    main()
```

**Step 2: Create blank template**

Create `launcher/scaffold/templates/blank/manifest.yaml`:
```yaml
name: {{name}}
id: {{id}}
description: {{description}}
icon: {{icon}}
version: 1.0.0
```

Create `launcher/scaffold/templates/blank/app.py`:
```python
"""{{name}} app."""

from nicegui import ui


def render(container):
    """Render the app UI."""
    with container:
        ui.label("{{name}}").classes("text-2xl font-bold")
```

**Step 3: Commit**

```bash
git add launcher/scaffold/
git commit -m "chore: set up scaffolder package structure"
```

---

## Task 10: Scaffolder - Form-Based Template

**Files:**
- Create: `launcher/scaffold/templates/form/manifest.yaml`
- Create: `launcher/scaffold/templates/form/app.py`

**Step 1: Create form template manifest**

Create `launcher/scaffold/templates/form/manifest.yaml`:
```yaml
name: {{name}}
id: {{id}}
description: {{description}}
icon: {{icon}}
version: 1.0.0
```

**Step 2: Create form template app**

Create `launcher/scaffold/templates/form/app.py`:
```python
"""{{name}} - Form-based app."""

from nicegui import ui


def render(container):
    """Render the form-based app UI."""
    with container:
        ui.label("{{name}}").classes("text-2xl font-bold mb-4")

        # Form fields
        with ui.card().classes("w-full max-w-md"):
            field1 = ui.input("Field 1", placeholder="Enter value")
            field2 = ui.input("Field 2", placeholder="Enter value")

            result = ui.label("").classes("mt-4")

            def submit():
                result.text = f"Submitted: {field1.value}, {field2.value}"

            ui.button("Submit", on_click=submit).classes("mt-4")
```

**Step 3: Commit**

```bash
git add launcher/scaffold/templates/form/
git commit -m "feat: add form-based scaffolder template"
```

---

## Task 11: Scaffolder - Additional Templates

**Files:**
- Create: `launcher/scaffold/templates/file-browser/manifest.yaml`
- Create: `launcher/scaffold/templates/file-browser/app.py`
- Create: `launcher/scaffold/templates/settings/manifest.yaml`
- Create: `launcher/scaffold/templates/settings/app.py`
- Create: `launcher/scaffold/templates/dashboard/manifest.yaml`
- Create: `launcher/scaffold/templates/dashboard/app.py`

**Step 1: Create file-browser template**

Create `launcher/scaffold/templates/file-browser/manifest.yaml`:
```yaml
name: {{name}}
id: {{id}}
description: {{description}}
icon: {{icon}}
version: 1.0.0
```

Create `launcher/scaffold/templates/file-browser/app.py`:
```python
"""{{name}} - File browser app."""

from pathlib import Path
from nicegui import ui


def render(container):
    """Render the file browser app UI."""
    with container:
        ui.label("{{name}}").classes("text-2xl font-bold mb-4")

        current_path = ui.label(str(Path.home())).classes("text-gray-400 mb-2")
        file_list = ui.column().classes("w-full")

        def refresh_files(path: Path):
            current_path.text = str(path)
            file_list.clear()
            with file_list:
                # Parent directory
                if path.parent != path:
                    with ui.row().classes("items-center cursor-pointer hover:bg-gray-800 p-2"):
                        ui.icon("folder").classes("mr-2")
                        ui.label("..").on("click", lambda p=path.parent: refresh_files(p))

                # List contents
                try:
                    for item in sorted(path.iterdir()):
                        icon = "folder" if item.is_dir() else "description"
                        with ui.row().classes("items-center cursor-pointer hover:bg-gray-800 p-2"):
                            ui.icon(icon).classes("mr-2")
                            if item.is_dir():
                                ui.label(item.name).on("click", lambda p=item: refresh_files(p))
                            else:
                                ui.label(item.name)
                except PermissionError:
                    ui.label("Permission denied").classes("text-red-500")

        refresh_files(Path.home())
```

**Step 2: Create settings template**

Create `launcher/scaffold/templates/settings/manifest.yaml`:
```yaml
name: {{name}}
id: {{id}}
description: {{description}}
icon: {{icon}}
version: 1.0.0
```

Create `launcher/scaffold/templates/settings/app.py`:
```python
"""{{name}} - Settings panel app."""

import json
from pathlib import Path
from nicegui import ui


def render(container):
    """Render the settings panel app UI."""
    settings_file = Path.home() / ".{{id}}-settings.json"

    def load_settings() -> dict:
        if settings_file.exists():
            return json.loads(settings_file.read_text())
        return {"option1": True, "option2": "", "option3": 50}

    def save_settings():
        settings = {
            "option1": option1.value,
            "option2": option2.value,
            "option3": option3.value,
        }
        settings_file.write_text(json.dumps(settings, indent=2))
        ui.notify("Settings saved!", type="positive")

    settings = load_settings()

    with container:
        ui.label("{{name}}").classes("text-2xl font-bold mb-4")

        with ui.card().classes("w-full max-w-md"):
            ui.label("Configuration").classes("text-lg font-semibold mb-2")

            option1 = ui.switch("Enable feature", value=settings.get("option1", True))
            option2 = ui.input("API Key", value=settings.get("option2", ""))
            option3 = ui.slider(min=0, max=100, value=settings.get("option3", 50))

            ui.button("Save Settings", on_click=save_settings).classes("mt-4")
```

**Step 3: Create dashboard template**

Create `launcher/scaffold/templates/dashboard/manifest.yaml`:
```yaml
name: {{name}}
id: {{id}}
description: {{description}}
icon: {{icon}}
version: 1.0.0
```

Create `launcher/scaffold/templates/dashboard/app.py`:
```python
"""{{name}} - Dashboard app."""

from nicegui import ui


def render(container):
    """Render the dashboard app UI."""
    with container:
        ui.label("{{name}}").classes("text-2xl font-bold mb-4")

        # Stats row
        with ui.row().classes("w-full gap-4 mb-4"):
            for title, value, icon_name in [
                ("Total Items", "1,234", "inventory"),
                ("Active", "56", "check_circle"),
                ("Pending", "12", "pending"),
            ]:
                with ui.card().classes("flex-1"):
                    with ui.row().classes("items-center"):
                        ui.icon(icon_name).classes("text-3xl mr-2")
                        with ui.column():
                            ui.label(title).classes("text-gray-400 text-sm")
                            ui.label(value).classes("text-2xl font-bold")

        # Recent activity
        with ui.card().classes("w-full"):
            ui.label("Recent Activity").classes("text-lg font-semibold mb-2")
            for i in range(5):
                with ui.row().classes("items-center py-2 border-b border-gray-700"):
                    ui.icon("event").classes("mr-2 text-gray-400")
                    ui.label(f"Activity item {i + 1}")
                    ui.label("2 hours ago").classes("ml-auto text-gray-500 text-sm")
```

**Step 4: Commit**

```bash
git add launcher/scaffold/templates/
git commit -m "feat: add file-browser, settings, and dashboard templates"
```

---

## Task 12: Scaffolder - Textual TUI App

**Files:**
- Create: `launcher/scaffold/app.py`
- Create: `launcher/scaffold/screens.py`

**Step 1: Create TUI screens**

Create `launcher/scaffold/screens.py`:
```python
"""Textual TUI screens for the scaffolder."""

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Input, Label, RadioButton, RadioSet, Checkbox


class BasicsScreen(Screen):
    """Screen for entering app basics."""

    BINDINGS = [("escape", "quit", "Quit")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Vertical(
            Label("Create New App", classes="title"),
            Label("App Name:"),
            Input(placeholder="My App", id="name"),
            Label("App ID:"),
            Input(placeholder="my-app", id="app_id"),
            Label("Description:"),
            Input(placeholder="What does this app do?", id="description"),
            Label("Icon:"),
            Input(placeholder="apps", id="icon"),
            Horizontal(
                Button("Cancel", variant="default", id="cancel"),
                Button("Next →", variant="primary", id="next"),
                classes="buttons",
            ),
            id="form",
        )
        yield Footer()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "name":
            # Auto-generate ID from name
            app_id_input = self.query_one("#app_id", Input)
            if not app_id_input.value or app_id_input.value == self._auto_id:
                self._auto_id = event.value.lower().replace(" ", "-")
                app_id_input.value = self._auto_id

    def on_mount(self) -> None:
        self._auto_id = ""

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel":
            self.app.exit()
        elif event.button.id == "next":
            self.app.basics = {
                "name": self.query_one("#name", Input).value,
                "id": self.query_one("#app_id", Input).value,
                "description": self.query_one("#description", Input).value,
                "icon": self.query_one("#icon", Input).value or "apps",
            }
            self.app.push_screen("template")


class TemplateScreen(Screen):
    """Screen for selecting app template."""

    BINDINGS = [("escape", "back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Vertical(
            Label("Choose Template", classes="title"),
            RadioSet(
                RadioButton("Blank - Empty starting point", id="blank"),
                RadioButton("Form-based - Input fields + action", id="form"),
                RadioButton("File browser - Directory picker UI", id="file-browser"),
                RadioButton("Settings panel - Config with save", id="settings"),
                RadioButton("Dashboard - Cards + status info", id="dashboard"),
                id="templates",
            ),
            Horizontal(
                Button("← Back", variant="default", id="back"),
                Button("Next →", variant="primary", id="next"),
                classes="buttons",
            ),
            id="form",
        )
        yield Footer()

    def action_back(self) -> None:
        self.app.pop_screen()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "back":
            self.app.pop_screen()
        elif event.button.id == "next":
            radio_set = self.query_one("#templates", RadioSet)
            selected = radio_set.pressed_button
            self.app.template = selected.id if selected else "blank"
            self.app.push_screen("features")


class FeaturesScreen(Screen):
    """Screen for selecting optional features."""

    BINDINGS = [("escape", "back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Vertical(
            Label("Optional Features", classes="title"),
            Checkbox("File picker dialog", id="file_picker"),
            Checkbox("Settings persistence (JSON storage)", id="settings_persistence"),
            Checkbox("Notifications (toast messages)", id="notifications"),
            Checkbox("Background task runner", id="background_tasks"),
            Horizontal(
                Button("← Back", variant="default", id="back"),
                Button("Create →", variant="success", id="create"),
                classes="buttons",
            ),
            id="form",
        )
        yield Footer()

    def action_back(self) -> None:
        self.app.pop_screen()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "back":
            self.app.pop_screen()
        elif event.button.id == "create":
            self.app.features = []
            for feature_id in ["file_picker", "settings_persistence", "notifications", "background_tasks"]:
                checkbox = self.query_one(f"#{feature_id}", Checkbox)
                if checkbox.value:
                    self.app.features.append(feature_id)
            self.app.create_app()
```

**Step 2: Create TUI app**

Create `launcher/scaffold/app.py`:
```python
"""Main Textual TUI application for the scaffolder."""

from pathlib import Path
import shutil

from textual.app import App
from textual.css.stylesheet import Stylesheet

from launcher.scaffold.screens import BasicsScreen, TemplateScreen, FeaturesScreen


CSS = """
Screen {
    align: center middle;
}

#form {
    width: 60;
    height: auto;
    padding: 2;
    border: solid green;
}

.title {
    text-align: center;
    text-style: bold;
    margin-bottom: 1;
}

.buttons {
    margin-top: 1;
    align: center middle;
}

Button {
    margin: 0 1;
}

RadioSet {
    margin: 1 0;
}

Checkbox {
    margin: 0 0 0 1;
}
"""


class ScaffolderApp(App):
    """Textual app for scaffolding new launcher apps."""

    CSS = CSS
    TITLE = "App Scaffolder"

    SCREENS = {
        "basics": BasicsScreen,
        "template": TemplateScreen,
        "features": FeaturesScreen,
    }

    def __init__(self):
        super().__init__()
        self.basics: dict = {}
        self.template: str = "blank"
        self.features: list[str] = []

    def on_mount(self) -> None:
        self.push_screen("basics")

    def create_app(self) -> None:
        """Create the new app from template."""
        # Determine paths
        templates_dir = Path(__file__).parent / "templates"
        apps_dir = Path(__file__).parent.parent.parent / "apps"

        template_dir = templates_dir / self.template
        target_dir = apps_dir / self.basics["id"]

        # Create target directory
        target_dir.mkdir(parents=True, exist_ok=True)

        # Copy and process template files
        for template_file in template_dir.iterdir():
            content = template_file.read_text()

            # Replace placeholders
            content = content.replace("{{name}}", self.basics["name"])
            content = content.replace("{{id}}", self.basics["id"])
            content = content.replace("{{description}}", self.basics["description"])
            content = content.replace("{{icon}}", self.basics["icon"])

            # Write to target
            target_file = target_dir / template_file.name
            target_file.write_text(content)

        self.exit(message=f"Created app at: {target_dir}")
```

**Step 3: Test the scaffolder**

Run:
```bash
uv run python -m launcher.scaffold
```
Expected: TUI appears with form for app creation

**Step 4: Commit**

```bash
git add launcher/scaffold/
git commit -m "feat: add Textual TUI scaffolder"
```

---

## Task 13: PyInstaller Build Configuration

**Files:**
- Create: `build.spec`

**Step 1: Create PyInstaller spec file**

Create `build.spec`:
```python
# -*- mode: python ; coding: utf-8 -*-

import sys
from pathlib import Path

block_cipher = None

# Get the project root
project_root = Path(SPECPATH)

a = Analysis(
    ['main.py'],
    pathex=[str(project_root)],
    binaries=[],
    datas=[
        ('apps', 'apps'),
        ('launcher/scaffold/templates', 'launcher/scaffold/templates'),
    ],
    hiddenimports=[
        'nicegui',
        'webview',
        'yaml',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='AppLauncher',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='AppLauncher',
)
```

**Step 2: Test the build**

Run:
```bash
uv run pyinstaller build.spec
```
Expected: Build completes, executable created in `dist/AppLauncher/`

**Step 3: Commit**

```bash
git add build.spec
git commit -m "chore: add PyInstaller build configuration"
```

---

## Task 14: Final Integration Test

**Step 1: Run all tests**

Run:
```bash
uv run pytest tests/ -v
```
Expected: All tests pass

**Step 2: Run the application**

Run:
```bash
uv run python main.py
```
Expected: Launcher opens with Hello World app in sidebar

**Step 3: Test scaffolder**

Run:
```bash
uv run python -m launcher.scaffold
```
Expected: TUI works, creates new app

**Step 4: Build executable**

Run:
```bash
uv run pyinstaller build.spec
```
Expected: Executable builds successfully

**Step 5: Run executable**

Run:
```bash
./dist/AppLauncher/AppLauncher.exe
```
Expected: Launcher works as standalone executable

**Step 6: Final commit**

```bash
git add -A
git commit -m "feat: complete app launcher v1.0.0"
```

---

## Summary

**Total Tasks:** 14

**Key Deliverables:**
1. Working launcher with sidebar navigation
2. App discovery from `apps/` folder
3. Dynamic app loading with error handling
4. Dark theme with consistent styling
5. Hello World example app
6. Textual TUI scaffolder with 5 templates
7. PyInstaller build configuration

**Commands Reference:**
```bash
# Development
uv run python main.py

# Run tests
uv run pytest tests/ -v

# Scaffold new app
uv run python -m launcher.scaffold

# Build executable
uv run pyinstaller build.spec
```
