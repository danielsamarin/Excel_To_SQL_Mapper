# App Launcher Design

## Overview

A local-only Python app launcher with sidebar navigation, built entirely with NiceGUI. Apps are utility/productivity tools that render inside the launcher. Bundled with PyInstaller for distribution without requiring Python installation.

## Tech Stack

- **NiceGUI** — launcher + all app UIs
- **PyInstaller** — standalone executable bundling
- **pywebview** — native window (via NiceGUI)
- **Textual** — TUI app scaffolder
- **uv** — package/project management
- **PyYAML** — manifest parsing

## Architecture

```
app-launcher/
├── pyproject.toml
├── main.py                 # Entry point
├── launcher/
│   ├── core.py             # Discovery, loading, lifecycle
│   ├── ui.py               # Sidebar + content area
│   ├── theme.py            # Shared styling + components
│   └── scaffold/           # Textual TUI scaffolder
│       ├── __main__.py
│       ├── screens.py
│       └── templates/
├── apps/                   # Discovered apps
│   └── example-app/
│       ├── manifest.yaml
│       └── app.py
└── build.spec              # PyInstaller config
```

## App Interface

### manifest.yaml

```yaml
name: App Name
id: app-id
description: What it does
icon: icon_name
version: 1.0.0
```

### app.py

```python
from nicegui import ui

def render(container):
    with container:
        ui.label("Hello from app")
```

## Key Behaviors

| Aspect | Behavior |
|--------|----------|
| Discovery | Scan `apps/` for folders with `manifest.yaml` |
| Loading | Lazy — import on selection |
| Switching | Clears container, unloads previous app |
| State | Fresh start each time (no persistence between switches) |
| Theming | Shared via `theme.py`, apps inherit automatically |
| Errors | Caught and displayed, don't crash launcher |

## UI Layout

```
┌─────────────────────────────────────────────────┐
│  Header (optional: app name, global actions)    │
├──────────┬──────────────────────────────────────┤
│          │                                      │
│  Sidebar │         Main Content Area            │
│          │                                      │
│  • App 1 │    (selected app renders here)       │
│  • App 2 │                                      │
│  • App 3 │                                      │
│          │                                      │
├──────────┴──────────────────────────────────────┤
│  Footer (optional: status, version)             │
└─────────────────────────────────────────────────┘
```

### Sidebar Behavior

- Shows app icons + names from discovered manifests
- Highlights currently selected app
- Collapsible on smaller windows (hamburger menu)

### Theming

NiceGUI uses Quasar (Vue component library) under the hood. Define theme in `theme.py`:
- Primary/secondary colors
- Font family
- Shared component styles (buttons, inputs, cards)

Apps automatically inherit these styles.

## App Discovery & Loading

### Discovery (on startup)

```python
import yaml

def discover_apps(apps_dir: Path) -> list[AppInfo]:
    apps = []
    for folder in apps_dir.iterdir():
        manifest_path = folder / "manifest.yaml"
        if manifest_path.exists():
            manifest = yaml.safe_load(manifest_path.read_text())
            apps.append(AppInfo(
                id=manifest["id"],
                name=manifest["name"],
                path=folder,
                icon=manifest.get("icon", "apps"),
                description=manifest.get("description", ""),
            ))
    return sorted(apps, key=lambda a: a.name)
```

### Loading (when app is selected)

```python
def load_app(app_info: AppInfo, container):
    # Clear previous app
    container.clear()

    # Import the app module
    spec = importlib.util.spec_from_file_location(
        app_info.id,
        app_info.path / "app.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    # Render the app
    module.render(container)
```

### Error Handling

If an app fails to load (syntax error, missing manifest), the main content area shows an error message instead of crashing the launcher.

## App Scaffolder (TUI)

### Invocation

```bash
uv run python -m launcher.scaffold
```

### Flow

**Screen 1 — Basics:**
- App Name (text input)
- App ID (auto-generated from name, editable)
- Description (text input)
- Icon (dropdown selection)

**Screen 2 — Template:**
- Blank — empty starting point
- Form-based — input fields + action button
- File browser — directory picker UI
- Settings panel — config with JSON persistence
- Dashboard — cards + status display

**Screen 3 — Features (toggles):**
- File picker dialog
- Settings persistence (JSON storage)
- Toast notifications
- Background task runner

### Output

Creates `apps/{app-id}/` with `manifest.yaml` and `app.py` pre-populated based on selections.

## Packaging & Distribution

### PyInstaller Setup

```bash
pyinstaller --onedir --windowed \
    --add-data "apps:apps" \
    --add-data "launcher/theme.py:launcher" \
    --name "AppLauncher" \
    main.py
```

### Directory structure after build

```
dist/
└── AppLauncher/
    ├── AppLauncher.exe      # Main executable
    ├── apps/                 # Bundled apps
    │   ├── app-one/
    │   └── app-two/
    └── _internal/            # Python runtime + dependencies
```

### Adding apps post-build

Users can drop new app folders into `apps/` after building. The launcher scans at runtime, so new apps appear without rebuilding.

### Development vs Production paths

```python
if getattr(sys, 'frozen', False):
    # Running as PyInstaller bundle
    base_path = Path(sys._MEIPASS)
else:
    # Running as script
    base_path = Path(__file__).parent
```

## Development Workflow

### Dependencies

```bash
uv init app-launcher
uv add nicegui pywebview pyyaml
uv add --dev pyinstaller textual
```

### Commands

```bash
# Run launcher in dev mode
uv run python main.py

# Scaffold new app
uv run python -m launcher.scaffold

# Build standalone executable
uv run pyinstaller build.spec

# Test a specific app independently
uv run python -m apps.example_app.test
```

### Testing apps independently

Create a simple test harness:

```python
from nicegui import ui
from apps.my_app import app

with ui.card() as container:
    app.render(container)

ui.run()
```
