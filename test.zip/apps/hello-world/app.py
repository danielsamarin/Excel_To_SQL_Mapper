"""Hello World example app."""

from nicegui import ui


def render(container):
    """Render the Hello World app UI."""
    with container:
        ui.label("Hello World!").classes("text-2xl font-bold mb-4")

        name = ui.input("Your name", placeholder="Enter your name")
        output = ui.label("")

        def greet():
            if name.value:
                output.text = f"Hello, {name.value}!"
            else:
                output.text = "Please enter your name."

        ui.button("Greet", on_click=greet).classes("mt-4")